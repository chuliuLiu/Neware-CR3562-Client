sln文件直接用vs studio打开，项目属于MFC架构，因此不建议通过vs code；

项目编译运行成功后，X64/release/.exe文件即为程序

需要将程序打包只需要将exe文件以及Setting.ini文件打包即可；ini配置文件不打包
时，下次校准自动生成默认ini文件。

