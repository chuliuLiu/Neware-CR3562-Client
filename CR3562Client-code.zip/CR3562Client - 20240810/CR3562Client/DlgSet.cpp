﻿// DlgSet.cpp: 实现文件
//

#include "pch.h"
#include "CR3562Client.h"
#include "afxdialogex.h"
#include "DlgSet.h"
#define POINIT_INVALID 0x7FFFFFFF

// DlgSet 对话框

IMPLEMENT_DYNAMIC(DlgSet, CDialogEx)

DlgSet::DlgSet(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_DLG_SET, pParent)
{
    m_PointVoltSeg.x = POINIT_INVALID;
    m_PointVoltSeg.y = POINIT_INVALID;
}

DlgSet::~DlgSet()
{
}

void DlgSet::DoDataExchange(CDataExchange* pDX)
{
    CDialogEx::DoDataExchange(pDX);

    DDX_Control(pDX, IDC_LIST_Point, m_ListVCaliSeg);
}

BOOL DlgSet::OnInitDialog()
{
    CDialogEx::OnInitDialog();
	((CComboBox*)GetDlgItem(IDC_COMBO_Type))->InsertString(0,L"电压");
	((CComboBox*)GetDlgItem(IDC_COMBO_Type))->InsertString(1, L"电阻");
	((CComboBox*)GetDlgItem(IDC_COMBO_Type))->SetCurSel(0);


    m_ListVCaliSeg.SetExtendedStyle(m_ListVCaliSeg.GetExtendedStyle()//设置内阻仪表格风格
        | LVS_EX_GRIDLINES /*| LVS_EX_CHECKBOXES*/ | LVS_EX_TRACKSELECT | LVS_EX_FULLROWSELECT | LVS_EX_DOUBLEBUFFER);
    int nIndex = 0;
    m_ListVCaliSeg.InsertColumn(nIndex++,
        L"序号", LVCFMT_LEFT, 80);
    m_ListVCaliSeg.InsertColumn(nIndex++,
        L"校准点(%)", LVCFMT_LEFT, 120);
    m_ListVCaliSeg.InsertColumn(nIndex++,
        L"电压(V)", LVCFMT_LEFT, 120);
    m_ListVCaliSeg.InsertColumn(nIndex++,
        L"精度(‰)", LVCFMT_LEFT, 120);
    m_ListVCaliSeg.InsertColumn(nIndex++,
        L"量程(V)", LVCFMT_LEFT, 120);

    CListCtrl* pVoltListCtrl = (CListCtrl*)this->GetDlgItem(IDC_LIST_Point);
    if (pVoltListCtrl && pVoltListCtrl->GetSafeHwnd())
    {
        CEdit* pEditVolt = (CEdit*)this->GetDlgItem(IDC_EDIT_VoltSeg);
        if (pEditVolt && pEditVolt->GetSafeHwnd())
        {
            pEditVolt->SetParent(pVoltListCtrl);
            pEditVolt->ShowWindow(SW_HIDE);
        }
    }

    SetHightLowParam(4, 0, 1.f);

    FreshListVCaliSeg();

	return 0;
}


BEGIN_MESSAGE_MAP(DlgSet, CDialogEx)
	ON_BN_CLICKED(IDOK, &DlgSet::OnBnClickedOk)
	ON_CBN_SELCHANGE(IDC_COMBO_Type, &DlgSet::OnCbnSelchangeComboType)
	ON_NOTIFY(NM_CLICK, IDC_LIST_Point, &DlgSet::OnNMClickListVolSeg)
    ON_EN_KILLFOCUS(IDC_EDIT_VoltSeg, &DlgSet::OnEnKillfocusEditVoltseg)
END_MESSAGE_MAP()


// DlgSet 消息处理程序


const bool DlgSet::IsEditInputNumber(const CString& cstrNumber)
{
    //点字符不能多于1个
    unsigned long nDotCount = 0;
    for (int nIndex = 0; nIndex < cstrNumber.GetLength(); nIndex++)
    {
        if (cstrNumber[nIndex] == '.')
        {
            nDotCount++;
            if (nDotCount > 1)
            {
                CString cstrTmp;
                cstrTmp = cstrNumber.Left(nIndex);
                cstrTmp += cstrNumber.Right(cstrNumber.GetLength() - nIndex - 1);
                return false;
            }
        }
    }

    //不允许输入数字和点以外的字符，支持负值
    for (int nIndex = 0; nIndex < cstrNumber.GetLength(); nIndex++)
    {
        if ((cstrNumber[nIndex] != '.') && ((cstrNumber[nIndex] > '9') || (cstrNumber[nIndex] < '0')))
        {
            if (nIndex != 0) {
                return false;
            }
            else {
                if (cstrNumber[nIndex] != '-') {
                    return false;
                }
            }
        }
    }
    return true;
}

bool DlgSet::ShowValueToUnit(const string& strValue, double& dValue)
{
    bool bRtrn = true;
    if (strValue.empty()) {
        //字符串为空, 则返回 0 值
        dValue = 0;
    }
    else {//当前仅用于调整校准检测分段的电压部分
        double dRate = 1;
        unsigned long nDecimal = 5;
        dValue = atof(strValue.c_str()) / dRate;
    }
    return bRtrn;
}

void DlgSet::FreshCaliPrmPoint()
{
    GetVoltCaliSegParam();

    FreshParamDataList();
}

void DlgSet::GetVoltCaliSegParam()
{
    if (((CComboBox*)GetDlgItem(IDC_COMBO_Type))->GetCurSel() == 0) {
        map<float, MacCnnctDev_copy::CaliRangePointPrm::RangePoint>::iterator it_mapVolt;
        for (it_mapVolt = m_VCaliRangePointPrm.m_mapVoltRange.begin();
            it_mapVolt != m_VCaliRangePointPrm.m_mapVoltRange.end();
            it_mapVolt++)
        {
            MacCnnctDev_copy::CaliRangePointPrm::RangePoint* pVC = (MacCnnctDev_copy::CaliRangePointPrm::RangePoint*)&(it_mapVolt->second);
            pVC->m_vcRangePoint.clear();
        }

        map<float, MacCnnctDev_copy::CaliRangePointPrm::RangePoint>::iterator it;
        for (int i = 0; i < m_VoltCaliRangePoint.m_vcRangePoint.size(); i++)
        {
            MacCnnctDev_copy::CaliPointNo* pRangePoint = &(m_VoltCaliRangePoint.m_vcRangePoint[i]);
            it = m_VCaliRangePointPrm.m_mapVoltRange.find(pRangePoint->m_fRange);
            if (it != m_VCaliRangePointPrm.m_mapVoltRange.end())
            {
                MacCnnctDev_copy::CaliRangePointPrm::RangePoint* pVC = (MacCnnctDev_copy::CaliRangePointPrm::RangePoint*)&(it->second);
                MacCnnctDev_copy::CaliPointNo hCaliPoint;
                hCaliPoint.m_fRange = pRangePoint->m_fRange;
                hCaliPoint.m_fPoint = pRangePoint->m_fPoint;
                hCaliPoint.m_fPrecision = pRangePoint->m_fPrecision;
                pVC->m_vcRangePoint.push_back(hCaliPoint);
            }
        }
    }
    else if (((CComboBox*)GetDlgItem(IDC_COMBO_Type))->GetCurSel() == 1) {
        map<float, MacCnnctDev_copy::CaliRangePointPrm::RangePoint>::iterator it_mapVolt;
        for (it_mapVolt = m_RCaliRangePointPrm.m_mapVoltRange.begin();
            it_mapVolt != m_RCaliRangePointPrm.m_mapVoltRange.end();
            it_mapVolt++)
        {
            MacCnnctDev_copy::CaliRangePointPrm::RangePoint* pVC = (MacCnnctDev_copy::CaliRangePointPrm::RangePoint*)&(it_mapVolt->second);
            pVC->m_vcRangePoint.clear();
        }

        map<float, MacCnnctDev_copy::CaliRangePointPrm::RangePoint>::iterator it;
        for (int i = 0; i < m_ResCaliRangePoint.m_vcRangePoint.size(); i++)
        {
            MacCnnctDev_copy::CaliPointNo* pRangePoint = &(m_ResCaliRangePoint.m_vcRangePoint[i]);
            it = m_RCaliRangePointPrm.m_mapVoltRange.find(pRangePoint->m_fRange);
            if (it != m_RCaliRangePointPrm.m_mapVoltRange.end())
            {
                MacCnnctDev_copy::CaliRangePointPrm::RangePoint* pVC = (MacCnnctDev_copy::CaliRangePointPrm::RangePoint*)&(it->second);
                MacCnnctDev_copy::CaliPointNo hCaliPoint;
                hCaliPoint.m_fRange = pRangePoint->m_fRange;
                hCaliPoint.m_fPoint = pRangePoint->m_fPoint;
                hCaliPoint.m_fPrecision = pRangePoint->m_fPrecision;
                pVC->m_vcRangePoint.push_back(hCaliPoint);
            }
        }
    }
   
}

void DlgSet::FreshParamDataList()
{
    CString strName;
    bool bDMM = false;
    float fUSpe = 0;
    float fVoltValue = 0;
    //float fVoltValueDV = 0;
    float fCurrValue = 0;
    float fTURValue = 0;
    //float fTURValueDV = 0;
    float fAccuracy = 0;
    float fMaxRangValue = 0;


    if (((CComboBox*)GetDlgItem(IDC_COMBO_Type))->GetCurSel() == 0) {
        //电压点
        //m_ListVolCaliSeg.DeleteAllItems();
        FreshListVCaliSeg();
        m_VoltCaliRangePoint.m_vcRangePoint.clear();

        MacCnnctDev_copy::CaliRangePointPrm* pCaliRangePointVolt = (MacCnnctDev_copy::CaliRangePointPrm*)&(m_VCaliRangePointPrm);
        map<float, MacCnnctDev_copy::CaliRangePointPrm::RangePoint>::iterator it_mapRealVolt;
        for (it_mapRealVolt = pCaliRangePointVolt->m_mapVoltRange.begin();
            it_mapRealVolt != pCaliRangePointVolt->m_mapVoltRange.end();
            it_mapRealVolt++)
        {
            MacCnnctDev_copy::CaliRangePointPrm::RangePoint* pVC = (MacCnnctDev_copy::CaliRangePointPrm::RangePoint*)&(it_mapRealVolt->second);
            if (pVC->m_vcRangePoint.size() > 0)
            {
                fMaxRangValue = it_mapRealVolt->first;
                for (int i = 0; i < pVC->m_vcRangePoint.size(); i++)
                {

                    MacCnnctDev_copy::CaliPointNo hCaliPoint;
                    hCaliPoint.m_fRange = fMaxRangValue;
                    hCaliPoint.m_fPoint = pVC->m_vcRangePoint[i].m_fPoint;
                    hCaliPoint.m_fPrecision = pVC->m_vcRangePoint[i].m_fPrecision;
                    /*hCaliPoint.m_wDMMNo = pVC->m_vcRangePoint[i].m_wDMMNo;
                    hCaliPoint.m_wShuntNo = pVC->m_vcRangePoint[i].m_wShuntNo;*/
                    m_VoltCaliRangePoint.m_vcRangePoint.push_back(hCaliPoint);
                }
            }
        }
    }
    else if (((CComboBox*)GetDlgItem(IDC_COMBO_Type))->GetCurSel() == 1) {
        //电压点
        //m_ListVolCaliSeg.DeleteAllItems();
        FreshListVCaliSeg();
        m_VoltCaliRangePoint.m_vcRangePoint.clear();

        MacCnnctDev_copy::CaliRangePointPrm* pCaliRangePointVolt = (MacCnnctDev_copy::CaliRangePointPrm*)&(m_RCaliRangePointPrm);
        map<float, MacCnnctDev_copy::CaliRangePointPrm::RangePoint>::iterator it_mapRealVolt;
        for (it_mapRealVolt = pCaliRangePointVolt->m_mapVoltRange.begin();
            it_mapRealVolt != pCaliRangePointVolt->m_mapVoltRange.end();
            it_mapRealVolt++)
        {
            MacCnnctDev_copy::CaliRangePointPrm::RangePoint* pVC = (MacCnnctDev_copy::CaliRangePointPrm::RangePoint*)&(it_mapRealVolt->second);
            if (pVC->m_vcRangePoint.size() > 0)
            {
                fMaxRangValue = it_mapRealVolt->first;
                for (int i = 0; i < pVC->m_vcRangePoint.size(); i++)
                {

                    MacCnnctDev_copy::CaliPointNo hCaliPoint;
                    hCaliPoint.m_fRange = fMaxRangValue;
                    hCaliPoint.m_fPoint = pVC->m_vcRangePoint[i].m_fPoint;
                    hCaliPoint.m_fPrecision = pVC->m_vcRangePoint[i].m_fPrecision;
                    /*hCaliPoint.m_wDMMNo = pVC->m_vcRangePoint[i].m_wDMMNo;
                    hCaliPoint.m_wShuntNo = pVC->m_vcRangePoint[i].m_wShuntNo;*/
                    m_VoltCaliRangePoint.m_vcRangePoint.push_back(hCaliPoint);
                }
            }
        }
}
    }

void DlgSet::FreshListVCaliSeg()
{
    int nRow = 0, nCol = 0;
    CString cstrData;
    float fValue = 0;
    m_ListVCaliSeg.DeleteAllItems();
    int m_nCurrCaliSeg;
    if (((CComboBox*)GetDlgItem(IDC_COMBO_Type))->GetCurSel() == 0) {
        m_nCurrCaliSeg = 4;
        for (map<float, CaliRangePointPrm::RangePoint>::iterator it = m_VCaliRangePointPrm.m_mapVoltRange.begin()
            ; it != m_VCaliRangePointPrm.m_mapVoltRange.end(); it++) {
            for (size_t j = 0; j < it->second.m_vcRangePoint.size(); j++) {
                CaliPointNo& mCaliPoint = it->second.m_vcRangePoint[j];
                cstrData.Format(L"%d", m_nCurrCaliSeg == 0 ? m_nCurrCaliSeg + 1 : (nRow % (m_nCurrCaliSeg + 1) + 1));
                m_ListVCaliSeg.InsertItem(nRow, cstrData); nCol++;//序号
                cstrData.Format(L"%.2f", mCaliPoint.m_fPoint);
                m_ListVCaliSeg.SetItemText(nRow, nCol, cstrData); nCol++;//校准点
                fValue = mCaliPoint.m_fPoint * mCaliPoint.m_fRange / 100;
                cstrData.Format(L"%.3f", fValue);
                m_ListVCaliSeg.SetItemText(nRow, nCol, cstrData); nCol++;//电压
                cstrData.Format(L"%.02f", mCaliPoint.m_fPrecision * 10);//千分之一
                m_ListVCaliSeg.SetItemText(nRow, nCol, cstrData); nCol++;//精度
                cstrData.Format(L"%.2f", mCaliPoint.m_fRange);
                m_ListVCaliSeg.SetItemText(nRow, nCol, cstrData); nCol++;//量程
                nRow++; nCol = 0;
            }
        }
    }
    else if (((CComboBox*)GetDlgItem(IDC_COMBO_Type))->GetCurSel() == 1) {
        m_nCurrCaliSeg = 1;
        for (map<float, CaliRangePointPrm::RangePoint>::iterator it = m_RCaliRangePointPrm.m_mapVoltRange.begin()
            ; it != m_RCaliRangePointPrm.m_mapVoltRange.end(); it++) {
            for (size_t j = 0; j < it->second.m_vcRangePoint.size(); j++) {
                CaliPointNo& mCaliPoint = it->second.m_vcRangePoint[j];
                cstrData.Format(L"%d", m_nCurrCaliSeg == 0 ? m_nCurrCaliSeg + 1 : (nRow % (m_nCurrCaliSeg + 1) + 1));
                m_ListVCaliSeg.InsertItem(nRow, cstrData); nCol++;//序号
                cstrData.Format(L"%.2f", mCaliPoint.m_fPoint);
                m_ListVCaliSeg.SetItemText(nRow, nCol, cstrData); nCol++;//校准点
                fValue = mCaliPoint.m_fPoint * mCaliPoint.m_fRange / 100;
                cstrData.Format(L"%.5f", fValue /** 1000*/);
                m_ListVCaliSeg.SetItemText(nRow, nCol, cstrData); nCol++;//电压
                cstrData.Format(L"%.02f", mCaliPoint.m_fPrecision * 10);//千分之一
                m_ListVCaliSeg.SetItemText(nRow, nCol, cstrData); nCol++;//精度
                cstrData.Format(L"%.2f", mCaliPoint.m_fRange);
                m_ListVCaliSeg.SetItemText(nRow, nCol, cstrData); nCol++;//量程
                nRow++; nCol = 0;
            }
        }
    }
    
}

void DlgSet::SetHightLowParam(const int nSegNum, const int nType, const float fAccuracy)
{
    int nMultNum = nSegNum;
    float fInc = 100.0f / nMultNum;
    if (nSegNum == 0) {
        fInc = 100;
    }
    float fValue = 0.0f;

    float fMaxRangValue = 0.0f;
    float fStandardAcc = fAccuracy;

    //手动构造

    //if (nType == 0)
    //{
    //    m_VCaliRangePointPrm.m_mapVoltRange.clear();
    //    m_VoltCaliRangePoint.m_vcRangePoint.clear();
    //    for (map<int, CString>::iterator it = m_mpVRange.begin(); it != m_mpVRange.end(); it++) {
    //        if (it->second == "6") {
    //            CaliRangePointPrm::RangePoint mRangePoint;//量程点
    //            for (size_t i = 0; i < nSegNum + 1; i++) {
    //                CaliPointNo mCaliPointNo;
    //                if (i == 0 || i == nSegNum) {
    //                    mCaliPointNo.m_fPoint = 0 + i * fInc * 2 - 100;
    //                    mCaliPointNo.m_fPoint > 0 ? mCaliPointNo.m_fPoint -= 16.666667 : mCaliPointNo.m_fPoint += 16.666667;
    //                }
    //                else {
    //                    mCaliPointNo.m_fPoint = 0 + i * fInc * 2 - 100;
    //                }

    //                mCaliPointNo.m_fRange = 6.0;
    //                mCaliPointNo.m_fPrecision = 0.01;
    //                mRangePoint.m_vcRangePoint.push_back(mCaliPointNo);
    //                m_VoltCaliRangePoint.m_vcRangePoint.push_back(mCaliPointNo);
    //            }
    //            m_CaliRangePointPrm.m_mapVoltRange[6.0] = mRangePoint;
    //        }
    //        else if (it->second == "60") {
    //            CaliRangePointPrm::RangePoint mRangePoint;//量程点
    //            for (size_t i = 0; i < nSegNum + 1; i++) {
    //                CaliPointNo mCaliPointNo;
    //                //mCaliPointNo.m_fPoint = 0 + i * fInc * 2 - 100;
    //                if (i == 0 || i == nSegNum) {
    //                    mCaliPointNo.m_fPoint = 0 + i * fInc * 2 - 100;
    //                    mCaliPointNo.m_fPoint > 0 ? mCaliPointNo.m_fPoint -= 16.666667 : mCaliPointNo.m_fPoint += 16.666667;
    //                }
    //                else {
    //                    mCaliPointNo.m_fPoint = 0 + i * fInc * 2 - 100;
    //                    if (mCaliPointNo.m_fPoint > 0) { mCaliPointNo.m_fPoint += 5; }
    //                    if (mCaliPointNo.m_fPoint < 0) { mCaliPointNo.m_fPoint -= 5; }
    //                }
    //                mCaliPointNo.m_fRange = 60.0;
    //                mCaliPointNo.m_fPrecision = 0.01;
    //                mRangePoint.m_vcRangePoint.push_back(mCaliPointNo);
    //                m_VoltCaliRangePoint.m_vcRangePoint.push_back(mCaliPointNo);
    //            }
    //            m_CaliRangePointPrm.m_mapVoltRange[60.0] = mRangePoint;
    //        }
    //    }

    //}
    //else if (nType == 1)
    //{
    //    m_RCaliRangePointPrm.m_mapVoltRange.clear();
    //    m_ResCaliRangePoint.m_vcRangePoint.clear();
    //    for (map<int, CString>::iterator it = m_mpRRange.begin(); it != m_mpRRange.end(); it++) {
    //        if (it->second == "3000") {
    //            CaliRangePointPrm::RangePoint mRangePoint;//量程点
    //            for (size_t i = 0; i < nSegNum + 1; i++) {
    //                CaliPointNo mCaliPointNo;
    //                mCaliPointNo.m_fPoint = 0 + i * /*fInc*/66.717;
    //                mCaliPointNo.m_fRange = atof(CW2A(it->second));
    //                mCaliPointNo.m_fPrecision = 0.3;
    //                mRangePoint.m_vcRangePoint.push_back(mCaliPointNo);
    //                m_VoltCheckRangePoint.m_vcRangePoint.push_back(mCaliPointNo);
    //            }
    //            m_CheckRangePointPrm.m_mapVoltRange[3000] = mRangePoint;
    //        }
    //        else if (it->second == "300") {
    //            CaliRangePointPrm::RangePoint mRangePoint;//量程点
    //            for (size_t i = 0; i < nSegNum + 1; i++) {
    //                CaliPointNo mCaliPointNo;
    //                mCaliPointNo.m_fPoint = 0 + i * /*fInc*/66.63433333;
    //                mCaliPointNo.m_fRange = atof(CW2A(it->second));
    //                mCaliPointNo.m_fPrecision = 0.3;
    //                mRangePoint.m_vcRangePoint.push_back(mCaliPointNo);
    //                m_VoltCheckRangePoint.m_vcRangePoint.push_back(mCaliPointNo);
    //            }
    //            m_CheckRangePointPrm.m_mapVoltRange[300] = mRangePoint;
    //        }
    //        else if (it->second == "30") {
    //            CaliRangePointPrm::RangePoint mRangePoint;//量程点
    //            for (size_t i = 0; i < nSegNum + 1; i++) {
    //                CaliPointNo mCaliPointNo;
    //                mCaliPointNo.m_fPoint = 0 + i * /*fInc*/66.73166667;
    //                mCaliPointNo.m_fRange = atof(CW2A(it->second));
    //                mCaliPointNo.m_fPrecision = 0.3;
    //                mRangePoint.m_vcRangePoint.push_back(mCaliPointNo);
    //                m_VoltCheckRangePoint.m_vcRangePoint.push_back(mCaliPointNo);
    //            }
    //            m_CheckRangePointPrm.m_mapVoltRange[30] = mRangePoint;
    //        }
    //        else if (it->second == "3") {
    //            CaliRangePointPrm::RangePoint mRangePoint;//量程点
    //            for (size_t i = 0; i < nSegNum + 1; i++) {
    //                CaliPointNo mCaliPointNo;
    //                mCaliPointNo.m_fPoint = 0 + i * /*fInc*/67.06866667;
    //                mCaliPointNo.m_fRange = atof(CW2A(it->second));
    //                mCaliPointNo.m_fPrecision = 0.4;
    //                mRangePoint.m_vcRangePoint.push_back(mCaliPointNo);
    //                m_VoltCheckRangePoint.m_vcRangePoint.push_back(mCaliPointNo);
    //            }
    //            m_CheckRangePointPrm.m_mapVoltRange[3] = mRangePoint;
    //        }
    //    }
    //}

    FreshCaliPrmPoint();
}

        

void DlgSet::OnBnClickedOk()
{
	// TODO: 在此添加控件通知处理程序代码
	CDialogEx::OnOK();
}


void DlgSet::OnCbnSelchangeComboType()
{
	// TODO: 在此添加控件通知处理程序代码
	//切换电阻电压
	if (((CComboBox*)GetDlgItem(IDC_COMBO_Type))->GetCurSel() == 0) {

	}
	else if (((CComboBox*)GetDlgItem(IDC_COMBO_Type))->GetCurSel() == 1) {

	}
    FreshListVCaliSeg();
}

void DlgSet::OnNMClickListVolSeg(NMHDR* pNMHDR, LRESULT* pResult)
{
    LPNMITEMACTIVATE pNMItemActivate = reinterpret_cast<LPNMITEMACTIVATE>(pNMHDR);
    // TODO: 在此添加控件通知处理程序代码
    *pResult = 0;
    if (pNMItemActivate->iItem < 0) { return; }
    CListCtrl* pListCtrl = (CListCtrl*)this->GetDlgItem(IDC_LIST_Point);
    if (pListCtrl && pListCtrl->GetSafeHwnd()) {}
    else { assert(false && "逻辑错误"); return; }

    bool bValid = false;
    float fTUR = 0;
    std::string str;
    str = CW2A((LPCWSTR)pListCtrl->GetItemText(pNMItemActivate->iItem, 4));
    fTUR = atof(str.c_str());
    //bValid = IsTURValid(fTUR);
    

    m_PointVoltSeg.x = pNMItemActivate->iItem;
    m_PointVoltSeg.y = pNMItemActivate->iSubItem;

    std::string strTemp;
    if (((CComboBox*)GetDlgItem(IDC_COMBO_Type))->GetCurSel() == 0) {
        if (1 == pNMItemActivate->iSubItem)
        {
            strTemp = CW2A((LPCWSTR)pListCtrl->GetItemText(pNMItemActivate->iItem, pNMItemActivate->iSubItem));
            MacCnnctDev_copy::CaliPointNo* pPoint = &(m_VoltCaliRangePoint.m_vcRangePoint[m_PointVoltSeg.x]);
            strTemp = MacCnnctDev_copy::Format("%.06f", pPoint->m_fPoint);
            CString cStr(strTemp.c_str());

            CEdit* pEdit = (CEdit*)pListCtrl->GetDlgItem(IDC_EDIT_VoltSeg);
            if (pEdit && pEdit->GetSafeHwnd()) {
                pEdit->SetWindowTextW(cStr);

                CRect rect;
                pListCtrl->GetSubItemRect(pNMItemActivate->iItem, pNMItemActivate->iSubItem, LVIR_BOUNDS, rect);
                pEdit->MoveWindow(rect);
                pEdit->ShowWindow(SW_SHOW);
                pEdit->SetFocus();    //设置焦点
            }
        }
        else if (2 == pNMItemActivate->iSubItem)
        {
            strTemp = CW2A((LPCWSTR)pListCtrl->GetItemText(pNMItemActivate->iItem, pNMItemActivate->iSubItem));
            MacCnnctDev_copy::CaliPointNo* pPoint = &(m_VoltCaliRangePoint.m_vcRangePoint[m_PointVoltSeg.x]);
            strTemp = MacCnnctDev_copy::Format("%.03f", pPoint->m_fPoint * pPoint->m_fRange / 100);

            CString cStr(strTemp.c_str());

            CEdit* pEdit = (CEdit*)pListCtrl->GetDlgItem(IDC_EDIT_VoltSeg);
            if (pEdit && pEdit->GetSafeHwnd()) {
                pEdit->SetWindowTextW(cStr);

                CRect rect;
                pListCtrl->GetSubItemRect(pNMItemActivate->iItem, pNMItemActivate->iSubItem, LVIR_BOUNDS, rect);
                pEdit->MoveWindow(rect);
                pEdit->ShowWindow(SW_SHOW);
                pEdit->SetFocus();    //设置焦点
            }
        }
    }
    else if (((CComboBox*)GetDlgItem(IDC_COMBO_Type))->GetCurSel() == 1) {
        if (1 == pNMItemActivate->iSubItem)
        {
            strTemp = CW2A((LPCWSTR)pListCtrl->GetItemText(pNMItemActivate->iItem, pNMItemActivate->iSubItem));
            MacCnnctDev_copy::CaliPointNo* pPoint = &(m_ResCaliRangePoint.m_vcRangePoint[m_PointVoltSeg.x]);
            strTemp = MacCnnctDev_copy::Format("%.06f", pPoint->m_fPoint);
            CString cStr(strTemp.c_str());

            CEdit* pEdit = (CEdit*)pListCtrl->GetDlgItem(IDC_EDIT_VoltSeg);
            if (pEdit && pEdit->GetSafeHwnd()) {
                pEdit->SetWindowTextW(cStr);

                CRect rect;
                pListCtrl->GetSubItemRect(pNMItemActivate->iItem, pNMItemActivate->iSubItem, LVIR_BOUNDS, rect);
                pEdit->MoveWindow(rect);
                pEdit->ShowWindow(SW_SHOW);
                pEdit->SetFocus();    //设置焦点
            }
        }
        else if (2 == pNMItemActivate->iSubItem)
        {
            strTemp = CW2A((LPCWSTR)pListCtrl->GetItemText(pNMItemActivate->iItem, pNMItemActivate->iSubItem));
            MacCnnctDev_copy::CaliPointNo* pPoint = &(m_ResCaliRangePoint.m_vcRangePoint[m_PointVoltSeg.x]);
            strTemp = MacCnnctDev_copy::Format("%.05f", pPoint->m_fPoint * pPoint->m_fRange / 100 /** 1000*/);

            CString cStr(strTemp.c_str());

            CEdit* pEdit = (CEdit*)pListCtrl->GetDlgItem(IDC_EDIT_VoltSeg);
            if (pEdit && pEdit->GetSafeHwnd()) {
                pEdit->SetWindowTextW(cStr);

                CRect rect;
                pListCtrl->GetSubItemRect(pNMItemActivate->iItem, pNMItemActivate->iSubItem, LVIR_BOUNDS, rect);
                pEdit->MoveWindow(rect);
                pEdit->ShowWindow(SW_SHOW);
                pEdit->SetFocus();    //设置焦点
            }
        }
    }
   
}

void DlgSet::OnEnKillfocusEditVoltseg()
{
    CListCtrl* pListCtrl = (CListCtrl*)this->GetDlgItem(IDC_LIST_Point);
    if (pListCtrl && pListCtrl->GetSafeHwnd()) {}
    else { assert(false && "逻辑错误"); return; }

    CEdit* pEdit = (CEdit*)pListCtrl->GetDlgItem(IDC_EDIT_VoltSeg);
    if (pEdit && pEdit->GetSafeHwnd()) {}

    pEdit->ShowWindow(SW_HIDE);
    if ((m_PointVoltSeg.x == POINIT_INVALID)
        || (m_PointVoltSeg.y == POINIT_INVALID)) {
    }

    string str;
    double dValue = 0;
    CString cstrEditValue;
    pEdit->GetWindowTextW(cstrEditValue);
    if (IsEditInputNumber(cstrEditValue))
    {
        if (((CComboBox*)GetDlgItem(IDC_COMBO_Type))->GetCurSel() == 0) {
            if (1 == m_PointVoltSeg.y)
            {
                str = CW2A(cstrEditValue);
                str = TrimSpace(str, true, true);
                if (str.length() == 0) { return; }
                CString strShow;
                dValue = 0;
                if (ShowValueToUnit(str, dValue))
                {
                    if ((dValue >= -100) && (dValue <= 500))
                    {
                        //校准点必须按照从小到大的顺序
                        double max = 500;
                        double min = -100;
                        double rate = dValue;
                        //获取校准段数
                        //CComboBox* m_VolCaliSelCmb = (CComboBox*)GetDlgItem(IDC_COMBO_CaliVSeg);
                        const int nMultIndex = 4;
                        if ((m_PointVoltSeg.x + 1) % (nMultIndex + 1) == 1)
                        {
                            //第一个点
                            CString str = (LPCWSTR)pListCtrl->GetItemText(m_PointVoltSeg.x + 1, m_PointVoltSeg.y);
                            max = atoi(CW2A(str));

                            if (rate >= max)
                            {
                                MessageBox(L"校准点设置错误!", L"警告!", MB_OK);
                                return;
                            }
                        }
                        else if ((m_PointVoltSeg.x + 1) % (nMultIndex + 1) == 0)
                        {
                            //最后一个点
                            CString str = (LPCWSTR)pListCtrl->GetItemText(m_PointVoltSeg.x - 1, m_PointVoltSeg.y);
                            min = atoi(CW2A(str));

                            if (rate <= min)
                            {
                                MessageBox(L"校准点设置错误!", L"警告!", MB_OK);
                                return;
                            }
                        }
                        else
                        {
                            //中间点
                            CString strLast = (LPCWSTR)pListCtrl->GetItemText(m_PointVoltSeg.x - 1, m_PointVoltSeg.y);
                            CString strNext = (LPCWSTR)pListCtrl->GetItemText(m_PointVoltSeg.x + 1, m_PointVoltSeg.y);
                            max = atoi(CW2A(strNext));
                            min = atoi(CW2A(strLast));

                            if (rate <= min || rate >= max)
                            {
                                MessageBox(L"校准点设置错误!", L"警告!", MB_OK);
                                return;
                            }
                        }

                        strShow.Format(_T("%02.03f"), dValue);
                        pListCtrl->SetItemText(m_PointVoltSeg.x, m_PointVoltSeg.y, strShow);
                        if (m_PointVoltSeg.x < m_VoltCaliRangePoint.m_vcRangePoint.size())
                        {
                            MacCnnctDev_copy::CaliPointNo* pPoint = &(m_VoltCaliRangePoint.m_vcRangePoint[m_PointVoltSeg.x]);

                            pPoint->m_fPoint = dValue;
                            dValue = (pPoint->m_fRange * dValue / 100.0f);

                            CString strValue;
                            strValue.Format(_T("%02.03f"), dValue);
                            pListCtrl->SetItemText(m_PointVoltSeg.x, 2, strValue);
                        }
                    }
                }
            }
            else if (2 == m_PointVoltSeg.y) {
                str = CW2A(cstrEditValue);
                str = TrimSpace(str, true, true);
                if (str.length() == 0) { return; }
                CString strShow;
                dValue = 0;
                if (ShowValueToUnit(str, dValue))
                {
                    //校准点必须按照从小到大的顺序
                    double max = 5000;
                    double min = -100;
                    if (m_PointVoltSeg.x < m_VoltCaliRangePoint.m_vcRangePoint.size())
                    {
                        MacCnnctDev_copy::CaliPointNo* pPoint = &(m_VoltCaliRangePoint.m_vcRangePoint[m_PointVoltSeg.x]);
                        max = 5 * pPoint->m_fRange;
                        min = 0 - pPoint->m_fRange;
                    }
                    else {
                        return;
                    }
                    double rate = dValue;
                    //获取校准段数
                    //CComboBox* m_VolCaliSelCmb = (CComboBox*)GetDlgItem(IDC_COMBO_CaliVSeg);
                    const int nMultIndex = 4;
                    if ((m_PointVoltSeg.x + 1) % (nMultIndex + 1) == 1)
                    {
                        //第一个点
                        CString str = (LPCWSTR)pListCtrl->GetItemText(m_PointVoltSeg.x + 1, m_PointVoltSeg.y);
                        max = atoi(CW2A(str));

                        if (rate >= max)
                        {
                            MessageBox(L"校准点设置错误!", L"警告!", MB_OK);
                            return;
                        }
                    }
                    else if ((m_PointVoltSeg.x + 1) % (nMultIndex + 1) == 0)
                    {
                        //最后一个点
                        CString str = (LPCWSTR)pListCtrl->GetItemText(m_PointVoltSeg.x - 1, m_PointVoltSeg.y);
                        min = atoi(CW2A(str));

                        if (rate <= min)
                        {
                            MessageBox(L"校准点设置错误!", L"警告!", MB_OK);
                            return;
                        }
                    }
                    else
                    {
                        //中间点
                        CString strLast = (LPCWSTR)pListCtrl->GetItemText(m_PointVoltSeg.x - 1, m_PointVoltSeg.y);
                        CString strNext = (LPCWSTR)pListCtrl->GetItemText(m_PointVoltSeg.x + 1, m_PointVoltSeg.y);
                        max = atoi(CW2A(strNext));
                        min = atoi(CW2A(strLast));

                        if (rate <= min || rate >= max)
                        {
                            MessageBox(L"校准点设置错误!", L"警告!", MB_OK);
                            return;
                        }
                    }

                    strShow.Format(_T("%02.03f"), dValue);
                    pListCtrl->SetItemText(m_PointVoltSeg.x, m_PointVoltSeg.y, strShow);
                    if (m_PointVoltSeg.x < m_VoltCaliRangePoint.m_vcRangePoint.size())
                    {
                        MacCnnctDev_copy::CaliPointNo* pPoint = &(m_VoltCaliRangePoint.m_vcRangePoint[m_PointVoltSeg.x]);

                        //pPoint->m_fPoint = dValue;
                        pPoint->m_fPoint = dValue / pPoint->m_fRange * 100.0f;

                        dValue = pPoint->m_fPoint;

                        CString strValue;
                        strValue.Format(_T("%02.03f"), dValue);
                        pListCtrl->SetItemText(m_PointVoltSeg.x, 1, strValue);
                    }
                }
            }
            else if (3 == m_PointVoltSeg.y)
            {
                str = CW2A(cstrEditValue);
                str = TrimSpace(str, true, true);
                if (str.length() == 0) { return; }
                CString strShow;
                dValue = 0;
                if (ShowValueToUnit(str, dValue))
                {
                    if ((dValue > 0) && (dValue <= 100))
                    {
                        strShow.Format(_T("%02.03f"), dValue);
                        pListCtrl->SetItemText(m_PointVoltSeg.x, m_PointVoltSeg.y, strShow);
                        if (m_PointVoltSeg.x < m_VoltCaliRangePoint.m_vcRangePoint.size())
                        {
                            MacCnnctDev_copy::CaliPointNo* pPoint = &(m_VoltCaliRangePoint.m_vcRangePoint[m_PointVoltSeg.x]);
                            pPoint->m_fPrecision = dValue / 10.0f;
                        }
                    }
                }
            }
        }
        else if (((CComboBox*)GetDlgItem(IDC_COMBO_Type))->GetCurSel() == 1) {
            if (1 == m_PointVoltSeg.y)
            {
                str = CW2A(cstrEditValue);
                str = TrimSpace(str, true, true);
                if (str.length() == 0) { return; }
                CString strShow;
                dValue = 0;
                if (ShowValueToUnit(str, dValue))
                {
                    if ((dValue >= -100) && (dValue <= 500))
                    {
                        //校准点必须按照从小到大的顺序
                        double max = 500;
                        double min = -100;
                        double rate = dValue;
                        //获取校准段数
                        //CComboBox* m_VolCaliSelCmb = (CComboBox*)GetDlgItem(IDC_COMBO_CaliVSeg);
                        const int nMultIndex = 1;
                        if ((m_PointVoltSeg.x + 1) % (nMultIndex + 1) == 1)
                        {
                            //第一个点
                            CString str = (LPCWSTR)pListCtrl->GetItemText(m_PointVoltSeg.x + 1, m_PointVoltSeg.y);
                            max = atoi(CW2A(str));

                            if (rate >= max)
                            {
                                MessageBox(L"校准点设置错误!", L"警告!", MB_OK);
                                return;
                            }
                        }
                        else if ((m_PointVoltSeg.x + 1) % (nMultIndex + 1) == 0)
                        {
                            //最后一个点
                            CString str = (LPCWSTR)pListCtrl->GetItemText(m_PointVoltSeg.x - 1, m_PointVoltSeg.y);
                            min = atoi(CW2A(str));

                            if (rate <= min)
                            {
                                MessageBox(L"校准点设置错误!", L"警告!", MB_OK);
                                return;
                            }
                        }
                        else
                        {
                            //中间点
                            CString strLast = (LPCWSTR)pListCtrl->GetItemText(m_PointVoltSeg.x - 1, m_PointVoltSeg.y);
                            CString strNext = (LPCWSTR)pListCtrl->GetItemText(m_PointVoltSeg.x + 1, m_PointVoltSeg.y);
                            max = atoi(CW2A(strNext));
                            min = atoi(CW2A(strLast));

                            if (rate <= min || rate >= max)
                            {
                                MessageBox(L"校准点设置错误!", L"警告!", MB_OK);
                                return;
                            }
                        }

                        strShow.Format(_T("%02.03f"), dValue);
                        pListCtrl->SetItemText(m_PointVoltSeg.x, m_PointVoltSeg.y, strShow);
                        if (m_PointVoltSeg.x < m_ResCaliRangePoint.m_vcRangePoint.size())
                        {
                            MacCnnctDev_copy::CaliPointNo* pPoint = &(m_ResCaliRangePoint.m_vcRangePoint[m_PointVoltSeg.x]);

                            pPoint->m_fPoint = dValue;
                            dValue = (pPoint->m_fRange * dValue / 100.0f);

                            CString strValue;
                            strValue.Format(_T("%02.03f"), dValue);
                            pListCtrl->SetItemText(m_PointVoltSeg.x, 2, strValue);
                        }
                    }
                }
            }
            else if (2 == m_PointVoltSeg.y) {
                str = CW2A(cstrEditValue);
                str = TrimSpace(str, true, true);
                if (str.length() == 0) { return; }
                CString strShow;
                dValue = 0;
                if (ShowValueToUnit(str, dValue))
                {
                    //校准点必须按照从小到大的顺序
                    double max = 5000;
                    double min = -100;
                    if (m_PointVoltSeg.x < m_ResCaliRangePoint.m_vcRangePoint.size())
                    {
                        MacCnnctDev_copy::CaliPointNo* pPoint = &(m_ResCaliRangePoint.m_vcRangePoint[m_PointVoltSeg.x]);
                        max = 5 * pPoint->m_fRange;
                        min = 0 - pPoint->m_fRange;
                    }
                    else {
                        return;
                    }
                    double rate = dValue;
                    //获取校准段数
                    //CComboBox* m_VolCaliSelCmb = (CComboBox*)GetDlgItem(IDC_COMBO_CaliVSeg);
                    const int nMultIndex = 1;
                    if ((m_PointVoltSeg.x + 1) % (nMultIndex + 1) == 1)
                    {
                        //第一个点
                        CString str = (LPCWSTR)pListCtrl->GetItemText(m_PointVoltSeg.x + 1, m_PointVoltSeg.y);
                        max = atoi(CW2A(str));

                        if (rate >= max)
                        {
                            MessageBox(L"校准点设置错误!", L"警告!", MB_OK);
                            return;
                        }
                    }
                    else if ((m_PointVoltSeg.x + 1) % (nMultIndex + 1) == 0)
                    {
                        //最后一个点
                        CString str = (LPCWSTR)pListCtrl->GetItemText(m_PointVoltSeg.x - 1, m_PointVoltSeg.y);
                        min = atoi(CW2A(str));

                        if (rate <= min)
                        {
                            MessageBox(L"校准点设置错误!", L"警告!", MB_OK);
                            return;
                        }
                    }
                    else
                    {
                        //中间点
                        CString strLast = (LPCWSTR)pListCtrl->GetItemText(m_PointVoltSeg.x - 1, m_PointVoltSeg.y);
                        CString strNext = (LPCWSTR)pListCtrl->GetItemText(m_PointVoltSeg.x + 1, m_PointVoltSeg.y);
                        max = atoi(CW2A(strNext));
                        min = atoi(CW2A(strLast));

                        if (rate <= min || rate >= max)
                        {
                            MessageBox(L"校准点设置错误!", L"警告!", MB_OK);
                            return;
                        }
                    }

                    strShow.Format(_T("%02.03f"), dValue);
                    pListCtrl->SetItemText(m_PointVoltSeg.x, m_PointVoltSeg.y, strShow);
                    if (m_PointVoltSeg.x < m_ResCaliRangePoint.m_vcRangePoint.size())
                    {
                        MacCnnctDev_copy::CaliPointNo* pPoint = &(m_ResCaliRangePoint.m_vcRangePoint[m_PointVoltSeg.x]);

                        pPoint->m_fPoint = (dValue/*/1000.0*/) / pPoint->m_fRange * 100.0f;

                        dValue = pPoint->m_fPoint;

                        CString strValue;
                        strValue.Format(_T("%02.03f"), dValue);
                        pListCtrl->SetItemText(m_PointVoltSeg.x, 1, strValue);
                    }
                }
            }
            else if (3 == m_PointVoltSeg.y)
            {
                str = CW2A(cstrEditValue);
                str = TrimSpace(str, true, true);
                if (str.length() == 0) { return; }
                CString strShow;
                dValue = 0;
                if (ShowValueToUnit(str, dValue))
                {
                    if ((dValue > 0) && (dValue <= 100))
                    {
                        strShow.Format(_T("%02.03f"), dValue);
                        pListCtrl->SetItemText(m_PointVoltSeg.x, m_PointVoltSeg.y, strShow);
                        if (m_PointVoltSeg.x < m_ResCaliRangePoint.m_vcRangePoint.size())
                        {
                            MacCnnctDev_copy::CaliPointNo* pPoint = &(m_ResCaliRangePoint.m_vcRangePoint[m_PointVoltSeg.x]);
                            pPoint->m_fPrecision = dValue / 10.0f;
                        }
                    }
                }
            }
        }
        
    }
    else
    {
        pListCtrl->SetItemText(m_PointVoltSeg.x, m_PointVoltSeg.y, _T(""));
    }

    FreshCaliPrmPoint();
}
