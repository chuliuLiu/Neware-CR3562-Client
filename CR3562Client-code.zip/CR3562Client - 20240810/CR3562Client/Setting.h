#pragma once
#include<string>
std::string strSetting = "\
[DELAY]\r\n\
r = 5\r\n\
v = 5\r\n\
[R0.002]\r\n\
err = 1000\r\n\
0 = 0.00000\r\n\
1 = 0.0020149\r\n\
[R0.02]\r\n\
err = 300\r\n\
0 = 0.00000\r\n\
1 = 0.020070\r\n\
[R0.2]\r\n\
err = 300\r\n\
0 = 0.00000\r\n\
1 = 0.19766\r\n\
[R2]\r\n\
err = 300\r\n\
0 = 0.00000\r\n\
1 = 1.9608\r\n\
[R20]\r\n\
err = 300\r\n\
0 = 0.00000\r\n\
1 = 20.0100\r\n\
[R200]\r\n\
err = 300\r\n\
0 = 0.00000\r\n\
1 = 200.100\r\n\
[V2]\r\n\
err = 5\r\n\
0 = -2.04809\r\n\
1 = -1.02407\r\n\
2 = 0.0\r\n\
3 = 1.02407\r\n\
4 = 2.04809\r\n\
[V20]\r\n\
err = 5\r\n\
0 = -20.3192\r\n\
1 = -4.09599\r\n\
2 = 0.0\r\n\
3 = 4.09598\r\n\
4 = 20.3185\r\n\
[V100]\r\n\
err = 5\r\n\
0 = -40.6377\r\n\
1 = -20.3192\r\n\
2 = 0.0\r\n\
3 = 20.3185\r\n\
4 = 40.6377\r\n\
";
//class Setting
//{
//public:
//	Setting();
//	~Setting();
//	string strSetting;
//private:
//
//};

