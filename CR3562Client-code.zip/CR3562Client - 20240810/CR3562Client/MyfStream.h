#pragma once
#include"fstream"
#include"map"
using namespace std;

class MyfStream
{
public:
	MyfStream();
	~MyfStream();

private:
	fstream infile;//
	CString m_strFilePath;
	const DWORD BUF_SIZE = 0x800000;//8M �����С
	
	__int64 nbufdiffLen;//�޸ĵ�ַ��ƫ�Ƴ���
	BYTE* m_buf;//������
	bool bLoadfile;//�Ƿ�����ļ�
public:
	__int64 nbuffileLen;//�ļ�����
	/*t_sUpdateData*/vector<t_sUpdatePerData> m_sUpdateData;
	st_CaliFile m_st_CaliFile;
public:
	const bool LoadFileStream(CString cstrFilePath);
	const bool CloseFileStream();

	//t_sUpdateData
	const bool GetUpdateData(string& strErr);
	const bool GetHead(string& strErr);
	const bool GetBody(string& strErr);
	const bool GetBuffer(byte* pBuf, const unsigned int nOffset, const unsigned int nBufLen);
	const bool GetCR3562UpdateFile(string& strErr);

	//caliFile
	const bool GetCaliUpdateData(string& strErr);
	const bool GetCaliHead(string& strErr);
	const bool GetCaliBody(string& strErr);
	const bool GetCaliBuffer(byte* pBuf, const unsigned int nOffset, const unsigned int nBufLen);

	const int GetTYPE();
	const DWORD GetVer();
	const string GetBuildDate();//��ȡת���������
	const string GetBuildTime();//��ȡת�����ʱ��
};


