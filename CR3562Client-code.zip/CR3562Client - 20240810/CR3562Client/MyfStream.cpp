#include"pch.h"
#include "framework.h"
#include "CR3562Client.h"
#include "CR3562ClientDlg.h"
#include"MyfStream.h"


MyfStream::MyfStream()
{
	m_buf = new BYTE[BUF_SIZE];
	memset(m_buf, 0, BUF_SIZE);
	bLoadfile = false;
	nbufdiffLen = 0x300;
	//m_sUpdateData.pucData = NULL;
}

MyfStream::~MyfStream()
{
	if (infile.is_open()) {
		infile.close();
	}
	//if (m_sUpdateData.pucData) {
	//	delete m_sUpdateData.pucData;
	//	m_sUpdateData.pucData = NULL;
	//}
	if (m_buf) {
		delete[] m_buf;
		m_buf = NULL;
	}
}

const bool MyfStream::LoadFileStream(CString cstrFilePath)
{
	m_strFilePath = cstrFilePath;
	infile.open(m_strFilePath, ios::binary | ios::in | ios::out);//!infile.is_open()
	if (infile.is_open()) {
		infile.seekg(0, ios::end);
		nbuffileLen = infile.tellg();
		infile.seekg(0, ios::beg);
		return true;
	}
	else
		return false;
}

const bool MyfStream::CloseFileStream()
{
	if (infile.is_open()) {
		infile.close();
	}
	memset(m_buf,0,sizeof(m_buf));
	bLoadfile = false;
	//if (m_sUpdateData.pucData) {
	//	delete m_sUpdateData.pucData;
	//	m_sUpdateData.pucData = NULL;
	//}
	return true;
}

const bool MyfStream::GetUpdateData(string& strErr)
{

	//if (!GetHead(strErr)) {
	//	return false;
	//}

	//if (!GetBody(strErr)) {
	//	return false;
	//}
	if (!GetCR3562UpdateFile(strErr)) {
		return false;
	}

	infile.seekg(0, ios::beg);
	memset(m_buf, 0, BUF_SIZE);
	infile.read((char*)m_buf, nbuffileLen);
	if (infile.is_open()) {
		infile.close();
	}
	return true;
}

//const bool MyfStream::GetHead(string& strErr)
//{
//	if (nbuffileLen < 123) {
//		strErr = "�ļ�����С��Head";
//		return false;
//	}
//	infile.seekg(0, ios::beg);
//	memset(m_buf, 0, BUF_SIZE);
//	infile.read((char*)m_buf, nbuffileLen<BUF_SIZE? nbuffileLen: BUF_SIZE);
//	byte* buf = m_buf;
//
//	m_sUpdateData.unBeginFlag = *(int*)buf;
//	buf += sizeof(int);
//	if (m_sUpdateData.unBeginFlag != 0xFF5555FF) {
//		strErr = "��ʼ��־��ƥ��";
//		return false;
//	}
//
//	m_sUpdateData.unPackLen = *(int*)buf;
//	buf += sizeof(int);
//	if (m_sUpdateData.unPackLen != nbuffileLen) {
//		strErr = "�ļ������쳣";
//		return false;
//	}
//
//	m_sUpdateData.ucType = *(byte*)buf;
//	buf += sizeof(byte);
//
//	m_sUpdateData.usDataOffset = *(short*)buf;
//	buf += sizeof(short);
//
//	m_sUpdateData.unDataLen = *(int*)buf;
//	buf += sizeof(int);
//	if ((m_sUpdateData.usDataOffset + m_sUpdateData.unDataLen + sizeof(int) + sizeof(int)) != nbuffileLen) {
//		strErr = "����ƫ��������ʵ�ʳ���ֵ�����쳣";
//		return false;
//	}
//
//	m_sUpdateData.usVersion = *(int*)buf;
//	buf += sizeof(int);
//
//	//Date
//	m_sUpdateData.unBuildDate = *(int*)buf;
//	buf += sizeof(int);
//
//	m_sUpdateData.unBuildTime = *(int*)buf;
//	buf += sizeof(int);
//
//	for (size_t i = 0; i < sizeof(m_sUpdateData.pucReserve); i++)
//	{//Ԥ���ռ�
//		m_sUpdateData.pucReserve[i] = *(byte*)buf;
//		buf += sizeof(byte);
//	}	
//
//	m_sUpdateData.unHeadCRC32 = *(int*)buf;
//	buf += sizeof(int);
//
//	buf = m_buf;
//	buf+= sizeof(int);
//	DWORD dwLen = sizeof(int) + sizeof(byte) + sizeof(short) + sizeof(int) + sizeof(int) + sizeof(int) + sizeof(int) + sizeof(m_sUpdateData.pucReserve);
//	unsigned int nHeadCrc32 = CalcCrc32FromBuf(buf, dwLen);
//	if (nHeadCrc32 != m_sUpdateData.unHeadCRC32) {
//		strErr = "ͷCRC32����";
//		return false;
//	}
//	return true;
//}
//
//const bool MyfStream::GetBody(string& strErr)
//{
//	byte* buf = m_buf;
//	m_sUpdateData.pucData = new unsigned char[m_sUpdateData.unDataLen];
//	memset(m_sUpdateData.pucData, 0, sizeof(m_sUpdateData.pucData));
//	if (nbuffileLen < BUF_SIZE) {
//		buf += m_sUpdateData.usDataOffset;
//		memcpy(m_sUpdateData.pucData, buf, m_sUpdateData.unDataLen);
//		buf += m_sUpdateData.unDataLen;
//
//		m_sUpdateData.unDataCRC32 = *(int*)buf;
//		buf += sizeof(int);
//
//		m_sUpdateData.unEndFlag = *(int*)buf;
//		buf += sizeof(int);
//		if (m_sUpdateData.unEndFlag != 0xFFAAAAFF) {
//			strErr = "������׼��ƥ��";
//			return false;
//		}
//	}
//	else {
//		int nSeg = (nbuffileLen - m_sUpdateData.usDataOffset) / BUF_SIZE + ((nbuffileLen - m_sUpdateData.usDataOffset) % BUF_SIZE > 0 ? 1 : 0);
//		for (size_t i = 0; i < nSeg - 1; i++)
//		{
//			infile.seekg(i * BUF_SIZE + m_sUpdateData.usDataOffset, ios::beg);
//			memset(m_buf, 0, BUF_SIZE);
//			infile.read((char*)m_buf, BUF_SIZE);
//			buf = m_buf;
//			memcpy(m_sUpdateData.pucData + i* BUF_SIZE, buf, BUF_SIZE);
//		}
//		infile.seekg((nSeg-1) * BUF_SIZE + m_sUpdateData.usDataOffset, ios::beg);
//		memset(m_buf, 0, BUF_SIZE);
//		infile.read((char*)m_buf, BUF_SIZE);
//		buf = m_buf;
//		memcpy(m_sUpdateData.pucData + (nSeg - 1) * BUF_SIZE, buf, m_sUpdateData.unDataLen - (nSeg - 1) * BUF_SIZE);
//		buf += m_sUpdateData.unDataLen - (nSeg - 1) * BUF_SIZE;
//
//		m_sUpdateData.unDataCRC32 = *(int*)buf;
//		buf += sizeof(int);
//
//		m_sUpdateData.unEndFlag = *(int*)buf;
//		buf += sizeof(int);
//		if (m_sUpdateData.unEndFlag != 0xFFAAAAFF) {
//			strErr = "������׼��ƥ��";
//			return false;
//		}		
//	}
//	DWORD dwLen = m_sUpdateData.unDataLen;
//	buf = m_sUpdateData.pucData;
//	unsigned int nBodyCrc32 = CalcCrc32FromBuf(buf, dwLen);
//	if (nBodyCrc32 != m_sUpdateData.unDataCRC32) {
//		strErr = "����CRC32����";
//		return false;
//	}
//	return true;
//}

const bool MyfStream::GetBuffer(byte* pBuf, const unsigned int nOffset, const unsigned int nBufLen)
{
	//infile.seekg(nOffset, ios::beg);
	byte* pbuf = m_buf;
	//memset(m_buf, 0, BUF_SIZE);
	//infile.read((char*)m_buf, nBufLen);
	//pBuf = m_buf;
	pbuf += nOffset;
	memcpy(pBuf, pbuf, nBufLen);
	return true;
}

const bool MyfStream::GetCR3562UpdateFile(string& strErr)
{
	/*if (nbuffileLen > 1024) {
		strErr = "�ļ�����";
		return false;
	}*/
	infile.seekg(0, ios::beg);
	memset(m_buf, 0, BUF_SIZE);
	infile.read((char*)m_buf, nbuffileLen < BUF_SIZE ? nbuffileLen : BUF_SIZE);
	byte* buf = m_buf;
	char cbuf[1024];
	memset(cbuf, 0, sizeof(cbuf));

	unsigned int unFileVer;
	unsigned int unFileLen;

	//unFileVer = *(int*)buf;
	//buf += sizeof(int);

	//�жϰ汾�Ƿ���Ҫ��������

	unFileLen = nbuffileLen;

	m_sUpdateData.clear();
	int nFileSeg = unFileLen / 128 + (unFileLen % 128 > 0 ? 1 : 0);
	
	vector<t_sUpdatePerData> sUpdateData;
	sUpdateData.resize(nFileSeg);
	for (size_t i = 0; i < nFileSeg; i++)
	{
		buf = m_buf;
		memset(sUpdateData[i].pucData, 0, sizeof(sUpdateData[i].pucData));

		sUpdateData[i].unBeginFlag = 0x5555;
		sUpdateData[i].unPackIndex = i;
		if (i == nFileSeg - 1) {
			sUpdateData[i].unPackIndex = 0xFFFF;
		}
		buf += i * 128;
		sUpdateData[i].unPackLen = (unFileLen  - i * 128) >= 128 ? 128 : (unFileLen - i * 128);
		memset(sUpdateData[i].pucData, 0, sizeof(sUpdateData[i].pucData));
		memcpy((void*)sUpdateData[i].pucData, (void*)buf, sUpdateData[i].unPackLen);
		memset(cbuf, 0, sizeof(cbuf));
		char* pBuf = cbuf;
		*(WORD*)pBuf = sUpdateData[i].unPackIndex;
		pBuf += sizeof(WORD);
		*(WORD*)pBuf = sUpdateData[i].unPackLen;
		pBuf += sizeof(WORD);
		memcpy(pBuf, sUpdateData[i].pucData, sizeof(sUpdateData[i].pucData));

		sUpdateData[i].unDataCRC32 = calc_crc16_with_init(cbuf, sizeof(WORD) * 2 + 128/*sUpdateData[i].unPackLen*/,0XFFFF);
		sUpdateData[i].unEndFlag = 0xAAAA;
	}
	swap(m_sUpdateData, sUpdateData);
	return true;
}

const bool MyfStream::GetCaliUpdateData(string& strErr)
{
	//��֤У׼�ļ�head����

	//��֤У׼�ļ�body����
	infile.seekg(0, ios::beg);
	memset(m_buf, 0, BUF_SIZE);
	infile.read((char*)m_buf, nbuffileLen);
	if (infile.is_open()) {
		infile.close();
	}
	unsigned long nLen = m_st_CaliFile.Decode((byte*)m_buf, nbuffileLen);
	if (nLen != nbuffileLen) {
		return false;
	}
	else {
		return true;
	}	
}

const int MyfStream::GetTYPE()
{
	return /*m_sUpdateData.ucType*/0;
}

const DWORD MyfStream::GetVer()
{
	return /*m_sUpdateData.usVersion*/0;
}

const string MyfStream::GetBuildDate()
{
	string strDate,strOutput="";
	/*if (m_sUpdateData.unBuildDate == 0) {
		strOutput = "";
	}
	else {
		strOutput = "�����ļ��������ڣ�20";
		strDate = UintToHexStr(m_sUpdateData.unBuildDate);
		BYTE nA = 0, nB = 0, nC = 0;
		string strData = strDate.substr(2, 2);
		unsigned char buf[2] = { 0 };
		unsigned long nDataLen = 0;
		if (HexNoSpaceStrToBuf(strData, buf, sizeof(buf), nDataLen)) {
			nA = *(unsigned long*)((BYTE*)buf);
		}
		else {
			assert(false && "ת������ɫֵʧ��!");
		}
		memset(buf, 0, sizeof(buf));
		strData = strDate.substr(4, 2);
		if (HexNoSpaceStrToBuf(strData, buf, sizeof(buf), nDataLen)) {
			nB = *(unsigned long*)((BYTE*)buf);
		}
		else {
			assert(false && "ת������ɫֵʧ��!");
		}
		strData = strDate.substr(6, 2);
		if (HexNoSpaceStrToBuf(strData, buf, sizeof(buf), nDataLen)) {
			nC = *(unsigned long*)((BYTE*)buf);
		}
		else {
			assert(false && "ת������ɫֵʧ��!");
		}
		strDate = MacCnnctDev_copy::Format("%02d-%02d-%02d", nA, nB, nC);
		strOutput += strDate;

		
	}*/	
	return strOutput;
}

const string MyfStream::GetBuildTime()
{
	string strTime = "",strOutput="";
	/*if (m_sUpdateData.unBuildTime == 0) {

	}
	else {
		strOutput = " ";
		strTime = UintToHexStr(m_sUpdateData.unBuildTime);
		BYTE nA = 0, nB = 0, nC = 0;
		string strData = strTime.substr(2, 2);
		unsigned char buf[2] = { 0 };
		unsigned long nDataLen = 0;
		if (HexNoSpaceStrToBuf(strData, buf, sizeof(buf), nDataLen)) {
			nA = *(unsigned long*)((BYTE*)buf);
		}
		else {
			assert(false && "ת������ɫֵʧ��!");
		}
		memset(buf, 0, sizeof(buf));
		strData = strTime.substr(4, 2);
		if (HexNoSpaceStrToBuf(strData, buf, sizeof(buf), nDataLen)) {
			nB = *(unsigned long*)((BYTE*)buf);
		}
		else {
			assert(false && "ת������ɫֵʧ��!");
		}
		strData = strTime.substr(6, 2);
		if (HexNoSpaceStrToBuf(strData, buf, sizeof(buf), nDataLen)) {
			nC = *(unsigned long*)((BYTE*)buf);
		}
		else {
			assert(false && "ת������ɫֵʧ��!");
		}
		strTime = MacCnnctDev_copy::Format("%02d:%02d:%02d", nA, nB, nC);
		strOutput += strTime;
	}*/
	

	return strOutput;
}
