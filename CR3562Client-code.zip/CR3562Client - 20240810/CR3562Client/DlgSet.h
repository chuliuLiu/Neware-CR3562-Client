﻿#pragma once
#include "afxdialogex.h"


// DlgSet 对话框

class DlgSet : public CDialogEx
{
	DECLARE_DYNAMIC(DlgSet)

public:
	DlgSet(CWnd* pParent = nullptr);   // 标准构造函数
	virtual ~DlgSet();

// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_DLG_SET };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 支持
	virtual BOOL OnInitDialog();
	DECLARE_MESSAGE_MAP()
public:
	POINT m_PointVoltSeg;//最后所选择的seg行
	CaliRangePointPrm m_VCaliRangePointPrm;//校准参数
	CaliRangePointPrm m_RCaliRangePointPrm;//校准参数
	CaliRangePointPrm::RangePoint m_VoltCaliRangePoint;
	CaliRangePointPrm::RangePoint m_ResCaliRangePoint;
public:
	//从主函数中获取，返回主函数并存到配置
	void GetRangePoint(CaliRangePointPrm& vPoint, CaliRangePointPrm& rPoint);
	void SaveRangePointToLocal();//存配置到本地
	//绘制列表

	const bool IsEditInputNumber(const CString& cstrNumber);
	bool ShowValueToUnit(const string& strValue, double& dValue);
	void FreshCaliPrmPoint();
	void GetVoltCaliSegParam();
	void FreshParamDataList();
	void FreshListVCaliSeg();//刷新电压校准分段表
	void SetHightLowParam(const int nSegNum/* 段数 */, const int nType/* 类型(电压/电流) */, const float fAccuracy = 10.f/* 精度 */);
public:
	afx_msg void OnBnClickedOk();
	afx_msg void OnCbnSelchangeComboType();
	afx_msg void OnNMClickListVolSeg(NMHDR* pNMHDR, LRESULT* pResult);//左键支持分段校准点调整
	afx_msg void OnEnKillfocusEditVoltseg();
	CListCtrl m_ListVCaliSeg;
};
