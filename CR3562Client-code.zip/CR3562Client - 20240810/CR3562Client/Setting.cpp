#include "pch.h"
//#include "Setting.h"

//Setting::Setting()
//{
//	
//}
