#include"pch.h"
#include"MacCnnctDev_Copy.h"
#include "CR3562Client.h"
#include "CR3562ClientDlg.h"
#include <vector>
#include <string>
#include <regex>
using namespace std;

namespace MacCnnctDev_copy
{ 
MeterMidInfo::MeterMidInfo()
{
    m_wDevID = 0;//�豸��
    memset((void*)m_vbtIP, 0, sizeof(m_vbtIP));
    m_wPort = 0;//�˿ں�
    memset((void*)m_chSN, 0, sizeof(m_chSN));//�豸���к�, "A-34410A-22034"
}
const unsigned long MeterMidInfo::Encode(BYTE* pData, const unsigned long nMaxLen, string& strError) const
{
    //�������ݽṹ�������������
    //��ʧ��, �򷵻�0, ��ɹ�, �򷵻ش��������ݳ���
    BYTE* pBuf = pData;

    const unsigned long nMinLen = (sizeof(unsigned short) + sizeof(BYTE) * 4
        + sizeof(unsigned short) + sizeof(char) * 32) + sizeof(BYTE);
    if (nMaxLen < nMinLen) {
        /*strError = Format("��������С: %d, ����: %d",
            nMaxLen, nMinLen);*/
        return 0;
    }

    *(unsigned short*)pBuf = m_wDevID;//�豸��
    pBuf += sizeof(unsigned short);

    memcpy((void*)pBuf, (void*)m_vbtIP, sizeof(m_vbtIP));//IP
    pBuf += sizeof(m_vbtIP);

    *(unsigned short*)pBuf = m_wPort;//�˿ں�
    pBuf += sizeof(unsigned short);

    memcpy((void*)pBuf, (void*)m_chSN, sizeof(m_chSN));//SN
    pBuf += sizeof(m_chSN);

    *(BYTE*)pBuf = m_eMeterType;
    pBuf += sizeof(BYTE);

    return (pBuf - pData);
}
const unsigned long MeterMidInfo::Decode(const BYTE* pData, const unsigned long nMaxLen, string& strError)
{
    //�ӻ��������й��챾���ݽṹ
    //��ʧ��, �򷵻�0, ��ɹ�, �򷵻ر���������ݳ���
    const BYTE* pBuf = pData;

    const unsigned long nMinLen = (sizeof(unsigned short) + sizeof(BYTE) * 4
        + sizeof(unsigned short) + sizeof(char) * 32) + sizeof(BYTE);
    if (nMaxLen < nMinLen) {
        /*strError = Format("��������С: %d, ����: %d",
            nMaxLen, nMinLen);*/
        return 0;
    }

    m_wDevID = *(unsigned short*)pBuf;//�豸��
    pBuf += sizeof(unsigned short);

    memcpy((void*)m_vbtIP, (void*)pBuf, sizeof(m_vbtIP));//IP
    pBuf += sizeof(m_vbtIP);

    m_wPort = *(unsigned short*)pBuf;//�˿ں�
    pBuf += sizeof(unsigned short);

    memcpy((void*)m_chSN, (void*)pBuf, sizeof(m_chSN));
    pBuf += sizeof(m_chSN);

    m_eMeterType = *(BYTE*)pBuf;
    pBuf += sizeof(BYTE);

    return (pBuf - pData);
}
const string MeterMidInfo::ToStr() const
{
    string strRtrn = "";
    /*string strRtrn = Format("%s: NUID: 0x%08X, ��ַ: %d.%d.%d.%d, �˿ں�: %hu",
        __FUNCTION__, (DWORD)m_wDevID, m_vbtIP[0], m_vbtIP[1], m_vbtIP[2], m_vbtIP[3], m_wPort);*/
    return strRtrn;
}
const bool MeterMidInfo::ToXML(TiXmlNode* pPrnt, string& strError) const
{
    /*if (NULL == pPrnt) {
        strError = "pPrnt �ڵ�Ϊ NULL";
        return false;
    }
    TiXmlNode* pMeterDevNode = pPrnt->InsertEndChild(TiXmlElement(this->XMLNodeName()));
    pMeterDevNode->ToElement()->SetAttribute("MeterDevID", Misc::IntToStr(m_wDevID));
    const string strDevIP = UintToStr(m_vbtIP[0]) + "." + UintToStr(m_vbtIP[1]) + "."
        + UintToStr(m_vbtIP[2]) + "." + UintToStr(m_vbtIP[3]);
    pMeterDevNode->ToElement()->SetAttribute("MeterDevIP", strDevIP);
    pMeterDevNode->ToElement()->SetAttribute("Port", Misc::IntToStr(m_wPort));
    pMeterDevNode->ToElement()->SetAttribute("SN", Misc::CharBufToStr((const unsigned char*)m_chSN, sizeof(m_chSN)));
    pMeterDevNode->ToElement()->SetAttribute("MeterID", m_strATLID);
    pMeterDevNode->ToElement()->SetAttribute("MeterType", UintToStr(m_eMeterType));
    pMeterDevNode->ToElement()->SetAttribute("Eff.Data", m_strATLEffData);*/
    return true;
}
const bool MeterMidInfo::FromXML(const TiXmlNode* pMeterDevNode, string& strError)
{
    //const char* pstrTxt = NULL;
    //unsigned long nDataLen = 0;
    //if (NULL == pMeterDevNode) {
    //    strError = "pMeterDevNode Ϊ NULL";
    //    return false;
    //}

    //pstrTxt = pMeterDevNode->ToElement()->Attribute("MeterDevID");
    //if (!pstrTxt) {
    //    strError = "pMeterDevNode �� DevID ����";
    //    return false;
    //}
    //m_wDevID = atoi(pstrTxt);

    //pstrTxt = pMeterDevNode->ToElement()->Attribute("MeterDevIP");
    //if (!pstrTxt) {
    //    strError = "pMeterDevNode �� MeterDevIP ����";
    //    return false;
    //}
    //if (Misc::StrIPToBuf(string(pstrTxt).c_str(), m_vbtIP, sizeof(m_vbtIP), nDataLen)) {}
    //else {
    //    strError = "DevIP ����ֵת������Ӧ������ʧ��";
    //    return false;
    //}

    //pstrTxt = pMeterDevNode->ToElement()->Attribute("Port");
    //if (!pstrTxt) {
    //    strError = "pMeterDevNode �� Port ����";
    //    return false;
    //}
    //m_wPort = atoi(pstrTxt);

    //pstrTxt = pMeterDevNode->ToElement()->Attribute("SN");
    //if (!pstrTxt) {
    //    strError = "pMeterDevNode �� SN ����";
    //    return false;
    //}

    //string strSN = string(pstrTxt);
    //if (strSN.length() > sizeof(m_chSN)) {
    //    strError = "SN ����ֵ���ȳ���������";
    //    return false;
    //}
    //memcpy(m_chSN, strSN.c_str(), strSN.length());

    //pstrTxt = pMeterDevNode->ToElement()->Attribute("MeterID");
    //if (!pstrTxt) {
    //    //strError = string(__FUNCTION__) + ": pMeterDevNode �� MeterID ����";
    //}
    //else { m_strATLID = string(pstrTxt); }

    //pstrTxt = pMeterDevNode->ToElement()->Attribute("Eff.Data");
    //if (!pstrTxt) {
    //    //strError = string(__FUNCTION__) + ": pMeterDevNode �� Eff.Data ����";
    //}
    //else { m_strATLEffData = string(pstrTxt); }

    //pstrTxt = pMeterDevNode->ToElement()->Attribute("MeterType");
    //if (!pstrTxt) {
    //    //strError = string(__FUNCTION__) + ": pMeterDevNode �� MeterType ����";
    //}
    //else { m_eMeterType = atoi(pstrTxt); }
    return true;
}

string MeterMidInfo::GetStrSN()
{
    string strData = m_chSN;
    if (strData.find(',') != string::npos) {
        int nPos = strData.find(',');
        strData = strData.substr(nPos + 1, strData.length());
        if (strData.find(',') != string::npos) {
            nPos = strData.find(',');
            strData = strData.substr(nPos + 1, strData.length());
            if (strData.find(',') != string::npos) {
                nPos = strData.find(',');
                strData = strData.substr(0, nPos);
            }
        }
    }
    return strData;
}

string MeterMidInfo::GetStrDEVType()
{
    string strData = m_chSN;
    if (strData.find(',') != string::npos) {
        int nPos = strData.find(',');
        strData = strData.substr(nPos + 1, strData.length());
        if (strData.find(',') != string::npos) {
            nPos = strData.find(',');
            strData = strData.substr(0, nPos);
        }
    }
    return strData;
}

string MeterMidInfo::GetStrName()
{
    string strData = m_chSN;
    if (strData.find(',') != string::npos) {
        int nPos = strData.find(',');
        strData = strData.substr(0, nPos);
    }
    return strData;
}

string MeterMidInfo::GetNuid()
{
    string strData = m_chSN;
    if (strData.find(',') != string::npos) {
        int nPos = strData.find(',');
        strData = strData.substr(nPos + 1, strData.length());
        if (strData.find(',') != string::npos) {
            nPos = strData.find(',');
            strData = strData.substr(nPos + 1, strData.length());
            if (strData.find(',') != string::npos) {
                nPos = strData.find(',');
                strData = strData.substr(0, nPos);
            }
        }
    }
    return strData;
}

PkgMac::PkgMac()
{
    m_dwCrc = 0;//CRC-32У����: ����һ�ֶο�ʼ����β, �������ܴ��ڵ�[�豸˽��������չ], �������ֽ���У��
    m_wPackLen = 0;//�������ݰ������ֽ���, �������ܴ��ڵ�[�豸˽��������չ]
    m_wCmdID = 0;//����ָ��: 0x0001-��; 0x0002-д; 0x0003-����
    m_wDevType = 0;//�豸����: 0x0001 ֻ���ֶ�
    m_wSubType = 0;//���豸����: 0x0001 �ж��ֶ�
    m_wDevVer = 0;//�豸�汾: 0x0001 ֻ���ֶ�
    m_wHardVer = 0;//Ӳ���汾: 0x001 ֻ���ֶ�
    m_dwNuid = 0;//NUID ֻ���ֶ�
    m_wWorkStatus = 0;//�豸״̬: 0x0000, ֻ���ֶ�, ����Ϊ 0 ʱ, ����ʹ��, ��ֹʹ��
    m_wDiscoverVer = 0;//Э��汾
    memset((void*)m_vbtDevMac, 0, sizeof(m_vbtDevMac));//BYTE m_ucDevMac[6];//�豸��MAC��ַ; ȫ0��ʾ��Чֵ���޸�, ȫF��ʾ�㲥
    m_wDevID = 0;//unsigned char m_btDevID;//�豸���
    m_dwDevIpMode = 0;//�豸IP��ȡ�÷�ʽ: 1-��̬IP; 2-��̬IP
    memset((void*)m_vbtDevIP, 0, sizeof(m_vbtDevIP));//DWORD m_dwDevIp;//�豸��IP��ַ
    memset((void*)m_vbtMask, 0, sizeof(m_vbtMask));//DWORD m_dwDevSnm;//�豸����������
    memset((void*)m_vbtGateway, 0, sizeof(m_vbtGateway));//DWORD m_dwDevGateway;//�豸�����ص�ַ
    memset((void*)m_vbtPcIP, 0, sizeof(m_vbtPcIP));//DWORD m_dwServerIp;//��������IP��ַ
    m_wSrvPort = 0;//WORD m_wServerPort;//�������Ķ˿�
    m_wIsTcp = 0;//WORD m_wSocketType;//ͨѶsocket����: 1-TCP, 2-UDP
    m_wDebugPort = 0;//WORD m_wDevPort;//�豸�Ķ˿�
    m_wTagReg = 0;//�豸�ṩ��һ�����������ɶ���д�ı�ǩ�Ĵ���
    memset((void*)m_vcSN, 0, sizeof(m_vcSN));//�豸 SN ��
}
const string PkgMac::ToStr() const
{
    string strRtrn;
    strRtrn = Format("%s: CRC32: 0x%08X", __FUNCTION__, m_dwCrc)
        + Format(", ���ݰ�����: %hd", m_wPackLen)
        + Format(", ����ָ��(0x0001-��; 0x0002-д; 0x0003-����): 0x%04X", m_wCmdID)
        /*+ Format(", �豸����: %s", Misc::EnumDevTypeToStr((BYTE)m_wDevType).c_str())*/
        + Format(", ���豸����: 0x%04X", m_wSubType)
        + Format(", �豸�汾: 0x%04X", m_wDevVer)
        + Format(", Ӳ���汾: 0x%04X", m_wHardVer)
        + Format(", ״̬: 0x%04X", m_wWorkStatus)
        + Format(", DiscoverVer: 0x%04X", m_wDiscoverVer)
        /*+ Format(", MAC��ַ(ȫ0��ʾ��Чֵ���޸ģ�ȫF��ʾ�㲥): %s",
            Misc::BufToHexStr((const unsigned char*)m_vbtDevMac, sizeof(m_vbtDevMac)).c_str())*/
        + Format(", �豸���: %hd", m_wDevID)
        + Format(", IP��ʽ(1-��̬IP; 2-��̬IP): %u", m_dwDevIpMode)
        + Format(", IP: %d.%d.%d.%d, ����: %d.%d.%d.%d, ���ص�ַ: %d.%d.%d.%d, ���Զ˿�: %hd",
            m_vbtDevIP[0], m_vbtDevIP[1], m_vbtDevIP[2], m_vbtDevIP[3],
            m_vbtMask[0], m_vbtMask[1], m_vbtMask[2], m_vbtMask[3],
            m_vbtGateway[0], m_vbtGateway[1], m_vbtGateway[2], m_vbtGateway[3],
            m_wDebugPort)
        + Format(", ������IP: %d.%d.%d.%d, �˿�: %u",
            m_vbtPcIP[0], m_vbtPcIP[1], m_vbtPcIP[2], m_vbtPcIP[3],
            m_wSrvPort)
        + Format(", ��ǩ�Ĵ�: 0x%04X", m_wTagReg)
        /*+ Misc::BufToHexStr(m_vcSN, sizeof(m_vcSN))*/;
    return strRtrn;
}
const unsigned long PkgMac::Encode(unsigned char* pData, const unsigned long nMaxLen,
    string& strError) const
{
    //bCSPack: Ϊ true ��ʾ�ͻ���������Ĵ�����, �����ԭʼ MAC ��ַ�ֶ�
    unsigned char* pBuf = pData;
    unsigned long nPackLen = 76;
    if (nMaxLen < nPackLen) {
        strError = Format("��Ч���ݰ�����: %d, ��ָ���ݰ����벻С��: %d",
            nMaxLen, nPackLen);
        return 0;
    }

    *(DWORD*)pBuf = m_dwCrc;
    pBuf += sizeof(DWORD);

    *(WORD*)pBuf = m_wPackLen;
    pBuf += sizeof(WORD);

    if ((m_wCmdID != MAC_CMD_READ)
        && (m_wCmdID != MAC_CMD_READ_RESP)
        && (m_wCmdID != MAC_CMD_WRITE)
        && (m_wCmdID != MAC_CMD_WRITE_RESP)
        && (m_wCmdID != MAC_CMD_TEST)
        && (m_wCmdID != MAC_CMD_TEST_RESP)) {
        assert(false && "��Ч������");
        strError = Format("��Ч������: %04X",
            m_wCmdID);
        return 0;
    }

    *(WORD*)pBuf = m_wCmdID;
    pBuf += sizeof(WORD);

    *(WORD*)pBuf = m_wDevType;
    pBuf += sizeof(WORD);

    *(WORD*)pBuf = m_wSubType;
    pBuf += sizeof(WORD);

    *(WORD*)pBuf = m_wDevVer;
    pBuf += sizeof(WORD);

    *(WORD*)pBuf = m_wHardVer;
    pBuf += sizeof(WORD);

    DWORD dwNuid = m_dwNuid;
    SwapBuf((BYTE*)&dwNuid, sizeof(DWORD));
    *(DWORD*)pBuf = dwNuid;
    //SwapBuf(pBuf, sizeof(m_dwNuid));
    pBuf += sizeof(DWORD);

    *(WORD*)pBuf = m_wWorkStatus;
    pBuf += sizeof(WORD);

    *(WORD*)pBuf = m_wDiscoverVer;
    pBuf += sizeof(WORD);

    memcpy((void*)pBuf, m_vbtDevMac, sizeof(m_vbtDevMac));
    pBuf += sizeof(m_vbtDevMac);

    *(WORD*)pBuf = m_wDevID;
    pBuf += sizeof(WORD);

    *(DWORD*)pBuf = m_dwDevIpMode;
    pBuf += sizeof(DWORD);

    memcpy((void*)pBuf, m_vbtDevIP, sizeof(m_vbtDevIP));
    SwapBuf(pBuf, sizeof(m_vbtDevIP));
    pBuf += sizeof(m_vbtDevIP);

    memcpy((void*)pBuf, m_vbtMask, sizeof(m_vbtMask));
    SwapBuf(pBuf, sizeof(m_vbtMask));
    pBuf += sizeof(m_vbtMask);

    memcpy((void*)pBuf, m_vbtGateway, sizeof(m_vbtGateway));
    SwapBuf(pBuf, sizeof(m_vbtGateway));
    pBuf += sizeof(m_vbtGateway);

    memcpy((void*)pBuf, m_vbtPcIP, sizeof(m_vbtPcIP));
    SwapBuf(pBuf, sizeof(m_vbtPcIP));
    pBuf += sizeof(m_vbtPcIP);

    *(WORD*)pBuf = m_wSrvPort;
    pBuf += sizeof(WORD);

    *(WORD*)pBuf = m_wIsTcp;
    pBuf += sizeof(WORD);

    *(WORD*)pBuf = m_wDebugPort;
    pBuf += sizeof(WORD);

    *(WORD*)pBuf = m_wTagReg;
    pBuf += sizeof(WORD);

    memcpy((void*)pBuf, m_vcSN, sizeof(m_vcSN));
    SwapBuf(pBuf, sizeof(m_vcSN));
    pBuf += sizeof(m_vcSN);

    return (pBuf - pData);
}
const unsigned long PkgMac::Decode(const unsigned char* pData, const unsigned long nLen,
    string& strError)
{
    //bCSPack: Ϊ true ��ʾ�ͻ���������Ĵ�����, �����ԭʼ MAC ��ַ�ֶ�
    const unsigned char* pBuf = pData;
    unsigned long nPackLen = 76;
    if (nLen < nPackLen) {
        strError = Format("��Ч���ݰ�����: %d, ��ָ���ݰ����벻С��: %d",
            nLen, nPackLen);
        return 0;
    }

    m_dwCrc = *(DWORD*)pBuf;
    pBuf += sizeof(DWORD);

    m_wPackLen = *(WORD*)pBuf;
    pBuf += sizeof(WORD);

    m_wCmdID = *(WORD*)pBuf;
    pBuf += sizeof(WORD);

    if ((m_wCmdID != MAC_CMD_READ)
        && (m_wCmdID != MAC_CMD_READ_RESP)
        && (m_wCmdID != MAC_CMD_WRITE)
        && (m_wCmdID != MAC_CMD_WRITE_RESP)
        && (m_wCmdID != MAC_CMD_TEST)
        && (m_wCmdID != MAC_CMD_TEST_RESP)) {
        //assert(false && "��Ч������");
        strError = Format("��Ч������: %04X",
            m_wCmdID);
        return 0;
    }

    m_wDevType = *(WORD*)pBuf;
    pBuf += sizeof(WORD);

    m_wSubType = *(WORD*)pBuf;
    pBuf += sizeof(WORD);

    m_wDevVer = *(WORD*)pBuf;
    pBuf += sizeof(WORD);

    m_wHardVer = *(WORD*)pBuf;
    pBuf += sizeof(WORD);

    m_dwNuid = *(DWORD*)pBuf;
    SwapBuf((BYTE*)&m_dwNuid, sizeof(DWORD));
    pBuf += sizeof(DWORD);

    m_wWorkStatus = *(WORD*)pBuf;
    pBuf += sizeof(WORD);

    m_wDiscoverVer = *(WORD*)pBuf;
    pBuf += sizeof(WORD);

    memcpy(m_vbtDevMac, (void*)pBuf, sizeof(m_vbtDevMac));
    pBuf += sizeof(m_vbtDevMac);

    m_wDevID = *(WORD*)pBuf;
    pBuf += sizeof(WORD);

    m_dwDevIpMode = *(DWORD*)pBuf;
    pBuf += sizeof(DWORD);

    memcpy(m_vbtDevIP, (void*)pBuf, sizeof(m_vbtDevIP));
    SwapBuf(m_vbtDevIP, sizeof(m_vbtDevIP));
    pBuf += sizeof(m_vbtDevIP);

    memcpy(m_vbtMask, (void*)pBuf, sizeof(m_vbtMask));
    SwapBuf(m_vbtMask, sizeof(m_vbtMask));
    pBuf += sizeof(m_vbtMask);

    memcpy(m_vbtGateway, (void*)pBuf, sizeof(m_vbtGateway));
    SwapBuf(m_vbtGateway, sizeof(m_vbtGateway));
    pBuf += sizeof(m_vbtGateway);

    memcpy(m_vbtPcIP, (void*)pBuf, sizeof(m_vbtPcIP));
    SwapBuf(m_vbtPcIP, sizeof(m_vbtPcIP));
    pBuf += sizeof(m_vbtPcIP);

    m_wSrvPort = *(WORD*)pBuf;
    pBuf += sizeof(WORD);

    m_wIsTcp = *(WORD*)pBuf;
    pBuf += sizeof(WORD);

    m_wDebugPort = *(WORD*)pBuf;
    pBuf += sizeof(WORD);

    m_wTagReg = *(WORD*)pBuf;
    pBuf += sizeof(WORD);

    memcpy(m_vcSN, pBuf, sizeof(m_vcSN));
    SwapBuf(m_vcSN, sizeof(m_vcSN));
    pBuf += sizeof(m_vcSN);

    return (pBuf - pData);
}
void PkgMac::SwapBuf(unsigned char* pBuf, const unsigned long nLen) const
{
    //������������
    unsigned char btTmp = 0;
    for (unsigned long i = 0; i < nLen / 2; ++i) {
        btTmp = pBuf[i];
        pBuf[i] = pBuf[nLen - i - 1];
        pBuf[nLen - i - 1] = btTmp;
    }
}
const bool PkgMac::ToXML(TiXmlNode* pPrnt, string& strError) const
{
    if (NULL == pPrnt) {
        strError = "PkgMac::ToXML(): pPrnt Ϊ NULL";
        return false;
    }
    string strAttr;

    //�������ڵ�
    TiXmlNode* pPkgMacNode = pPrnt->InsertEndChild(TiXmlElement(this->XMLNodeName()));
    pPkgMacNode->ToElement()->SetAttribute("CRC32", UintToStr(m_dwCrc));//CRC-32У����
    pPkgMacNode->ToElement()->SetAttribute("PackLen", UintToStr(m_wPackLen));//�������ݰ������ֽ���
    pPkgMacNode->ToElement()->SetAttribute("CmdID", UintToStr(m_wCmdID));//����ָ��
    pPkgMacNode->ToElement()->SetAttribute("DevType", UintToStr(m_wDevType));//�豸����
    pPkgMacNode->ToElement()->SetAttribute("SubType", UintToStr(m_wSubType));//���豸����
    pPkgMacNode->ToElement()->SetAttribute("DevVer", UintToStr(m_wDevVer));//�豸�汾
    pPkgMacNode->ToElement()->SetAttribute("HardVer", UintToStr(m_wHardVer));//Ӳ���汾
    pPkgMacNode->ToElement()->SetAttribute("NUID", UintToStr(m_dwNuid));//���к�
    pPkgMacNode->ToElement()->SetAttribute("WorkStatus", UintToStr(m_wWorkStatus));//�豸״̬
    pPkgMacNode->ToElement()->SetAttribute("DiscoverVer", UintToStr(m_wDiscoverVer));//�豸״̬
    //strAttr = Misc::BufToHexNoSpaceStrWithTag((const unsigned char*)m_vbtDevMac, sizeof(m_vbtDevMac));//�豸��MAC��ַ
    pPkgMacNode->ToElement()->SetAttribute("DevMac", strAttr);
    pPkgMacNode->ToElement()->SetAttribute("DevID", UintToStr(m_wDevID));//�豸���
    pPkgMacNode->ToElement()->SetAttribute("DevIpMode", UintToStr(m_dwDevIpMode));//�豸IP��ȡ�÷�ʽ

    //IP��ַ
    strAttr = UintToStr(m_vbtDevIP[0])
        + "." + UintToStr(m_vbtDevIP[1])
        + "." + UintToStr(m_vbtDevIP[2])
        + "." + UintToStr(m_vbtDevIP[3]);
    pPkgMacNode->ToElement()->SetAttribute("DevIP", strAttr);

    //��������
    strAttr = UintToStr(m_vbtMask[0])
        + "." + UintToStr(m_vbtMask[1])
        + "." + UintToStr(m_vbtMask[2])
        + "." + UintToStr(m_vbtMask[3]);
    pPkgMacNode->ToElement()->SetAttribute("Mask", strAttr);

    //����
    strAttr = UintToStr(m_vbtGateway[0])
        + "." + UintToStr(m_vbtGateway[1])
        + "." + UintToStr(m_vbtGateway[2])
        + "." + UintToStr(m_vbtGateway[3]);
    pPkgMacNode->ToElement()->SetAttribute("Gateway", strAttr);

    //������IP
    strAttr = UintToStr(m_vbtPcIP[0])
        + "." + UintToStr(m_vbtPcIP[1])
        + "." + UintToStr(m_vbtPcIP[2])
        + "." + UintToStr(m_vbtPcIP[3]);
    pPkgMacNode->ToElement()->SetAttribute("PcIP", strAttr);

    pPkgMacNode->ToElement()->SetAttribute("SrvPort", UintToStr(m_wSrvPort));//�������Ķ˿�
    pPkgMacNode->ToElement()->SetAttribute("IsTcp", UintToStr(m_wIsTcp));//ͨѶsocket����
    pPkgMacNode->ToElement()->SetAttribute("DebugPort", UintToStr(m_wDebugPort));//���Զ˿�
    pPkgMacNode->ToElement()->SetAttribute("TagReg", UintToStr(m_wTagReg));//�豸�ṩ��һ�����������ɶ���д�ı�ǩ�Ĵ���

    BYTE vcSN[16];
    memcpy(vcSN, m_vcSN, sizeof(vcSN));
    SwapBuf((BYTE*)vcSN, sizeof(vcSN));

    strAttr = (const char*)vcSN;//�豸ԭʼ MAC ��ַ
    pPkgMacNode->ToElement()->SetAttribute("SN", strAttr);
    return true;
}

const bool PkgMac::FromXML(const TiXmlNode* pCommonPrmNode, string& strError)
{
    return false;
}

const string EnumMeterToStr(const EnumMeter eMeter)
{
    string strRtrn;
    switch (eMeter) {
    case eMeter_34410A: strRtrn = "34410A"; break;
    case eMeter_34461A: strRtrn = "34461A"; break;
    case eMeter_8846A: strRtrn = "8846A"; break;
    case eMeter_3458A: strRtrn = "3458A"; break;
    case eMeter_34465A:strRtrn = "34465A"; break;
    case eMeter_34470A: strRtrn = "34470A"; break;
    case eMeter_9562: strRtrn = "9562"; break;
    case eMeter_7526A: strRtrn = "7526A"; break;
    case eMeter_5522A:strRtrn = "5522A"; break;
    case eMeter_5560A:strRtrn = "5560A"; break;
    case eMeter_Invld: strRtrn = "Invld"; break;
    default: assert(false && "��������ñ�����"); break;
    }
    return strRtrn;
}

const EnumMeter StrToEnumMeter(const string& strMeter)
{
    EnumMeter eMeter = eMeter_Invld;
    if (strMeter == "Invld") { eMeter = eMeter_Invld; }
    else if (strMeter == "Agilent_34410A") { eMeter = eMeter_34410A; }
    else if (strMeter == "Agilent_34461A") { eMeter = eMeter_34461A; }
    else if (strMeter == "Fluke_8846A") { eMeter = eMeter_8846A; }
    else if (strMeter == "GPIB_3458A") { eMeter = eMeter_3458A; }
    else if (strMeter == "Agilent_34465A") { eMeter = eMeter_34465A; }
    else if (strMeter == "Agilent_34470A") { eMeter = eMeter_34470A; }
    else { assert(false && "��Ч�ַ���"); }
    return eMeter;
}

const string Format(const char* pFormatStr, ...)
{
    const unsigned long nBufSize = 16 * 1024;
    char Buf[nBufSize] = { 0 };

    //��������ɱ����
    va_list list;
    va_start(list, pFormatStr);
    vsprintf_s(Buf, nBufSize, pFormatStr, list);
    va_end(list);

    Buf[nBufSize - 1] = 0;

    return string((char*)Buf);
}

const string CharBufToStr(const unsigned char* chData, const unsigned long nDataLen)
{
    //�� char ����ת��Ϊ std::string, ����֤�������� 0x00 ��β
    unsigned long nLen = nDataLen;
    for (unsigned long i = 0; i < nDataLen; ++i) {
        if (0x00 == chData[i]) {
            nLen = i;
            break;
        }
    }
    string strValue;
    strValue.resize(nLen);
    memcpy((void*)strValue.c_str(), chData, nLen);
    return strValue;
}

const bool StrIPToBuf(const string& strIP, unsigned char* pData, const unsigned long nMaxBufLen, unsigned long& nDataLen)
{
    //IP ��ַ�ַ�����ʽת��������������
    if (strIP.empty()) {
        assert(false);
        return false;
    }
    else {}
    if (NULL == pData) {
        assert(false);
        return false;
    }
    else {}
    if (nMaxBufLen >= 4) {}
    else {
        assert(false);
        return false;
    }

    int vcIP[4] = { 0 };
    const string strRegex = "^(\\d{1,3}).(\\d{1,3}).(\\d{1,3}).(\\d{1,3})$";
    if (IsRegexMatch(strRegex, strIP)) {}
    else {
        assert(false);
        return false;
    }
    if (EOF == sscanf_s(strIP.c_str(), "%d.%d.%d.%d",
        &vcIP[0], &vcIP[1], &vcIP[2], &vcIP[3])) {
        assert(false);
        return false;
    }
    if ((vcIP[0] >= 0) && (vcIP[0] <= 255)
        && (vcIP[1] >= 0) && (vcIP[1] <= 255)
        && (vcIP[2] >= 0) && (vcIP[2] <= 255)
        && (vcIP[3] >= 0) && (vcIP[3] <= 255)) {
    }
    else {
        assert(false);
        return false;
    }
    pData[0] = (unsigned char)vcIP[0];
    pData[1] = (unsigned char)vcIP[1];
    pData[2] = (unsigned char)vcIP[2];
    pData[3] = (unsigned char)vcIP[3];
    nDataLen = 4;
    return true;
}

const string UintToStr(const UINT iData)
{
    char chBuf[256];
    memset((void*)chBuf, 0, sizeof(chBuf));
    _ultoa_s(iData, chBuf, sizeof(chBuf), 10);
    return string(chBuf);
}

const string UInt64ToStr(const UINT64 iData)
{
    char chBuf[256];
    memset((void*)chBuf, 0, sizeof(chBuf));
    _ui64toa_s(iData, chBuf, sizeof(chBuf), 10);
    return string(chBuf);
}

const bool IsRegexMatch(const string& strRegex, const string& strValue)
{
    //ȡֵ�Ƿ�ƥ���������ʽ
    try {
        const std::regex pattern(strRegex);
        bool bRtrn = std::regex_match(strValue, pattern);
        if (bRtrn) {}
        else {
#ifdef _DEBUG
            /*Misc::DebugOutput("%s: ���ݲ�ƥ��: Regex: %s, Value: %s\n",
                __FUNCTION__, strRegex.c_str(), strValue.c_str());*/
#endif//_DEBUG
        }
        return bRtrn;
    }
    catch (...) {
#ifdef _DEBUG
        /*Misc::DebugOutput("%s: ���ݲ�ƥ��: Regex: %s, Value: %s\n",
            __FUNCTION__, strRegex.c_str(), strValue.c_str());*/
#endif//_DEBUG
        return false;
    }
    assert(false);
    return false;
}

void SwapBuf(unsigned char* pData, const unsigned long nLen)
{
    BYTE btTmp = 0;
    for (unsigned long i = 0; i < nLen / 2; ++i) {
        btTmp = pData[i];
        pData[i] = pData[nLen - i - 1];
        pData[nLen - i - 1] = btTmp;
    }
}

const string CharIPToStrIP(unsigned char CharIP[4])
{
    const unsigned long nLenBufMax = 1024;
    char BufIP[nLenBufMax] = { 0 };
    sprintf_s(BufIP, nLenBufMax, "%d.%d.%d.%d",
        (int)CharIP[0],
        (int)CharIP[1],
        (int)CharIP[2],
        (int)CharIP[3]);
    string strSechIP = BufIP;
    return strSechIP;
}

void DebugOutput(const char* pFormatStr, ...)
{
#ifdef _DEBUG
    const unsigned long nBufSize = 2 * 1024;
    char pBuf[nBufSize] = { 0 };

    //��������ɱ����
    va_list list;
    va_start(list, pFormatStr);
    vsprintf_s(pBuf, nBufSize, pFormatStr, list);
    va_end(list);

    pBuf[nBufSize - 1] = 0;
    OutputDebugStringA(pBuf);
#endif//_DEBUG
}

const UINT64 GetTimeMicroSeconds()
{
    //��ȡ��΢��Ϊ��λ�ĵ�ǰʱ��
    UINT64 u64Value = (UINT64)time(NULL) * 1000000;
    SYSTEMTIME Time;
    ::GetLocalTime(&Time);
    u64Value += Time.wMilliseconds * 1000;
    return u64Value;
}

const UINT64 StrTimeToUInt64MicroSeconds(const string& strTime)
{
    assert(strTime.length() == string("0000-00-00 00:00:00.000").length());
    UINT64 u64Rtrn = 0;
    struct tm Time;
    unsigned long nYear = 0xFFFFFFFF;//1970 -- 2012
    unsigned long nMonth = 0xFFFFFFFF;// 1 -- 12
    unsigned long nDay = 0xFFFFFFFF;// 1 -- 31
    unsigned long nHour = 0xFFFFFFFF;// 0 -- 23
    unsigned long nMin = 0xFFFFFFFF;// 0 -- 59
    unsigned long nSec = 0xFFFFFFFF;// 0 - 59
    unsigned long nMillSec = 0xFFFFFFFF;// 0 -- 9999
    //unsigned long nMicrSec = 0xFFFFFFFF;// 0 -- 9999
    unsigned long nMicrSec = 0x00;// 0 -- 9999
    if (EOF == sscanf_s(strTime.c_str(), "%u-%u-%u %u:%u:%u.%u:%u",
        &nYear, &nMonth, &nDay, &nHour, &nMin, &nSec, &nMillSec, &nMicrSec)) {
        assert(false && "ʱ���ַ�����ʽ����");
        u64Rtrn = 0;
    }
    else {
        if ((nYear == 0xFFFFFFFF)
            || (nMonth == 0xFFFFFFFF)
            || (nDay == 0xFFFFFFFF)
            || (nHour == 0xFFFFFFFF)
            || (nMin == 0xFFFFFFFF)
            || (nSec == 0xFFFFFFFF)
            || (nMillSec == 0xFFFFFFFF)) {
            assert((nYear == 0xFFFFFFFF)
                && (nMonth == 0xFFFFFFFF)
                && (nDay == 0xFFFFFFFF)
                && (nHour == 0xFFFFFFFF)
                && (nMin == 0xFFFFFFFF)
                && (nSec == 0xFFFFFFFF)
                && (nMillSec == 0xFFFFFFFF));
            assert(false && "ʱ���ַ�����ʽ����");
            u64Rtrn = 0;
            return 0;
        }
        else if ((nYear < 1900) || (nMonth < 1)) {//Ϊ���ַ���
            assert((nYear == 0)
                && (nMonth == 0)
                && (nDay == 0)
                && (nHour == 0)
                && (nMin == 0)
                && (nSec == 0)
                && (nMillSec == 0)
                && (nMicrSec == 0));
            assert(strTime == string("0000-00-00 00:00:00:000:000"));
            return 0;
        }
        else {
            Time.tm_year = nYear - 1900;
            Time.tm_mon = nMonth - 1;
            Time.tm_mday = nDay;
            Time.tm_hour = nHour;
            Time.tm_min = nMin;
            Time.tm_sec = nSec;
            time_t tm = _mktime64(&Time);
            u64Rtrn = (UINT64)((UINT64)tm * 1000000 + (UINT64)nMillSec * 1000 + nMicrSec);
        }
    }
    return u64Rtrn;
}

const UINT64 StrTimeNoMSToUInt64MicroSeconds(const string& strTime)
{
    assert(strTime.length() == string("0000-00-00 00:00:00").length());
    UINT64 u64Rtrn = 0;
    struct tm Time;
    unsigned long nYear = 0xFFFFFFFF;//1970 -- 2012
    unsigned long nMonth = 0xFFFFFFFF;// 1 -- 12
    unsigned long nDay = 0xFFFFFFFF;// 1 -- 31
    unsigned long nHour = 0xFFFFFFFF;// 0 -- 23
    unsigned long nMin = 0xFFFFFFFF;// 0 -- 59
    unsigned long nSec = 0xFFFFFFFF;// 0 - 59
    unsigned long nMillSec = 0x00;// 0 -- 9999
    //unsigned long nMicrSec = 0xFFFFFFFF;// 0 -- 9999
    unsigned long nMicrSec = 0x00;// 0 -- 9999
    if (EOF == sscanf_s(strTime.c_str(), "%u-%u-%u %u:%u:%u.%u:%u",
        &nYear, &nMonth, &nDay, &nHour, &nMin, &nSec, &nMillSec, &nMicrSec)) {
        assert(false && "ʱ���ַ�����ʽ����");
        u64Rtrn = 0;
    }
    else {
        if ((nYear == 0xFFFFFFFF)
            || (nMonth == 0xFFFFFFFF)
            || (nDay == 0xFFFFFFFF)
            || (nHour == 0xFFFFFFFF)
            || (nMin == 0xFFFFFFFF)
            || (nSec == 0xFFFFFFFF)
            || (nMillSec == 0xFFFFFFFF)) {
            assert((nYear == 0xFFFFFFFF)
                && (nMonth == 0xFFFFFFFF)
                && (nDay == 0xFFFFFFFF)
                && (nHour == 0xFFFFFFFF)
                && (nMin == 0xFFFFFFFF)
                && (nSec == 0xFFFFFFFF)
                && (nMillSec == 0xFFFFFFFF));
            assert(false && "ʱ���ַ�����ʽ����");
            u64Rtrn = 0;
            return 0;
        }
        else if ((nYear < 1900) || (nMonth < 1)) {//Ϊ���ַ���
            assert((nYear == 0)
                && (nMonth == 0)
                && (nDay == 0)
                && (nHour == 0)
                && (nMin == 0)
                && (nSec == 0)
                && (nMillSec == 0)
                && (nMicrSec == 0));
            assert(strTime == string("0000-00-00 00:00:00:000:000"));
            return 0;
        }
        else {
            Time.tm_year = nYear - 1900;
            Time.tm_mon = nMonth - 1;
            Time.tm_mday = nDay;
            Time.tm_hour = nHour;
            Time.tm_min = nMin;
            Time.tm_sec = nSec;
            time_t tm = _mktime64(&Time);
            u64Rtrn = (UINT64)((UINT64)tm * 1000000 + (UINT64)nMillSec * 1000 + nMicrSec);
        }
    }
    return u64Rtrn;
}

const string UInt64MicroSecondsToStrTime(const UINT64 u64MicroSeconds)
{
    if (u64MicroSeconds <= 0) {
        return string("0000-00-00 00:00:00.000");
    }

    time_t u64Time = u64MicroSeconds / 1000000;
    struct tm LocalTime;
    errno_t err = localtime_s(&LocalTime, &u64Time);
    if (err == 0) {}
    else {
        assert(false);
        return string("0000-00-00 00:00:00.000");
    }

    const unsigned long nBufLen = 128;
    char buf[nBufLen];

    u64Time = u64MicroSeconds % 1000000;
    time_t u64MillSecond = u64Time / 1000;
    //time_t u64MicroSecond = u64Time % 1000;
    sprintf_s(buf, nBufLen, "%04d-%02d-%02d %02d:%02d:%02d.%03I64d",
        LocalTime.tm_year + 1900,
        LocalTime.tm_mon + 1,
        LocalTime.tm_mday,
        LocalTime.tm_hour,
        LocalTime.tm_min,
        LocalTime.tm_sec,
        u64MillSecond);
    return string((char*)buf);
}

const string UInt64MicroSecondsToStrTimeNoMS(const UINT64 u64MicroSeconds)
{
    if (u64MicroSeconds <= 0) {
        return string("0000-00-00 00:00:00");
    }

    time_t u64Time = u64MicroSeconds / 1000000;
    struct tm LocalTime;
    errno_t err = localtime_s(&LocalTime, &u64Time);
    if (err == 0) {}
    else {
        assert(false);
        return string("0000-00-00 00:00:00");
    }

    const unsigned long nBufLen = 128;
    char buf[nBufLen];

    sprintf_s(buf, nBufLen, "%04d-%02d-%02d %02d:%02d:%02d",
        LocalTime.tm_year + 1900,
        LocalTime.tm_mon + 1,
        LocalTime.tm_mday,
        LocalTime.tm_hour,
        LocalTime.tm_min,
        LocalTime.tm_sec);
    return string((char*)buf);
}

const string UInt64MicroSecondsToStrDate(const UINT64 u64MicroSeconds)
{
    if (u64MicroSeconds <= 0) {
        return string("00000000");
    }

    time_t u64Time = u64MicroSeconds / 1000000;
    struct tm LocalTime;
    errno_t err = localtime_s(&LocalTime, &u64Time);
    if (err == 0) {}
    else {
        assert(false);
        return string("00000000");
    }

    const unsigned long nBufLen = 128;
    char buf[nBufLen];

    u64Time = u64MicroSeconds % 1000000;
    time_t u64MillSecond = u64Time / 1000;
    //time_t u64MicroSecond = u64Time % 1000;
    sprintf_s(buf, nBufLen, "%04d%02d%02d",
        LocalTime.tm_year + 1900,
        LocalTime.tm_mon + 1,
        LocalTime.tm_mday);
    return string((char*)buf);
}

const string UInt64MicroSecondsToStrDateNoMS(const UINT64 u64MicroSeconds)
{
    if (u64MicroSeconds <= 0) {
        return string("00000000000000");
    }

    time_t u64Time = u64MicroSeconds / 1000000;
    struct tm LocalTime;
    errno_t err = localtime_s(&LocalTime, &u64Time);
    if (err == 0) {}
    else {
        assert(false);
        return string("00000000000000");
    }

    const unsigned long nBufLen = 128;
    char buf[nBufLen];

    u64Time = u64MicroSeconds % 1000000;
    time_t u64MillSecond = u64Time / 1000;
    //time_t u64MicroSecond = u64Time % 1000;
    sprintf_s(buf, nBufLen, "%04d%02d%02d%02d%02d%02d",
        LocalTime.tm_year + 1900,
        LocalTime.tm_mon + 1,
        LocalTime.tm_mday,
        LocalTime.tm_hour,
        LocalTime.tm_min,
        LocalTime.tm_sec);
    return string((char*)buf);
}

const string UInt64MicroSecondsToStrDevDate(const UINT64 u64MicroSeconds)
{
    if (u64MicroSeconds <= 0) {
        return string("2023,9,28");
    }

    time_t u64Time = u64MicroSeconds / 1000000;
    struct tm LocalTime;
    errno_t err = localtime_s(&LocalTime, &u64Time);
    if (err == 0) {}
    else {
        assert(false);
        return string("2023,9,28");
    }

    const unsigned long nBufLen = 128;
    char buf[nBufLen];

    u64Time = u64MicroSeconds % 1000000;
    time_t u64MillSecond = u64Time / 1000;
    //time_t u64MicroSecond = u64Time % 1000;
    sprintf_s(buf, nBufLen, "%04d,%d,%d",
        LocalTime.tm_year + 1900,
        LocalTime.tm_mon + 1,
        LocalTime.tm_mday);
    return string((char*)buf);
}

const string UInt64MicroSecondsToStrDevTime(const UINT64 u64MicroSeconds)
{
    if (u64MicroSeconds <= 0) {
        return string("0,0,0");
    }

    time_t u64Time = u64MicroSeconds / 1000000;
    struct tm LocalTime;
    errno_t err = localtime_s(&LocalTime, &u64Time);
    if (err == 0) {}
    else {
        assert(false);
        return string("0,0,0");
    }

    const unsigned long nBufLen = 128;
    char buf[nBufLen];

    u64Time = u64MicroSeconds % 1000000;
    time_t u64MillSecond = u64Time / 1000;
    //time_t u64MicroSecond = u64Time % 1000;
    sprintf_s(buf, nBufLen, "%d,%d,%d",
        LocalTime.tm_hour,
        LocalTime.tm_min,
        LocalTime.tm_sec);
    return string((char*)buf);
}

const UINT64 UInt64MicroSecondsToTodayTime(const UINT64 u64MicroSeconds)
{
    UINT64 u64TodayTime = 0;
    if (u64MicroSeconds <= 0) {
        return u64TodayTime;
    }

    time_t u64Time = u64MicroSeconds / 1000000;
    struct tm LocalTime;
    errno_t err = localtime_s(&LocalTime, &u64Time);
    if (err == 0) {}
    else {
        assert(false);
        return u64TodayTime;
    }

    const unsigned long nBufLen = 128;
    char buf[nBufLen];

    u64Time = u64MicroSeconds % 1000000;
    time_t u64MillSecond = u64Time / 1000;

    u64TodayTime = (LocalTime.tm_hour * 3600 + LocalTime.tm_min * 60 + LocalTime.tm_sec);
    u64TodayTime *= 1000000;
    return u64TodayTime;
}

const string GetProcessDir()
{
    //#ifdef _DEBUG
    const unsigned long nLenBufMax = MAX_PATH * 2;
    char Buf[nLenBufMax] = { 0 };
    GetModuleFileNameA(NULL, Buf, nLenBufMax);
    int nLen = strlen(Buf);
    if (nLen > 0) {
        char* pTmp = Buf;
        for (int i = (nLen - 1); i > 0; --i) {
            if (pTmp[i] == '\\') {
                Buf[i + 1] = '\0';
                break;
            }
        }
    }
    else
    {
        assert(false);
    }
    return std::string((char*)Buf);
}

const bool IsFileNameValid(const string& strFileName)
{
    if (strFileName.length() == 0) { return false; }
    if (strFileName.length() > 255) { return false; }
    char szSpecialCha[] = { '/','\\','\"',':','*','?','<','>','|','\t' };
    for (size_t i = 0; i < sizeof(szSpecialCha) / sizeof(char); ++i) {
        if (strFileName.find(szSpecialCha[i]) != string::npos) {
            return false;
        }
    }
    return true;
}

const bool FileExist(const string& strFilePath)
{
    WIN32_FIND_DATAA fd;
    HANDLE hFind = FindFirstFileA(strFilePath.c_str(), &fd);
    bool bRtrn = (hFind != INVALID_HANDLE_VALUE);
    if (hFind != INVALID_HANDLE_VALUE) {
        FindClose(hFind);
        hFind = INVALID_HANDLE_VALUE;
    }
    return bRtrn;
}

const string TrimSpace(const string& strValue, const bool bTrimL, const bool bTrimR)
{
    if (strValue.empty()) { return strValue; }
    if (!bTrimL && !bTrimR) { return strValue; }
    size_t nPosBgn = string::npos, nPosEnd = string::npos;
    if (bTrimL) {
        for (size_t i = 0; i < strValue.length(); ++i) {
            if (strValue[i] != ' ') {
                nPosBgn = i;
                break;
            }
        }
        if (nPosBgn == string::npos) {
            //���������ַ������������Ŀո�, �򷵻ط��ؿ��ַ���
            return string("");
        }
    }
    else {
        nPosBgn = 0;
    }

    if (bTrimR) {
        for (size_t i = 0; i < strValue.length(); ++i) {
            if (strValue[strValue.length() - i - 1] != ' ') {
                nPosEnd = strValue.length() - i - 1;
                break;
            }
        }
        if (nPosEnd == string::npos) {
            //���������ַ������������Ŀո�, �򷵻ط��ؿ��ַ���
            return string("");
        }
    }
    else {
        nPosEnd = strValue.length() - 1;
    }
    assert(nPosEnd >= nPosBgn);
    assert(nPosBgn != string::npos);
    assert(nPosEnd != string::npos);
    return strValue.substr(nPosBgn, nPosEnd - nPosBgn + 1);
}

void FormatTime(const UINT64 nTime, CString& str)
{
    UINT64 nMilliSecond = 0;
    UINT64 nMicroSecond = 0;
    //����Ϊ΢��
    nMilliSecond = nTime / 1000;
    nMicroSecond = nTime % 1000;
    UINT64 nHour = nMilliSecond / 3600000;
    UINT64 nTimeM = nMilliSecond % 3600000;
    UINT64 nMin = nTimeM / 60000;
    UINT64 nTimeS = nTimeM % 60000;
    UINT64 nSec = nTimeS / 1000;
    UINT64 nMs = nTimeS % 1000;

    str.Format(L"%lld:%002lld:%002lld:%0003lld", nHour, nMin, nSec, nMs);

    /*CString cstrTmp;
    cstrTmp.Format(L".%0003lld", nMicroSecond);
    str.Append(cstrTmp);*/
}

const string ErrorCodeToStr(const int nError)
{
    //���ݴ��������ɴ����ַ���
    return Format("0x%08X", (DWORD)nError);
}

const string IntToStr(const int iData)
{
    char chBuf[64];
    memset((void*)chBuf, 0, sizeof(chBuf));
    sprintf_s(chBuf, sizeof(chBuf), "%d", iData);
    return string(chBuf);
}

const string FloatToStr(const double dData)
{
    char chBuf[256];
    memset((void*)chBuf, 0, sizeof(chBuf));
    sprintf_s(chBuf, sizeof(chBuf), "%.013f", dData);
    return string(chBuf);
}

const string DoubleToStr(double in, unsigned long decimal_bit, unsigned long effective_bit)
{
    char str[64] = { 0 }, temp;
    if (decimal_bit == 0)
    {
        sprintf_s(str, _countof(str), "%lf", in);
    }
    else
    {
        char format[10] = { 0 };
        sprintf_s(format, _countof(format), "%%.0%ldlf", decimal_bit);
        sprintf_s(str, _countof(str), format, in);
    }

    temp = str[7];
    str[7] = '\0';
    //  ������Ƴ��Ⱥ󾫶���ʧ����1.0���򲻽��г�������
    if ((in - atof(str)) > 1.0)
    {
        str[6] = temp;
    }

    //  �̶���Чλ(����ʱǰ�油�ո�)
    int str_len = strlen(str);
    int diff_bit = (int)effective_bit - str_len;
    if (diff_bit > 0)
    {
        memcpy(str + diff_bit, str, str_len + 1);
        memset(str, ' ', diff_bit);
    }

    return string(str);
}

const string UintToHexStr(const UINT iData)
{
    char chBuf[256];
    memset((void*)chBuf, 0, sizeof(chBuf));
    sprintf_s(chBuf, sizeof(chBuf), "%08X", iData);
    return string(chBuf);
}

const bool StrToUint(const string& strUint, unsigned int& iValue)
{
    if (strUint.empty()) {
        //assert(false);
        return false;
    }
    if (EOF == sscanf_s(strUint.c_str(), "%d", &iValue)) {
        //assert(false);
        return false;
    }
    return true;
}

const bool HexNoSpaceStrToBuf(const string& strHex, unsigned char* pBuf, const unsigned long nMaxBufLen, unsigned long& nDataLen)
{
    //��ʮ�������ַ���ת����ʮ����������������
    if (strHex.length() == 0) {
        assert(false);
        return false;
    }
    if ((strHex.length() % 2) != 0) {
        assert(false);
        return false;
    }

    nDataLen = strHex.length() / 2;
    if (nMaxBufLen < nDataLen) {
        assert(false);
        return false;
    }

    const char* pstrHex = strHex.c_str();
    int nValue = 0;
    for (unsigned long i = 0; i < nDataLen; ++i) {
        if (EOF == sscanf_s(pstrHex + i * 2, "%02X", &nValue)) {
            assert(false);
            return false;
        }
        else { *(BYTE*)(pBuf + i) = (BYTE)nValue; }
    }
    return true;
}

const CString ToUnicode(const char* str)
{
    CString cstrTmp;
    int textlen = MultiByteToWideChar(936, 0, str, -1, NULL, 0);
    wchar_t* result = (wchar_t*)malloc((textlen + 1) * sizeof(wchar_t));
    if (result) {
        memset(result, 0, (textlen + 1) * sizeof(wchar_t));
        MultiByteToWideChar(936, 0, str, -1, (LPWSTR)result, textlen);
        cstrTmp = result;
        free(result);
        result = NULL;
    }
    else { assert(false && "��������ʧ��"); }
    return cstrTmp;
}

const unsigned long CalcCrc32FromBuf(const unsigned char* pBuf, const int nLen)
{
    const DWORD vcdwCrc32Table[256] = {
        0x00000000, 0x77073096, 0xEE0E612C, 0x990951BA, 0x076DC419, 0x706AF48F, 0xE963A535, 0x9E6495A3,
        0x0EDB8832, 0x79DCB8A4, 0xE0D5E91E, 0x97D2D988, 0x09B64C2B, 0x7EB17CBD, 0xE7B82D07, 0x90BF1D91,
        0x1DB71064, 0x6AB020F2, 0xF3B97148, 0x84BE41DE, 0x1ADAD47D, 0x6DDDE4EB, 0xF4D4B551, 0x83D385C7,
        0x136C9856, 0x646BA8C0, 0xFD62F97A, 0x8A65C9EC, 0x14015C4F, 0x63066CD9, 0xFA0F3D63, 0x8D080DF5,
        0x3B6E20C8, 0x4C69105E, 0xD56041E4, 0xA2677172, 0x3C03E4D1, 0x4B04D447, 0xD20D85FD, 0xA50AB56B,
        0x35B5A8FA, 0x42B2986C, 0xDBBBC9D6, 0xACBCF940, 0x32D86CE3, 0x45DF5C75, 0xDCD60DCF, 0xABD13D59,
        0x26D930AC, 0x51DE003A, 0xC8D75180, 0xBFD06116, 0x21B4F4B5, 0x56B3C423, 0xCFBA9599, 0xB8BDA50F,
        0x2802B89E, 0x5F058808, 0xC60CD9B2, 0xB10BE924, 0x2F6F7C87, 0x58684C11, 0xC1611DAB, 0xB6662D3D,
        0x76DC4190, 0x01DB7106, 0x98D220BC, 0xEFD5102A, 0x71B18589, 0x06B6B51F, 0x9FBFE4A5, 0xE8B8D433,
        0x7807C9A2, 0x0F00F934, 0x9609A88E, 0xE10E9818, 0x7F6A0DBB, 0x086D3D2D, 0x91646C97, 0xE6635C01,
        0x6B6B51F4, 0x1C6C6162, 0x856530D8, 0xF262004E, 0x6C0695ED, 0x1B01A57B, 0x8208F4C1, 0xF50FC457,
        0x65B0D9C6, 0x12B7E950, 0x8BBEB8EA, 0xFCB9887C, 0x62DD1DDF, 0x15DA2D49, 0x8CD37CF3, 0xFBD44C65,
        0x4DB26158, 0x3AB551CE, 0xA3BC0074, 0xD4BB30E2, 0x4ADFA541, 0x3DD895D7, 0xA4D1C46D, 0xD3D6F4FB,
        0x4369E96A, 0x346ED9FC, 0xAD678846, 0xDA60B8D0, 0x44042D73, 0x33031DE5, 0xAA0A4C5F, 0xDD0D7CC9,
        0x5005713C, 0x270241AA, 0xBE0B1010, 0xC90C2086, 0x5768B525, 0x206F85B3, 0xB966D409, 0xCE61E49F,
        0x5EDEF90E, 0x29D9C998, 0xB0D09822, 0xC7D7A8B4, 0x59B33D17, 0x2EB40D81, 0xB7BD5C3B, 0xC0BA6CAD,
        0xEDB88320, 0x9ABFB3B6, 0x03B6E20C, 0x74B1D29A, 0xEAD54739, 0x9DD277AF, 0x04DB2615, 0x73DC1683,
        0xE3630B12, 0x94643B84, 0x0D6D6A3E, 0x7A6A5AA8, 0xE40ECF0B, 0x9309FF9D, 0x0A00AE27, 0x7D079EB1,
        0xF00F9344, 0x8708A3D2, 0x1E01F268, 0x6906C2FE, 0xF762575D, 0x806567CB, 0x196C3671, 0x6E6B06E7,
        0xFED41B76, 0x89D32BE0, 0x10DA7A5A, 0x67DD4ACC, 0xF9B9DF6F, 0x8EBEEFF9, 0x17B7BE43, 0x60B08ED5,
        0xD6D6A3E8, 0xA1D1937E, 0x38D8C2C4, 0x4FDFF252, 0xD1BB67F1, 0xA6BC5767, 0x3FB506DD, 0x48B2364B,
        0xD80D2BDA, 0xAF0A1B4C, 0x36034AF6, 0x41047A60, 0xDF60EFC3, 0xA867DF55, 0x316E8EEF, 0x4669BE79,
        0xCB61B38C, 0xBC66831A, 0x256FD2A0, 0x5268E236, 0xCC0C7795, 0xBB0B4703, 0x220216B9, 0x5505262F,
        0xC5BA3BBE, 0xB2BD0B28, 0x2BB45A92, 0x5CB36A04, 0xC2D7FFA7, 0xB5D0CF31, 0x2CD99E8B, 0x5BDEAE1D,
        0x9B64C2B0, 0xEC63F226, 0x756AA39C, 0x026D930A, 0x9C0906A9, 0xEB0E363F, 0x72076785, 0x05005713,
        0x95BF4A82, 0xE2B87A14, 0x7BB12BAE, 0x0CB61B38, 0x92D28E9B, 0xE5D5BE0D, 0x7CDCEFB7, 0x0BDBDF21,
        0x86D3D2D4, 0xF1D4E242, 0x68DDB3F8, 0x1FDA836E, 0x81BE16CD, 0xF6B9265B, 0x6FB077E1, 0x18B74777,
        0x88085AE6, 0xFF0F6A70, 0x66063BCA, 0x11010B5C, 0x8F659EFF, 0xF862AE69, 0x616BFFD3, 0x166CCF45,
        0xA00AE278, 0xD70DD2EE, 0x4E048354, 0x3903B3C2, 0xA7672661, 0xD06016F7, 0x4969474D, 0x3E6E77DB,
        0xAED16A4A, 0xD9D65ADC, 0x40DF0B66, 0x37D83BF0, 0xA9BCAE53, 0xDEBB9EC5, 0x47B2CF7F, 0x30B5FFE9,
        0xBDBDF21C, 0xCABAC28A, 0x53B39330, 0x24B4A3A6, 0xBAD03605, 0xCDD70693, 0x54DE5729, 0x23D967BF,
        0xB3667A2E, 0xC4614AB8, 0x5D681B02, 0x2A6F2B94, 0xB40BBE37, 0xC30C8EA1, 0x5A05DF1B, 0x2D02EF8D
    };
    DWORD dwCrc32 = 0xFFFFFFFF;
    for (int i = 0; i < nLen; ++i)
    {
        dwCrc32 = ((dwCrc32) >> 8) ^ vcdwCrc32Table[(pBuf[i]) ^ ((dwCrc32) & 0x000000FF)];
    }

    dwCrc32 = ~dwCrc32;

    return dwCrc32;
}

const string btValueTypeToString(BYTE btType)
{
    string strType;
    switch (btType)
    {
    case MacCnnctDev_copy::eMeter_Value_RVX:
        strType = "RVX";
        break;
    case MacCnnctDev_copy::eMeter_Value_RV:
        strType = "RV";
        break;
    case MacCnnctDev_copy::eMeter_Value_V:
        strType = "V";
        break;
    case MacCnnctDev_copy::eMeter_Value_R:
        strType = "R";
        break;
    case MacCnnctDev_copy::eMeter_Value_RZP:
        strType = "RZP";
        break;
    default:
        strType = "RVX";
        break;
    }
    return strType;
}

CString GetRulerTitleByKind(UINT rulerKind)
{
    CString cstr;
    switch (rulerKind)
    {
    case MacCnnctDev_copy::RDK_NULL:
        break;
    case MacCnnctDev_copy::RDK_Time:
        cstr = L"Time";
        break;
    case MacCnnctDev_copy::RDK_R:
        cstr = L"R";
        break;
    case MacCnnctDev_copy::RDK_X:
        cstr = L"X";
        break;
    case MacCnnctDev_copy::RDK_V:
        cstr = L"V(V)";
        break;
    case MacCnnctDev_copy::RDK_P:
        cstr = L"P(��)";
        break;
    case MacCnnctDev_copy::RDK_Z:
        cstr = L"Z";
        break;
    default:
        cstr = L"";
        break;
    }
    return cstr;
}

//CRC-16/MODBUS http://www.ip33.com/crc.html
//���� 16
//����ʽ 8005
//��ʼֵ FFFF
//������ֵ 0000
const uint16_t calc_crc16_with_init(char* ptr, uint16_t len, uint16_t init_val)
{
    uint8_t i;
    uint16_t crc = init_val;
    while (len--)
    {
        //crc ^= *ptr++;
        crc ^= ((*ptr++) & 0x00FF);
        for (i = 0; i < 8; ++i)
        {
            if (crc & 1)
                crc = (crc >> 1) ^ 0xA001;
            else
                crc = (crc >> 1);
        }
    }
    return crc;
}

const int GetSizeFromValueMode(int ValueMode)
{
    int num = -1;
    switch (ValueMode)
    {
    case MacCnnctDev_copy::eMeter_Value_RVX:
        num = 3;
        break;
    case MacCnnctDev_copy::eMeter_Value_RV:
        num = 2;
        break;
    case MacCnnctDev_copy::eMeter_Value_V:
        num = 1;
        break;
    case MacCnnctDev_copy::eMeter_Value_R:
        num = 1;
        break;
    case MacCnnctDev_copy::eMeter_Value_RZP:
        num = 3;
        break;
    default:
        break;
    }
    return num;
}

RangeParam::RangeParam()
{
    nPlc = 10;
    fRRange = 3000;
    fVRange = 6;
    btEnumNPlc = eRange_NPLC_10;
    btEnumRRange = eRange_R_3;
    btEnumVRange = eRange_V_6;
    bHeat = false;
    bInternal = false;
    btEnumShowType = eMeter_Value_RVX;
}

RangeParam::~RangeParam()
{
}
//BYTE RangeParam::GetEnumVRange()
//{
//    BYTE btVRange;
//    if (fVRange == 6) {
//        btVRange = eRange_V_6;
//    }
//    else if (fVRange == 60) {
//        btVRange = eRange_V_60;
//    }
//    else {
//        btVRange = eRange_V_6;
//    }
//    return btVRange;
//}
//BYTE RangeParam::GetEnumRRange()
//{
//    BYTE btRRange;
//    if (fRRange == 3) {
//        btRRange = eRange_R_3;
//    }
//    else if (fRRange == 0.3) {
//        btRRange = eRange_R_03;
//    }
//    else if (fRRange == 0.03) {
//        btRRange = eRange_R_003;
//    }
//    else if (fRRange == 0.003) {
//        btRRange = eRange_R_0003;
//    }
//    else {
//        btRRange = eRange_R_3;
//    }
//    return btRRange;
//}
BYTE RangeParam::GetEnumNPLC()
{
    BYTE btNPLC;
    if (nPlc == 1) {
        btNPLC = eRange_NPLC_1;
    }
    else if (nPlc == 5) {
        btNPLC = eRange_NPLC_5;
    }
    else if (nPlc == 10) {
        btNPLC = eRange_NPLC_10;
    }
    else if (nPlc == 25) {
        btNPLC = eRange_NPLC_25;
    }
    else if (nPlc == 50) {
        btNPLC = eRange_NPLC_50;
    }
    else {
        btNPLC = eRange_NPLC_10;
    }
    return btNPLC;
}
IRMeterData::IRMeterData()
{
    nDataNo = -1;
    u64Time = 0;
    btValueType = eMeter_Value_RVX;
    fR = 0;
    fX = 0;
    fV = 0;
    fP = 0;
    fZ = 0;
    /*fAvgR=0;
    fAvgX=0;
    fAvgV=0;
    fAvgP=0;
    fAvgZ=0;*/
    bTrulyPoint = true;
}
IRMeterData::~IRMeterData()
{
}
IRMeterDataStatis::IRMeterDataStatis()
{
}
IRMeterDataStatis::~IRMeterDataStatis()
{
}
bool IRMeterDataStatis::UpdateData(vector<IRMeterData> vcIRMData)
{
    if (vcIRMeterData.size() != vcIRMData.size()) {
        swap(vcIRMeterData, vcIRMData);
        return true;
    }
    return false;
}
CaliRangePointPrm::CaliRangePointPrm()
{
    m_mapVoltRange.clear();
    //m_mapCurrRange.clear();
}
CaliRangePointPrm::~CaliRangePointPrm()
{
}
CaliRangePointPrm::RangePoint::RangePoint()
{
    m_vcRangePoint.clear();
}
CaliPointNo::CaliPointNo()
{
    memset(this, 0, sizeof(CaliPointNo));
    m_fRange=0;
    m_fPoint=0;			//��λ: %, ȡֵ��Χ : 0.0 -- 100.0
    m_fPrecision=0;
}
SegData::FetchData::FetchData()
{
    dIRMValue = 0;
    dMValue = 0;
}
SegData::SegData()
{
    //bDataForCali = true;
}
SegRslt::SegRslt()
{
    nBegin = 0;
    nEnd = 0;
    dK = 0;
    dB = 0;
    m_dCheckPriRate = 0.0;
    //m_dRsltPriShow = 0.0;
    m_dRsltPriMeasure = 0.0;
    //m_dRsltPriControl = 0.0;
    m_eCaliType = EnumCaliIRMeter::eCaliIRMeter_Invld;
    m_eRslt = EnumRslt::eRslt_NoSample;
    m_fRange = 0;
}
CaliOrCheckData::CaliOrCheckData()
{
    m_eCaliIRMeter = EnumCaliIRMeter::eCaliIRMeter_Invld;
}
void CaliOrCheckData::Reset()
{
    MeterMidInfo mMeterMidInfo;
    m_IRMeterMid = mMeterMidInfo;
    m_eCaliIRMeter = eCaliIRMeter_UnStart;
    m_mpVoltSegData.clear();
    m_mpIRRangeRslt.clear();
    m_mpVoltSegData.clear();
    m_mpIRRangeRslt.clear();
    m_vcVRange.clear();
    m_vcRRange.clear();
    m_vcBtPhasePoint.clear();
    m_mpPhaseData.clear();
}
bool CaliOrCheckData::IsCheckPass(bool bVolt)
{
    bool bRtrn = true;
    double dPrecision = 0;
    double dCurrPrecision = 0;
    if (!bVolt) {
        if (m_vcRRange.size() == 0) {
            bRtrn = false;
        }
        for (size_t i = 0; i < m_vcRRange.size(); i++)
        {
            for (size_t j = 0; j < m_mpIRRangeRslt[m_vcRRange[i]].m_vcSegRslt.size(); j++)
            {
                dPrecision = m_mpIRRangeRslt[m_vcRRange[i]].m_vcSegRslt[j].m_dCheckPriRate;
                dCurrPrecision = m_mpIRRangeRslt[m_vcRRange[i]].m_vcSegRslt[j].m_dRsltPriMeasure;
                if (dCurrPrecision > dPrecision) {
                    bRtrn = false;
                    break;
                }
            }
        }
    }
    
    if (bRtrn && bVolt) {
        if (m_vcVRange.size() == 0) {
            bRtrn = false;
        }
        for (size_t i = 0; i < m_vcVRange.size(); i++)
        {
            for (size_t j = 0; j < m_mpVoltRangeRslt[m_vcVRange[i]].m_vcSegRslt.size(); j++)
            {
                dPrecision = m_mpVoltRangeRslt[m_vcVRange[i]].m_vcSegRslt[j].m_dCheckPriRate;
                dCurrPrecision = m_mpVoltRangeRslt[m_vcVRange[i]].m_vcSegRslt[j].m_dRsltPriMeasure;
                if (dCurrPrecision > dPrecision) {
                    bRtrn = false;
                    break;
                }
            }
        }
    }    
    return bRtrn;
}
RangeRslts::RangeRslts()
{
    m_fRange = 0;
    m_BTCaliType = 0;
}
bool RangeRslts::InsertSeg(SegData m_SegData)
{
    m_vcSegRslt.clear();
    if (m_SegData.m_mpFetchData.size() < 2) {//����������
        return false;
    }
    for (size_t i = 0; i < m_SegData.m_mpFetchData.size() - 1; i++)
    {
        SegRslt m_SegRslt;
        /*m_SegRslt.fBegin = m_SegData.m_mpFetchData[i].m_CaliPointNo.m_fPoint;
        m_SegRslt.fEnd = m_SegData.m_mpFetchData[i + 1].m_CaliPointNo.m_fPoint;*/
        if (m_BTCaliType == eCali_IR) {
            m_SegRslt.nBegin = INT_MIN;//-2147483648
            m_SegRslt.nEnd = INT_MAX/*2147483647*/;
        }
        else if (m_BTCaliType == eCali_Volt) {
            m_SegRslt.nBegin = m_SegData.m_mpFetchData[i].dIRMValue;
            m_SegRslt.nEnd = m_SegData.m_mpFetchData[i + 1].dIRMValue;
        }  
        int nRate = 1;
        /*if (m_SegData.m_mpFetchData[i + 1].m_CaliPointNo.m_fRange != 3 && m_BTCaliType == eCali_IR) {
            nRate *= 1000;
        }*/
        //nRate *= 1000;
        m_SegRslt.dK = nRate * (m_SegData.m_mpFetchData[i + 1].dMValue - m_SegData.m_mpFetchData[i].dMValue)
            /(m_SegData.m_mpFetchData[i + 1].dIRMValue - m_SegData.m_mpFetchData[i].dIRMValue) ;//������ֵ 
        
        m_SegRslt.dB = (m_SegData.m_mpFetchData[i].dMValue - m_SegData.m_mpFetchData[i].dIRMValue * m_SegRslt.dK);
        if ((m_SegRslt.dK > 100) || (m_SegRslt.dK < 0.01)) {
            //����KBʧ��
        }
        m_SegRslt.m_fRange = m_fRange;
        m_vcSegRslt.push_back(m_SegRslt);
    }
    m_fRange = m_SegData.m_mpFetchData[0].m_CaliPointNo.m_fRange;
    return true;
}
bool RangeRslts::ADDSeg(SegData m_SegData)
{
    m_vcSegRslt.clear();
    if (m_SegData.m_mpFetchData.size() < 1) {//����һ����
        return false;
    }
    m_fRange = m_SegData.m_mpFetchData[0].m_CaliPointNo.m_fRange;
    for (size_t i = 0; i < m_SegData.m_mpFetchData.size(); i++)
    {
        SegRslt m_SegRslt;
        if (m_BTCaliType == eCali_IR) {
            m_SegRslt.m_dCheckPriRate = 0.05;//��5
        }
        else if (m_BTCaliType == eCali_Volt) {
            m_SegRslt.m_dCheckPriRate = 0.4;//��1
        }        
        m_SegRslt.m_dRsltPriMeasure = abs(m_SegData.m_mpFetchData[i].dMValue - m_SegData.m_mpFetchData[i].dIRMValue)/ m_fRange * 100;

        m_vcSegRslt.push_back(m_SegRslt);
    }
    return true;
}
CaliDataPerRng::CaliDataPerRng()
{
}
CaliDataPerType::CaliDataPerType()
{
}
CaliDataS::CaliDataS()
{
}
CaliDataPerSeg::CaliDataPerSeg()
{
    nBegin = 0;
    nEnd = 0;
    dK = 0;
    dB = 0;
}
CaliStates::CaliStates()
{
}
CaliState::CaliState()
{
    u64Time=0;
    memset(m_chSN, 0, sizeof(m_chSN));
}
PhaseData::PerPhaseData::PerPhaseData()
{
    dRValue = 0;
    dXValue = 0;
    dXita = 0;
    dRsltPriMeasure = 0;
    dCurrRValue = 0;//������ֵ
    dCurrXValue = 0;//������ֵ
}
PhaseData::PhaseData()
{
    dXita = 0; 
    fRange = 0;
    m_dRsltPriMeasure = 0;
}
st_CaliFile::st_CaliFile()
{
    wVer = 0;
    wFileLen = 0;
    btDevType = 0;
    btSubType = 0;
    dwDevNuid = 0;
    dwDate = 0;
    dwTime = 0;
    pRegCaliParam = NULL;
    dwCRC32 = 0;
}
st_CaliFile::~st_CaliFile()
{
    if (pRegCaliParam) {
        delete pRegCaliParam;
        pRegCaliParam = NULL;
    }
}
const DWORD st_CaliFile::Encode(BYTE* pData, const DWORD dwMaxLen)
{//���ֱ�Ӵ�
    DWORD dwPos = 0;

    if (!pRegCaliParam) {
        return dwPos;
    }

    *(WORD*)(pData + dwPos) = wVer;
    dwPos += sizeof(WORD);

    *(WORD*)(pData + dwPos) = wFileLen;
    dwPos += sizeof(WORD);

    if (wFileLen > dwMaxLen) {
        assert("У׼�ļ�����");
        return dwPos;
    }

    *(byte*)(pData + dwPos) = btDevType;
    dwPos += sizeof(byte);

    *(byte*)(pData + dwPos) = btSubType;
    dwPos += sizeof(byte);

    *(DWORD*)(pData + dwPos) = dwDevNuid;
    dwPos += sizeof(DWORD);

    *(DWORD*)(pData + dwPos) = dwDate;
    dwPos += sizeof(DWORD);

    *(DWORD*)(pData + dwPos) = dwTime;
    dwPos += sizeof(DWORD);

    {//pRegCaliParam
        *(float*)(pData + dwPos) = pRegCaliParam->fIntTemp;
        dwPos += sizeof(float);

        *(float*)(pData + dwPos) = pRegCaliParam->fExtTemp;
        dwPos += sizeof(float);

        *(byte*)(pData + dwPos) = pRegCaliParam->btResRangeNum;
        dwPos += sizeof(byte);

        *(byte*)(pData + dwPos) = pRegCaliParam->btVoltRangeNum;
        dwPos += sizeof(byte);

        int nRnum = 0;
        int nVnum = 0;

        for (size_t i = 0; i < NUM_Cali_Seg; i++)
        {
            *(byte*)(pData + dwPos) = pRegCaliParam->btResSegNum[i];
            dwPos += sizeof(byte);

            nRnum += pRegCaliParam->btResSegNum[i];
        }

        for (size_t i = 0; i < NUM_Cali_Seg; i++)
        {
            *(byte*)(pData + dwPos) = pRegCaliParam->btVoltSegNum[i];
            dwPos += sizeof(byte);

            nVnum += pRegCaliParam->btVoltSegNum[i];
        }

        for (size_t i = 0; i < NUM_Cali_Seg; i++)
        {
            *(float*)(pData + dwPos) = pRegCaliParam->m_fPhaseOffset[i];
            dwPos += sizeof(float);
        }

        for (size_t i = 0; i < NUM_Cali_Seg; i++)
        {
            *(float*)(pData + dwPos) = pRegCaliParam->m_fSourceCurrent[i];
            dwPos += sizeof(float);
        }

        for (size_t i = 0; i < NUM_Cali_Seg; i++)
        {
            *(DWORD*)(pData + dwPos) = pRegCaliParam->m_dwVoltZeroCode[i];
            dwPos += sizeof(DWORD);
        }

        for (size_t i = 0; i < NUM_Cali_Seg; i++)
        {
            *(DWORD*)(pData + dwPos) = pRegCaliParam->m_dwVoltRefCode[i];
            dwPos += sizeof(DWORD);
        }

        for (size_t i = 0; i < pRegCaliParam->m_vcResSegParam.size(); i++)
        {
            *(st_CaliSeg*)(pData + dwPos) = pRegCaliParam->m_vcResSegParam[i];
            dwPos += sizeof(st_CaliSeg);       
        }

        for (size_t i = 0; i < pRegCaliParam->m_vcVoltSegParam.size(); i++)
        {
            *(st_CaliSeg*)(pData + dwPos) = pRegCaliParam->m_vcVoltSegParam[i];
            dwPos += sizeof(st_CaliSeg);         
        }
    }

    dwCRC32 = CalcCrc32FromBuf(pData, dwPos);

    *(DWORD*)(pData + dwPos) = dwCRC32;
    dwPos += sizeof(DWORD);

    return dwPos;
}
const DWORD st_CaliFile::Decode(BYTE* pData, const DWORD dwMaxLen)
{//���ʱ��Ҫ�ж�
    DWORD dwPos = 0;

    if (!pRegCaliParam) {
        pRegCaliParam = new st_CaliParam;
    }

    wVer = *(WORD*)(pData + dwPos);
    dwPos += sizeof(WORD);

    wFileLen = *(WORD*)(pData + dwPos);
    dwPos += sizeof(WORD);

    btDevType = *(BYTE*)(pData + dwPos);
    dwPos += sizeof(BYTE);

    btSubType = *(BYTE*)(pData + dwPos);
    dwPos += sizeof(BYTE);

    dwDevNuid = *(DWORD*)(pData + dwPos);
    dwPos += sizeof(DWORD);

    dwDate = *(DWORD*)(pData + dwPos);
    dwPos += sizeof(DWORD);

    dwTime = *(DWORD*)(pData + dwPos);
    dwPos += sizeof(DWORD);

    {//pRegCaliParam
        pRegCaliParam->fIntTemp = *(float*)(pData + dwPos);
        dwPos += sizeof(float);

        pRegCaliParam->fExtTemp = *(float*)(pData + dwPos);
        dwPos += sizeof(float);

        pRegCaliParam->btResRangeNum = *(byte*)(pData + dwPos);
        dwPos += sizeof(byte);

        pRegCaliParam->btVoltRangeNum = *(byte*)(pData + dwPos);
        dwPos += sizeof(byte);

        int nRnum = 0;
        int nVnum = 0;

        for (size_t i = 0; i < NUM_Cali_Seg; i++)
        {
            pRegCaliParam->btResSegNum[i] = *(byte*)(pData + dwPos);
            dwPos += sizeof(byte);

            nRnum += pRegCaliParam->btResSegNum[i];
        }

        for (size_t i = 0; i < NUM_Cali_Seg; i++)
        {
            pRegCaliParam->btVoltSegNum[i] = *(byte*)(pData + dwPos);
            dwPos += sizeof(byte);

            nVnum += pRegCaliParam->btVoltSegNum[i];
        }

        for (size_t i = 0; i < NUM_Cali_Seg; i++)
        {
            pRegCaliParam->m_fPhaseOffset[i] = *(float*)(pData + dwPos);
            dwPos += sizeof(float);
        }

        for (size_t i = 0; i < NUM_Cali_Seg; i++)
        {
            pRegCaliParam->m_fSourceCurrent[i] = *(float*)(pData + dwPos);
            dwPos += sizeof(float);
        }

        for (size_t i = 0; i < NUM_Cali_Seg; i++)
        {
            pRegCaliParam->m_dwVoltZeroCode[i] = *(DWORD*)(pData + dwPos);
            dwPos += sizeof(DWORD);
        }

        for (size_t i = 0; i < NUM_Cali_Seg; i++)
        {
            pRegCaliParam->m_dwVoltRefCode[i] = *(DWORD*)(pData + dwPos);
            dwPos += sizeof(DWORD);
        }

        pRegCaliParam->m_vcResSegParam.resize(nRnum);
        for (size_t i = 0; i < nRnum; i++)
        {
            pRegCaliParam->m_vcResSegParam[i] = *(st_CaliSeg*)(pData + dwPos);
            dwPos += sizeof(st_CaliSeg);

            /*pRegCaliParam->m_vcResSegParam[i].begin = *(float*)(pData + dwPos);
            dwPos += sizeof(float);

            pRegCaliParam->m_vcResSegParam[i].end = *(float*)(pData + dwPos);
            dwPos += sizeof(float);

            pRegCaliParam->m_vcResSegParam[i].k = *(float*)(pData + dwPos);
            dwPos += sizeof(float);

            pRegCaliParam->m_vcResSegParam[i].b = *(float*)(pData + dwPos);
            dwPos += sizeof(float);*/
        }

        pRegCaliParam->m_vcVoltSegParam.resize(nVnum);
        for (size_t i = 0; i < nVnum; i++)
        {
            pRegCaliParam->m_vcVoltSegParam[i] = *(st_CaliSeg*)(pData + dwPos);
            dwPos += sizeof(st_CaliSeg);

            /*pRegCaliParam->m_vcVoltSegParam[i].begin = *(float*)(pData + dwPos);
            dwPos += sizeof(float);

            pRegCaliParam->m_vcVoltSegParam[i].end = *(float*)(pData + dwPos);
            dwPos += sizeof(float);

            pRegCaliParam->m_vcVoltSegParam[i].k = *(float*)(pData + dwPos);
            dwPos += sizeof(float);

            pRegCaliParam->m_vcVoltSegParam[i].b = *(float*)(pData + dwPos);
            dwPos += sizeof(float);*/
        }
    }
    DWORD dwCrc32 = CalcCrc32FromBuf(pData, dwPos);

    dwCRC32 = *(DWORD*)(pData + dwPos);
    dwPos += sizeof(DWORD);

    if (dwCrc32 != dwCRC32) {
        assert("У��ʧ�ܣ�");
    }

    return dwPos;
}
DWORD st_CaliFile::GetCaliParamLen()
{
    DWORD dwLen = 0;
    if (!pRegCaliParam) {
        return dwLen;
    }
    byte btRNum = 0, btVNum = 0, btRSegNum = 0,btVSegNum = 0;
    btRNum = pRegCaliParam->btResRangeNum;
    btVNum = pRegCaliParam->btVoltRangeNum;
    //dwLen += sizeof(byte) * (2 + btRNum + btVNum) + sizeof(float) * 4 * btRNum + sizeof(float) * 2 * btVNum;
    dwLen += sizeof(byte) * (2 + NUM_Cali_Seg * 2) + sizeof(float) * 2 * NUM_Cali_Seg + sizeof(DWORD) * 2 * NUM_Cali_Seg + sizeof(float) * 2;

    for (size_t i = 0; i < btRNum; i++)
    {
        btRSegNum += pRegCaliParam->btResSegNum[i];
    }

    for (size_t i = 0; i < btVNum; i++)
    {
        btVSegNum += pRegCaliParam->btVoltSegNum[i];
    }
    dwLen += sizeof(st_CaliSeg) * (btRSegNum + btVSegNum);

    return dwLen;
}
;
}
