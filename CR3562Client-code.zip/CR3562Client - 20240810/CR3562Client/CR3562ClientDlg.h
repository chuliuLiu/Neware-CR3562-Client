﻿
// CR3562ClientDlg.h: 头文件
//
#include"string"
#include<vector>
#include<map>
#include"SerialInterface.h"
#include"MacCnnctDev_Copy.h"
#include "MyfStream.h"
using namespace std;
using namespace MacCnnctDev_copy;

#pragma once


// CCR3562ClientDlg 对话框
class CCR3562ClientDlg : public CDialogEx
{
// 构造
public:
	CCR3562ClientDlg(CWnd* pParent = nullptr);	// 标准构造函数
	virtual ~CCR3562ClientDlg();
// 对话框数据
	enum { IDD = IDD_CR3562CLIENT_DIALOG ,
		ID_MENU_DEL_CALI_STATE = IDD + 1001,
		ID_MENU_Copy_CALI_STATE = IDD + 1002,
		};

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV 支持


// 实现
protected:
	HICON m_hIcon;

	// 生成的消息映射函数
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedOk();
	afx_msg void OnBnClickedBtnSearch();

public:
	void GetComList_Reg(std::vector<string>& comList);
	//bool cmp(string s1, string s2);
	void GetComFriendlyName();

public:
	CMenu menu;
	map<int, map<string, CString>> m_mpPortsName;
	SerialInterface m_SerialInterface;
	bool m_bConnect;
	int nConnectIndex;
	CString m_cstrConnectName;
	int m_nItem;
	int m_nSubItem;

	DWORD m_dwBtnStatus;//按钮状态 0-未连接，1-连接，2-发送，3-持续发送，4-校准，5-检测，6-升级

	bool m_bReConnect;

	//待合并为一个统一的数据结构
	bool m_bContinueSend;//持续发送
	bool m_bShowSend;//显示发送
	bool m_bShowTime;//显示时间
	UINT64 m_u64InterVal;//间隔
	bool m_bAimVolt;//目标为1-电压，0-电阻
	bool m_bUpdating;

	CaliStates m_CaliStates;

	//升级
	bool m_bCaliFile;
	CString m_strFilePath;//当前文件路径
	MyfStream m_FileStream;//文件流
	BYTE* m_buf;
	const DWORD BUF_maxsize = 1024;
	void* m_pThreadHandle;//线程句柄
	bool bLoadFile;//是否文件加载过了，加载过则支持打开重新选择文件，未加载过且文件存在则直接加载
	bool bFileLoading;//是否文件处于加载中
	bool m_bUpdateReady;

	//校准，校准点，校准kb，校准文件
	map<double, map<int, double>> m_mpCaliVPoint;
	map<double, map<int, double>> m_mpCaliRPoint;
	t_sCaliSeg m_CaliFile;
	//校准文件，校准码值
	map<double, map<double, double>> m_mpCliVPointMZValue;
	map<double, map<double, double>> m_mpCliRPointMZValue;
	double m_dVThreshold;//阈值百分比
	double m_dVAvgTS;//稳定的偏移
	map<double, double> m_mpVErr;
	double m_dRThreshold;//阈值百分比
	double m_dRAvgTS;//稳定的偏移
	map<double, double> m_mpRErr;
	
	bool m_bThreadUsing;

	
	afx_msg void OnBnClickedBtnConnect();
	afx_msg void OnBnClickedBtnSend();
	afx_msg void OnBnClickedBtnSet();
	afx_msg void OnBnClickedBtnCali();
	afx_msg void OnBnClickedBtnCheck();
	afx_msg void OnBnClickedCheckContinue();
	afx_msg void OnBnClickedRadioV();
	afx_msg void OnBnClickedRadioR();
	afx_msg void OnBnClickedBtnLoadfile();
	afx_msg void OnBnClickedBtnUpdate();
private:
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	const unsigned long m_nSendDataTimerID;//数据搜索回复定时器ID
	unsigned long m_nSendData;

public:
	void SetBtnStatus(DWORD dwStatus);

	void SendData();

	void EnableUpdate(bool bTag);
	void SetCaliCurrState(bool bVolt);//设置校准前激励电流状态，电压校准关，电阻校准开
	//bool FileExist(const string& strFilePath);
	bool CheckFile();
	bool LoadFile();
	bool InUpdate();//进入升级状态
	bool SendUpdateFile();

	void FreshCaliStates();//列表刷新
	string toLowerCase(const std::string& str);
	void InsertTips(const string strMess, const bool bErr);
	void InsertCaliStates(const int nitem, const CaliState caliState, const bool bErr);//新增消息
	CListCtrl m_ListRecvData;

	void ClearCaliStates();//清空消息
	afx_msg void OnNMRClickListResult(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnMenuDelCaliState();
	afx_msg void OnMenuCopyCaliState();

	afx_msg BOOL OnDeviceChange(UINT nEventType, DWORD_PTR dwData);
	afx_msg void OnCbnSelchangeComboSerialname();
	afx_msg void OnBnClickedCheckShowsend();
	afx_msg void OnBnClickedCheckShowtime();

	void UpdateCurrentRV(string strData,bool bData);

	void CaliMeter();
	void CurrCali();
	void UpdateMeter();
	bool bIsCR3562();

	void InitCaliParam();
	bool GetCaliParamFromFile();

	void InitTSValiParam();//合并到上面
	bool GetTSValiParamFromFile();

	//校准
	bool GetCaliFile();//获取校准文件
	bool UpdateCaliFile(t_sCaliSeg CaliFile);//更新校准文件
	bool UpdateCaliFileTiming();//更新校准文件日期和时间
	bool IssueCaliFile();//下发校准文件
	bool GetCaliFileFromData(char* cData, int Lenth);
	bool SetCaliFileToData(char* cData, int Lenth);

	bool SetRange(bool m_bIsV,double nRange);//切换量程
	bool GetPoint(bool m_bIsV,double nRange,int n,double dValue,double& dGetValue);//取点

	CProgressCtrl m_CaliProgress;
};
