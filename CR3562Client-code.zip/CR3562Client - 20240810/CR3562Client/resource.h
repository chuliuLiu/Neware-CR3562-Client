﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ 生成的包含文件。
// 供 CR3562Client.rc 使用
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_CR3562CLIENT_DIALOG         102
#define IDR_MAINFRAME                   128
#define IDR_MENU1                       130
#define IDD_DLG_SET                     131
#define IDC_BTN_Search                  1001
#define IDC_COMBO_SerialName            1002
#define IDC_BTN_Connect                 1003
#define IDC_BTN_Send                    1004
#define IDC_RADIO_V                     1006
#define IDC_RADIO_R                     1007
#define IDC_BTN_Cali                    1008
#define IDC_BTN_Check                   1009
#define IDC_EDIT_CMD                    1011
#define IDC_CHECK_Continue              1012
#define IDC_EDIT_Second                 1013
#define IDC_COMBO_BaudRate              1015
#define IDC_BTN_LoadFile                1016
#define IDC_COMBO_Databits              1016
#define IDC_COMBO3                      1017
#define IDC_BTN_Update                  1017
#define IDC_COMBO_Stopbits              1018
#define IDC_COMBO_FlowControl           1019
#define IDC_COMBO_Mode                  1020
#define IDC_COMBO_Type                  1021
#define IDC_COMBO_SegPointNum           1023
#define IDC_COMBO_Filepath              1024
#define IDC_STATIC_Checkbits            1025
#define IDC_LIST_Result                 1026
#define IDC_LIST_Point                  1027
#define IDC_CHECK_ShowSend              1028
#define IDC_CHECK_ShowTime              1029
#define IDC_EDIT_R                      1030
#define IDC_EDIT_V                      1031
#define IDC_EDIT_VoltSeg                1032
#define IDC_PROGRESS1                   1033
#define IDC_PROGRESS2                   1034
#define ID_Set                          32771

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1035
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
