﻿
// CR3562ClientDlg.cpp: 实现文件
//

#include "pch.h"
#include "framework.h"
#include "CR3562Client.h"
#include "CR3562ClientDlg.h"
#include "afxdialogex.h"
#include "SerialInterface.h"
#include <stdio.h>
#include <string>
#include <vector>
#include <algorithm>
#include <Windows.h>
#include <tchar.h>
#include <iostream>
#include <functional>
#include"Setting.h"

#include <devguid.h>
#include "setupapi.h"
#pragma comment(lib,"setupapi")

#include "DlgSet.h"
#include"CMyINI.h"
#include <thread>
#include <Dbt.h>

using namespace std;

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// 用于应用程序“关于”菜单项的 CAboutDlg 对话框

class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_ABOUTBOX };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 支持

// 实现
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialogEx(IDD_ABOUTBOX)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()


// CCR3562ClientDlg 对话框



CCR3562ClientDlg::CCR3562ClientDlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_CR3562CLIENT_DIALOG, pParent)
	, m_nSendDataTimerID(1)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);

	m_buf = new BYTE[BUF_maxsize];
	memset(m_buf, 0, BUF_maxsize);
	m_pThreadHandle = NULL;
	bLoadFile = false;
	bFileLoading = false;

	m_bCaliFile = false;

	m_bContinueSend = false;
	m_bShowSend = false;
	m_bShowTime = true;
	m_u64InterVal = 1000;
	m_bAimVolt = true;

	m_dwBtnStatus = 0;
	m_nSendData = 0;

	m_bUpdateReady = false;

	m_bReConnect = false;

	nConnectIndex = -1;
	m_cstrConnectName = "";

	m_nItem = -1;
	m_nSubItem = -1;

	m_bUpdating = false;
	m_bThreadUsing = false;
}

CCR3562ClientDlg::~CCR3562ClientDlg()
{
	m_FileStream.CloseFileStream();
	if (m_SerialInterface.isOpened()) {
		m_SerialInterface.closeComm();
		m_bConnect = false;
	}
	if (m_pThreadHandle) {
		std::thread* thrd = (std::thread*)m_pThreadHandle;
		thrd->join();
		delete thrd;
		m_pThreadHandle = NULL;
	}
	if (m_buf) {
		delete[] m_buf;
		m_buf = NULL;
	}
}

void CCR3562ClientDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST_Result, m_ListRecvData);
	DDX_Control(pDX, IDC_PROGRESS2, m_CaliProgress);
}

BEGIN_MESSAGE_MAP(CCR3562ClientDlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_TIMER()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDOK, &CCR3562ClientDlg::OnBnClickedOk)
	ON_BN_CLICKED(IDC_BTN_Search, &CCR3562ClientDlg::OnBnClickedBtnSearch)
	ON_BN_CLICKED(IDC_BTN_Connect, &CCR3562ClientDlg::OnBnClickedBtnConnect)
	ON_BN_CLICKED(IDC_BTN_Send, &CCR3562ClientDlg::OnBnClickedBtnSend)
	ON_COMMAND(32771, &CCR3562ClientDlg::OnBnClickedBtnSet)
	ON_BN_CLICKED(IDC_BTN_Cali, &CCR3562ClientDlg::OnBnClickedBtnCali)
	ON_BN_CLICKED(IDC_BTN_Check, &CCR3562ClientDlg::OnBnClickedBtnCheck)
	ON_BN_CLICKED(IDC_CHECK_Continue, &CCR3562ClientDlg::OnBnClickedCheckContinue)
	ON_BN_CLICKED(IDC_RADIO_V, &CCR3562ClientDlg::OnBnClickedRadioV)
	ON_BN_CLICKED(IDC_RADIO_R, &CCR3562ClientDlg::OnBnClickedRadioR)
	ON_BN_CLICKED(IDC_BTN_LoadFile, &CCR3562ClientDlg::OnBnClickedBtnLoadfile)
	ON_BN_CLICKED(IDC_BTN_Update, &CCR3562ClientDlg::OnBnClickedBtnUpdate)
	ON_NOTIFY(NM_RCLICK, IDC_LIST_Result, &CCR3562ClientDlg::OnNMRClickListResult)
	ON_COMMAND(ID_MENU_DEL_CALI_STATE, &CCR3562ClientDlg::OnMenuDelCaliState)
	ON_COMMAND(ID_MENU_Copy_CALI_STATE, &CCR3562ClientDlg::OnMenuCopyCaliState)
	ON_WM_DEVICECHANGE()
	ON_CBN_SELCHANGE(IDC_COMBO_SerialName, &CCR3562ClientDlg::OnCbnSelchangeComboSerialname)
	ON_BN_CLICKED(IDC_CHECK_ShowSend, &CCR3562ClientDlg::OnBnClickedCheckShowsend)
	ON_BN_CLICKED(IDC_CHECK_ShowTime, &CCR3562ClientDlg::OnBnClickedCheckShowtime)
END_MESSAGE_MAP()


// CCR3562ClientDlg 消息处理程序

BOOL CCR3562ClientDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// 将“关于...”菜单项添加到系统菜单中。

	// IDM_ABOUTBOX 必须在系统命令范围内。
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != nullptr)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// 设置此对话框的图标。  当应用程序主窗口不是对话框时，框架将自动
	//  执行此操作
	SetIcon(m_hIcon, TRUE);			// 设置大图标
	SetIcon(m_hIcon, FALSE);		// 设置小图标

	// TODO: 在此添加额外的初始化代码
	//加载菜单栏
	//menu.LoadMenu(IDR_MENU1);  //IDR_MENU1为菜单栏ID号
	//SetMenu(&menu);

	CString cstrData;

	cstrData = L"*IDN?";
	GetDlgItem(IDC_EDIT_CMD)->SetWindowText(cstrData);

	//通过配置显示是否持续输出，输出时间间隔
	((CButton*)GetDlgItem(IDC_CHECK_Continue))->SetCheck(m_bContinueSend);
	((CButton*)GetDlgItem(IDC_CHECK_ShowSend))->SetCheck(m_bShowSend);
	((CButton*)GetDlgItem(IDC_CHECK_ShowTime))->SetCheck(m_bShowTime);

	//cstrData = L"1";
	int nTime = m_u64InterVal / 1000;
	cstrData.Format(L"%d", nTime);
	GetDlgItem(IDC_EDIT_Second)->SetWindowText(cstrData);

	//通过配置显示校准目标
	if (m_bAimVolt)
	{
		((CButton*)GetDlgItem(IDC_RADIO_V))->SetCheck(true);
	}
	else
	{
		((CButton*)GetDlgItem(IDC_RADIO_R))->SetCheck(true);
	}

	m_ListRecvData.SetExtendedStyle(m_ListRecvData.GetExtendedStyle()//设置内阻仪表格风格
		| LVS_EX_GRIDLINES /*| LVS_EX_CHECKBOXES*//* | LVS_EX_TRACKSELECT*/ | LVS_EX_FULLROWSELECT | LVS_EX_DOUBLEBUFFER);
	int nIndex = 0;
	//m_ListRecvData.InsertColumn(nIndex++,
	//	L"类型", LVCFMT_LEFT, 100);
	m_ListRecvData.InsertColumn(nIndex++,
		L"提示", LVCFMT_LEFT, 460);
	m_ListRecvData.InsertColumn(nIndex++,
		L"时间", LVCFMT_LEFT, 240);

	//SetBtnStatus(m_dwBtnStatus);
	m_CaliProgress.ShowWindow(false);

	return TRUE;  // 除非将焦点设置到控件，否则返回 TRUE
}

void CCR3562ClientDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// 如果向对话框添加最小化按钮，则需要下面的代码
//  来绘制该图标。  对于使用文档/视图模型的 MFC 应用程序，
//  这将由框架自动完成。

void CCR3562ClientDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // 用于绘制的设备上下文

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// 使图标在工作区矩形中居中
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// 绘制图标
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

//当用户拖动最小化窗口时系统调用此函数取得光标
//显示。
HCURSOR CCR3562ClientDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}



void CCR3562ClientDlg::OnBnClickedOk()
{
	// TODO: 在此添加控件通知处理程序代码
	CDialogEx::OnOK();
}

bool cmp(string s1, string s2)
{
	if (atoi(s1.substr(3).c_str()) < atoi(s2.substr(3).c_str()))//升序
		return true;
	else
		return false;
}

//获取串口号
void CCR3562ClientDlg::GetComList_Reg(std::vector<string>& comList)
{
	HKEY hkey;
	int result;
	int i = 0;

	result = RegOpenKeyEx(HKEY_LOCAL_MACHINE,
		_T("Hardware\\DeviceMap\\SerialComm"),
		NULL,
		KEY_READ,
		&hkey);

	if (ERROR_SUCCESS == result)   //   打开串口注册表   
	{
		TCHAR portName[0x100], commName[0x100];
		DWORD dwLong, dwSize;
		do
		{
			dwSize = sizeof(portName) / sizeof(TCHAR);
			dwLong = dwSize;
			result = RegEnumValue(hkey, i, portName, &dwLong, NULL, NULL, (LPBYTE)commName, &dwSize);
			if (ERROR_NO_MORE_ITEMS == result)
			{
				//   枚举串口
				break;   //   commName就是串口名字"COM4"
			}

			int iLen = WideCharToMultiByte(CP_ACP, 0, commName, -1, NULL, 0, NULL, NULL);

			char* chRtn = new char[iLen * sizeof(char)];

			WideCharToMultiByte(CP_ACP, 0, commName, -1, chRtn, iLen, NULL, NULL);

			std::string strName(chRtn);

			comList.push_back(strName);
			i++;

			delete[] chRtn;
			chRtn = NULL;
		} while (1);

		RegCloseKey(hkey);
	}
}

void CCR3562ClientDlg::OnBnClickedBtnSearch()
{
	// TODO: 在此添加控件通知处理程序代码
	m_mpPortsName.clear();
	vector<string> comList;
	GetComList_Reg(comList);
	sort(comList.begin(), comList.end(), cmp);
	for (int i = 0; i < comList.size(); i++)
	{
		CString cstrCom;
		cstrCom = comList[i].c_str();		
		map<string, CString> mpPortName;
		mpPortName[comList[i]] = cstrCom;
		m_mpPortsName[i] = mpPortName;
	}
	
	//获取串口友好名称friendlyName
	GetComFriendlyName();

	for (size_t i = ((CComboBox*)GetDlgItem(IDC_COMBO_SerialName))->GetCount(); i !=0; i--)
	{
		((CComboBox*)GetDlgItem(IDC_COMBO_SerialName))->DeleteString(i-1);
	}
	
	for (map<int, map<string, CString>>::iterator it = m_mpPortsName.begin(); it !=m_mpPortsName.end(); it++)
	{
		((CComboBox*)GetDlgItem(IDC_COMBO_SerialName))->InsertString(it->first, it->second.begin()->second);
	}

	//增加组合框下拉列表的宽度
	this->SendDlgItemMessage( IDC_COMBO_SerialName, CB_SETDROPPEDWIDTH, 360, 0);
	((CComboBox*)GetDlgItem(IDC_COMBO_SerialName))->SetCurSel(0);
	nConnectIndex = 0;
}

//第二种方法
//获取串口友好名称friendlyName
VOID CCR3562ClientDlg::GetComFriendlyName()
{
	DWORD   i;
	CHAR    szBuf[256] = { 0 };
	TCHAR   FriendlyName[256] = { 0 };

	//构建系统存在的所有设备列表
	HDEVINFO hDevInfo = SetupDiGetClassDevs(NULL, NULL, NULL, DIGCF_PRESENT | DIGCF_ALLCLASSES);
	if (hDevInfo == INVALID_HANDLE_VALUE)
	{
		return;
	};
	//接口参数具体意义，请查看官方文档 https://docs.microsoft.com/en-us/windows/win32/api/setupapi/nf-setupapi-setupdigetclassdevsw
	SP_DEVINFO_DATA SpDevInfoData = { 0 };
	SpDevInfoData.cbSize = sizeof(SP_DEVINFO_DATA);
	for (i = 0; SetupDiEnumDeviceInfo(hDevInfo, i, &SpDevInfoData); i++)
	{

		if (!SetupDiGetDeviceRegistryProperty(hDevInfo, &SpDevInfoData, SPDRP_CLASS, NULL, (PBYTE)szBuf, sizeof(szBuf), 0))
		{
			continue;
		}
		else
		{
			int iLen = WideCharToMultiByte(CP_ACP, 0, (LPCWCH)szBuf, -1, NULL, 0, NULL, NULL);

			char* chRtn = new char[iLen * sizeof(char)];

			WideCharToMultiByte(CP_ACP, 0, (LPCWCH)szBuf, -1, chRtn, iLen, NULL, NULL);

			std::string strName(chRtn);
			if (strcmp(strName.c_str(), "Ports") != 0) //过滤端口
			{
				delete[] chRtn;
				chRtn = NULL;
				continue;
			}
			delete[] chRtn;
			chRtn = NULL;
		}

		if (SetupDiGetDeviceRegistryProperty(hDevInfo, &SpDevInfoData, SPDRP_FRIENDLYNAME, NULL, (PBYTE)FriendlyName, sizeof(FriendlyName), 0))
		{
			//((CComboBox*)GetDlgItem(IDC_COMBO_SerialName))->AddString(FriendlyName);
			string strName = CW2A(FriendlyName);
			for (map<int, map<string, CString>>::iterator it = m_mpPortsName.begin(); it !=m_mpPortsName.end(); it++)
			{
				if (strName.find(it->second.begin()->first)!=string::npos) //过滤端口
				{
					it->second.begin()->second += L"_";
					it->second.begin()->second += FriendlyName;
					break;
				}
			}
		}
	}
	SendDlgItemMessage(IDC_COMBO_SerialName, CB_SETCURSEL, 0, 0);
	if (hDevInfo)
		SetupDiDestroyDeviceInfoList(hDevInfo); //释放资源
}

//打开串口
//BOOL OpenUART(HWND hWnd)
//{
//	INT i, BegainIndex, EndIndex, Len;
//	std::string strTemp, strComName;
//	CHAR buf[256] = "";
//	CHAR tempBuf[256] = "";
//	CHAR ComName[16] = "";
//
//	//提取设备友好名称中的COM号
//	GetDlgItemText(hWnd, IDC_COMBO_SerialName, tempBuf, sizeof(tempBuf)); //获取组合框中的字符串
//	Len = strlen(tempBuf);
//	strTemp = tempBuf;
//	BegainIndex = strTemp.find('(');
//	EndIndex = strTemp.find(')');
//	for (i = 0; i < EndIndex - BegainIndex - 1; i++)
//	{
//		ComName[i] = tempBuf[BegainIndex + 1 + i];
//	}
//	strComName += "\\\\.\\"; //端口号大于9时，必须加入该字符串
//	strComName += ComName;
//
//	//打开串口
//	hCom = CreateFile((LPCTSTR)strComName.c_str(), GENERIC_READ | GENERIC_WRITE, 0, NULL, OPEN_EXISTING, FILE_FLAG_OVERLAPPED, NULL);
//	if (hCom == INVALID_HANDLE_VALUE)
//	{
//		return FALSE;
//	}
//	/*
//	串口设置…
//	*/
//	return TRUE;
//}




void CCR3562ClientDlg::OnTimer(UINT_PTR nIDEvent)
{
	if (nIDEvent == m_nSendDataTimerID) {
		SendData();
	}
}

void CCR3562ClientDlg::OnBnClickedBtnConnect()
{
	// TODO: 在此添加控件通知处理程序代码
	if (m_mpPortsName.find(nConnectIndex) == m_mpPortsName.end()) {
		return;
	}

	if (!m_bConnect) {
		string strName;
		if (m_mpPortsName[nConnectIndex].begin()->first.length() == 4) {
			strName = m_mpPortsName[nConnectIndex].begin()->first;
		}
		else{
			strName = "\\\\.\\";
			strName+= m_mpPortsName[nConnectIndex].begin()->first;
		}
		if (m_SerialInterface.openSyn(/*"\\\\.\\COM20"*/strName, CBR_115200, NOPARITY, 8, ONESTOPBIT))
		{
			if (bIsCR3562()) {
				//IDN?判断
				InsertTips("连接成功！", false);
				m_bConnect = true;
				m_bReConnect = false;
				m_dwBtnStatus = 1;
				SetBtnStatus(m_dwBtnStatus);
				m_cstrConnectName = m_mpPortsName[nConnectIndex].begin()->second;
			}
			else {
				if (m_SerialInterface.isOpened()) {
					m_SerialInterface.closeComm();
					m_bConnect = false;
					InsertTips("连接失败!", false);
					m_dwBtnStatus = 0;
					SetBtnStatus(m_dwBtnStatus);
					m_cstrConnectName = "";

					if (m_nSendData) {
						KillTimer(m_nSendDataTimerID);
						m_nSendData = 0;
					}
				}
			}
		}
		else
		{
			InsertTips("连接失败", false);
			m_dwBtnStatus = 0;
			SetBtnStatus(m_dwBtnStatus);
		}
	}
	else {
		if (m_SerialInterface.isOpened()) {
			m_SerialInterface.closeComm();
			m_bConnect = false;
			InsertTips("连接断开成功!", false);
			m_dwBtnStatus = 0;
			SetBtnStatus(m_dwBtnStatus);
			m_cstrConnectName = "";

			if (m_nSendData) {
				KillTimer(m_nSendDataTimerID);
				m_nSendData = 0;
			}
		}
	}
}


void CCR3562ClientDlg::OnBnClickedBtnSend()
{
	// TODO: 在此添加控件通知处理程序代码
	
	if (!m_bConnect) {
		InsertTips("未连接",false);
		return;
	}

	//判断状态
	if (m_dwBtnStatus == 1) {
		if (m_bContinueSend) {
			m_dwBtnStatus = 3;
			SetBtnStatus(m_dwBtnStatus);
			//启用线程
			CString cstrData;
			int nTimeInterval;
			GetDlgItem(IDC_EDIT_Second)->GetWindowText(cstrData);
			nTimeInterval = atoi(CW2A(cstrData));
			if (nTimeInterval == 0) {
				nTimeInterval = 1;
				cstrData.Format(L"%d", nTimeInterval);
				GetDlgItem(IDC_EDIT_Second)->SetWindowText(cstrData);
			}
			else if (nTimeInterval < 1) {
				nTimeInterval = 1;				
				cstrData.Format(L"%d", nTimeInterval);//%.1f
				GetDlgItem(IDC_EDIT_Second)->SetWindowText(cstrData);
			}
			m_u64InterVal = nTimeInterval * 1000;
			//启用定时器
			m_nSendData = SetTimer(m_nSendDataTimerID, m_u64InterVal, NULL);
		}
		else {
			m_dwBtnStatus = 2;
			SetBtnStatus(m_dwBtnStatus);
			SendData();
			m_dwBtnStatus = 1;
			SetBtnStatus(m_dwBtnStatus);
		}		
	}
	else if (/*m_dwBtnStatus == 2 ||*/ m_dwBtnStatus == 3) {
		//关闭线程
		if (m_nSendData) {
			KillTimer(m_nSendDataTimerID);
			m_nSendData = 0;
		}
		m_dwBtnStatus = 1;
		SetBtnStatus(m_dwBtnStatus);
	}

	
}

void CCR3562ClientDlg::OnBnClickedBtnSet() 
{
	DlgSet dlg;
	if (dlg.DoModal() == IDOK) {
		//替换配置参数
		//存配置文件
	}
}


void CCR3562ClientDlg::OnBnClickedBtnCali()
{
	// TODO: 在此添加控件通知处理程序代码
	//点击校准时会加载一次ini文件，若不存在ini文件或加载失败则使用初始化的校准参数
	m_mpCaliVPoint.clear();
	m_mpCaliRPoint.clear();
	if (GetCaliParamFromFile()) {

	}
	else {
		InitCaliParam();
	}

	/*if (GetTSValiParamFromFile()) {

	}
	else {
		InitTSValiParam();
	}*/
	
	if (!m_bConnect) {
		InsertTips("未连接", false);
		return;
	}

	if (!GetCaliFile()) {
		InsertTips("获取校准文件失败", false);
		return;
	}

	//判断状态
	if (m_dwBtnStatus == 1) {
		InsertTips("启动校准!", 1);
		if (m_pThreadHandle) {
			std::thread* thrd = (std::thread*)m_pThreadHandle;
			thrd->join();
			delete thrd;
			m_pThreadHandle = NULL;
		}
		m_bThreadUsing = true;
		std::thread* thrd = new std::thread(std::bind(&CCR3562ClientDlg::CaliMeter, this));//20221226 试一下用线程来插入
		m_pThreadHandle = (void*)thrd;
	}
	else if (m_dwBtnStatus == 4) {
		//关闭线程
		CString strMessage = L"正在校准，是否停止！";
		UINT uRes = MB_OK;
		uRes = MessageBoxEx(this->GetSafeHwnd()
			, strMessage, L"警告"
			, MB_OKCANCEL | MB_ICONQUESTION,
			MAKELANGID(LANG_CHINESE, SUBLANG_CHINESE_SIMPLIFIED));
		if (uRes == IDOK)
		{
			//bisCali = false;            
			//if (!IRMeter_OutCaliMode()) {}
			//20231010退出校准模式
			m_bThreadUsing = false;
			/*if (m_pThreadHandle) {
				std::thread* third = (std::thread*)m_pThreadHandle;
				third->join();
				delete third;
				m_pThreadHandle = NULL;
			}
			m_dwBtnStatus = 1;
			SetBtnStatus(m_dwBtnStatus);
			InsertTips("停止校准!", 1);*/
			return;
		}
		else {
			return;
		}
		
	}
}


void CCR3562ClientDlg::OnBnClickedBtnCheck()
{
	// TODO: 在此添加控件通知处理程序代码
}


void CCR3562ClientDlg::OnBnClickedCheckContinue()
{
	// TODO: 在此添加控件通知处理程序代码
	if (((CButton*)GetDlgItem(IDC_CHECK_Continue))->GetCheck()) {
		m_bContinueSend = true;
	}
	else {
		m_bContinueSend = false;
	}
}


void CCR3562ClientDlg::OnBnClickedRadioV()
{
	// TODO: 在此添加控件通知处理程序代码
	if (((CButton*)GetDlgItem(IDC_RADIO_V))->GetCheck()) {
		m_bAimVolt = true;
	}
	else {
		m_bAimVolt = false;
	}
}


void CCR3562ClientDlg::OnBnClickedRadioR()
{
	// TODO: 在此添加控件通知处理程序代码
	if (((CButton*)GetDlgItem(IDC_RADIO_R))->GetCheck()) {
		m_bAimVolt = false;
	}
	else {
		m_bAimVolt = true;
	}
}


void CCR3562ClientDlg::OnBnClickedBtnLoadfile()
{
	// TODO: 在此添加控件通知处理程序代码
	string strPath = CW2A(m_strFilePath);
	if (FileExist(strPath))//文件是否存在
	{
		if (!bLoadFile) {
			//直接加载文件
			if (CheckFile()) {
				//启用升级按钮
				EnableUpdate(true);
				m_bUpdateReady = true;
				bLoadFile = true;
			}
			else
			{
				bLoadFile = true;//若存在的文件并不是可用文件，支持重新加载
				m_bUpdateReady = false;
			}
		}
		else {
			//打开文件，加载文件
			if (LoadFile()) {
				if (CheckFile()) {
					//启用升级按钮
					EnableUpdate(true);
					m_bUpdateReady = true;
				}
				else
				{
					bLoadFile = true;//若存在的文件并不是可用文件，支持重新加载
					m_bUpdateReady = false;
				}
			}
		}
	}
	else {
		//打开文件，加载文件
		if (LoadFile()) {
			if (CheckFile()) {
				//启用升级按钮
				EnableUpdate(true);
				bLoadFile = true;
				m_bUpdateReady = true;
			}
			else
			{
				bLoadFile = true;//若存在的文件并不是可用文件，支持重新加载
				m_bUpdateReady = false;
			}
		}
	}
}


void CCR3562ClientDlg::OnBnClickedBtnUpdate()
{
	// TODO: 在此添加控件通知处理程序代码
	if (!m_bUpdating) {
		if (m_pThreadHandle) {
			std::thread* thrd = (std::thread*)m_pThreadHandle;
			thrd->join();
			delete thrd;
			m_pThreadHandle = NULL;
		}
		std::thread* thrd = new std::thread(std::bind(&CCR3562ClientDlg::UpdateMeter, this));//20221226 试一下用线程来插入
		m_pThreadHandle = (void*)thrd;
	}
	else {
		m_bUpdating = false;
	}	
}

void CCR3562ClientDlg::SetBtnStatus(DWORD dwStatus)
{
	switch (dwStatus)
	{case 0:
		GetDlgItem(IDC_COMBO_SerialName)->EnableWindow(true);
		GetDlgItem(IDC_BTN_Search)->EnableWindow(true);
		GetDlgItem(IDC_BTN_Connect)->EnableWindow(true);
		GetDlgItem(IDC_EDIT_CMD)->EnableWindow(false);
		GetDlgItem(IDC_CHECK_Continue)->EnableWindow(false);
		GetDlgItem(IDC_CHECK_ShowSend)->EnableWindow(false);
		GetDlgItem(IDC_CHECK_ShowTime)->EnableWindow(false);
		GetDlgItem(IDC_EDIT_Second)->EnableWindow(false);
		GetDlgItem(IDC_BTN_Send)->EnableWindow(false);
		GetDlgItem(IDC_RADIO_V)->EnableWindow(false);
		GetDlgItem(IDC_RADIO_R)->EnableWindow(false);
		GetDlgItem(IDC_BTN_Cali)->EnableWindow(false);
		GetDlgItem(IDC_BTN_Check)->EnableWindow(false);
		GetDlgItem(IDC_COMBO_Filepath)->EnableWindow(false);
		GetDlgItem(IDC_BTN_LoadFile)->EnableWindow(false);
		GetDlgItem(IDC_BTN_Update)->EnableWindow(false);
		GetDlgItem(IDC_BTN_Connect)->SetWindowText(L"连接");
		GetDlgItem(IDC_BTN_Send)->SetWindowText(L"发送");
		GetDlgItem(IDC_BTN_Cali)->SetWindowText(L"校准");
		GetDlgItem(IDC_BTN_Check)->SetWindowText(L"检测");
		GetDlgItem(IDC_BTN_Update)->SetWindowText(L"升级");
		break;
	case 1:
		GetDlgItem(IDC_COMBO_SerialName)->EnableWindow(false);
		GetDlgItem(IDC_BTN_Search)->EnableWindow(false);
		GetDlgItem(IDC_BTN_Connect)->EnableWindow(true);
		GetDlgItem(IDC_EDIT_CMD)->EnableWindow(true);
		GetDlgItem(IDC_CHECK_Continue)->EnableWindow(true);
		GetDlgItem(IDC_CHECK_ShowSend)->EnableWindow(true);
		GetDlgItem(IDC_CHECK_ShowTime)->EnableWindow(true);
		GetDlgItem(IDC_EDIT_Second)->EnableWindow(true);
		GetDlgItem(IDC_BTN_Send)->EnableWindow(true);
		GetDlgItem(IDC_RADIO_V)->EnableWindow(true);
		GetDlgItem(IDC_RADIO_R)->EnableWindow(true);
		GetDlgItem(IDC_BTN_Cali)->EnableWindow(true);
		GetDlgItem(IDC_BTN_Check)->EnableWindow(true);
		GetDlgItem(IDC_COMBO_Filepath)->EnableWindow(true);
		GetDlgItem(IDC_BTN_LoadFile)->EnableWindow(true);
		GetDlgItem(IDC_BTN_Update)->EnableWindow(true);
		GetDlgItem(IDC_BTN_Connect)->SetWindowText(L"断开");
		GetDlgItem(IDC_BTN_Send)->SetWindowText(L"发送");
		GetDlgItem(IDC_BTN_Cali)->SetWindowText(L"校准");
		GetDlgItem(IDC_BTN_Check)->SetWindowText(L"检测");
		GetDlgItem(IDC_BTN_Update)->SetWindowText(L"升级");
		break;
	case 2:
		GetDlgItem(IDC_COMBO_SerialName)->EnableWindow(false);
		GetDlgItem(IDC_BTN_Search)->EnableWindow(false);
		GetDlgItem(IDC_BTN_Connect)->EnableWindow(false);
		GetDlgItem(IDC_EDIT_CMD)->EnableWindow(false);
		GetDlgItem(IDC_CHECK_Continue)->EnableWindow(false);
		GetDlgItem(IDC_CHECK_ShowSend)->EnableWindow(false);
		GetDlgItem(IDC_CHECK_ShowTime)->EnableWindow(false);
		GetDlgItem(IDC_EDIT_Second)->EnableWindow(false);
		GetDlgItem(IDC_BTN_Send)->EnableWindow(true);
		GetDlgItem(IDC_RADIO_V)->EnableWindow(false);
		GetDlgItem(IDC_RADIO_R)->EnableWindow(false);
		GetDlgItem(IDC_BTN_Cali)->EnableWindow(false);
		GetDlgItem(IDC_BTN_Check)->EnableWindow(false);
		GetDlgItem(IDC_COMBO_Filepath)->EnableWindow(false);
		GetDlgItem(IDC_BTN_LoadFile)->EnableWindow(false);
		GetDlgItem(IDC_BTN_Update)->EnableWindow(false);
		GetDlgItem(IDC_BTN_Connect)->SetWindowText(L"断开");
		GetDlgItem(IDC_BTN_Send)->SetWindowText(L"发送");
		GetDlgItem(IDC_BTN_Cali)->SetWindowText(L"校准");
		GetDlgItem(IDC_BTN_Check)->SetWindowText(L"检测");
		GetDlgItem(IDC_BTN_Update)->SetWindowText(L"升级");
		break;
	case 3:
		GetDlgItem(IDC_COMBO_SerialName)->EnableWindow(false);
		GetDlgItem(IDC_BTN_Search)->EnableWindow(false);
		GetDlgItem(IDC_BTN_Connect)->EnableWindow(false);
		GetDlgItem(IDC_EDIT_CMD)->EnableWindow(false);
		GetDlgItem(IDC_CHECK_Continue)->EnableWindow(false);
		GetDlgItem(IDC_CHECK_ShowSend)->EnableWindow(false);
		GetDlgItem(IDC_CHECK_ShowTime)->EnableWindow(false);
		GetDlgItem(IDC_EDIT_Second)->EnableWindow(false);
		GetDlgItem(IDC_BTN_Send)->EnableWindow(true);
		GetDlgItem(IDC_RADIO_V)->EnableWindow(false);
		GetDlgItem(IDC_RADIO_R)->EnableWindow(false);
		GetDlgItem(IDC_BTN_Cali)->EnableWindow(false);
		GetDlgItem(IDC_BTN_Check)->EnableWindow(false);
		GetDlgItem(IDC_COMBO_Filepath)->EnableWindow(false);
		GetDlgItem(IDC_BTN_LoadFile)->EnableWindow(false);
		GetDlgItem(IDC_BTN_Update)->EnableWindow(false);
		GetDlgItem(IDC_BTN_Connect)->SetWindowText(L"断开");
		GetDlgItem(IDC_BTN_Send)->SetWindowText(L"停止");
		GetDlgItem(IDC_BTN_Cali)->SetWindowText(L"校准");
		GetDlgItem(IDC_BTN_Check)->SetWindowText(L"检测");
		GetDlgItem(IDC_BTN_Update)->SetWindowText(L"升级");
		break;
	case 4:
		GetDlgItem(IDC_COMBO_SerialName)->EnableWindow(false);
		GetDlgItem(IDC_BTN_Search)->EnableWindow(false);
		GetDlgItem(IDC_BTN_Connect)->EnableWindow(false);
		GetDlgItem(IDC_EDIT_CMD)->EnableWindow(false);
		GetDlgItem(IDC_CHECK_Continue)->EnableWindow(false);
		GetDlgItem(IDC_CHECK_ShowSend)->EnableWindow(false);
		GetDlgItem(IDC_CHECK_ShowTime)->EnableWindow(false);
		GetDlgItem(IDC_EDIT_Second)->EnableWindow(false);
		GetDlgItem(IDC_BTN_Send)->EnableWindow(false);
		GetDlgItem(IDC_RADIO_V)->EnableWindow(false);
		GetDlgItem(IDC_RADIO_R)->EnableWindow(false);
		GetDlgItem(IDC_BTN_Cali)->EnableWindow(true);
		GetDlgItem(IDC_BTN_Check)->EnableWindow(false);
		GetDlgItem(IDC_COMBO_Filepath)->EnableWindow(false);
		GetDlgItem(IDC_BTN_LoadFile)->EnableWindow(false);
		GetDlgItem(IDC_BTN_Update)->EnableWindow(false);
		GetDlgItem(IDC_BTN_Connect)->SetWindowText(L"断开");
		GetDlgItem(IDC_BTN_Send)->SetWindowText(L"发送");
		GetDlgItem(IDC_BTN_Cali)->SetWindowText(L"停止");
		GetDlgItem(IDC_BTN_Check)->SetWindowText(L"检测");
		GetDlgItem(IDC_BTN_Update)->SetWindowText(L"升级");
		break;
	case 5:
		GetDlgItem(IDC_COMBO_SerialName)->EnableWindow(false);
		GetDlgItem(IDC_BTN_Search)->EnableWindow(false);
		GetDlgItem(IDC_BTN_Connect)->EnableWindow(false);
		GetDlgItem(IDC_EDIT_CMD)->EnableWindow(false);
		GetDlgItem(IDC_CHECK_Continue)->EnableWindow(false);
		GetDlgItem(IDC_CHECK_ShowSend)->EnableWindow(false);
		GetDlgItem(IDC_CHECK_ShowTime)->EnableWindow(false);
		GetDlgItem(IDC_EDIT_Second)->EnableWindow(false);
		GetDlgItem(IDC_BTN_Send)->EnableWindow(false);
		GetDlgItem(IDC_RADIO_V)->EnableWindow(false);
		GetDlgItem(IDC_RADIO_R)->EnableWindow(false);
		GetDlgItem(IDC_BTN_Cali)->EnableWindow(false);
		GetDlgItem(IDC_BTN_Check)->EnableWindow(true);
		GetDlgItem(IDC_COMBO_Filepath)->EnableWindow(false);
		GetDlgItem(IDC_BTN_LoadFile)->EnableWindow(false);
		GetDlgItem(IDC_BTN_Update)->EnableWindow(false);
		GetDlgItem(IDC_BTN_Connect)->SetWindowText(L"断开");
		GetDlgItem(IDC_BTN_Send)->SetWindowText(L"发送");
		GetDlgItem(IDC_BTN_Cali)->SetWindowText(L"校准");
		GetDlgItem(IDC_BTN_Check)->SetWindowText(L"停止");
		GetDlgItem(IDC_BTN_Update)->SetWindowText(L"升级");
		break;
	case 6:
		GetDlgItem(IDC_COMBO_SerialName)->EnableWindow(false);
		GetDlgItem(IDC_BTN_Search)->EnableWindow(false);
		GetDlgItem(IDC_BTN_Connect)->EnableWindow(false);
		GetDlgItem(IDC_EDIT_CMD)->EnableWindow(false);
		GetDlgItem(IDC_CHECK_Continue)->EnableWindow(false);
		GetDlgItem(IDC_CHECK_ShowSend)->EnableWindow(false);
		GetDlgItem(IDC_CHECK_ShowTime)->EnableWindow(false);
		GetDlgItem(IDC_EDIT_Second)->EnableWindow(false);
		GetDlgItem(IDC_BTN_Send)->EnableWindow(false);
		GetDlgItem(IDC_RADIO_V)->EnableWindow(false);
		GetDlgItem(IDC_RADIO_R)->EnableWindow(false);
		GetDlgItem(IDC_BTN_Cali)->EnableWindow(false);
		GetDlgItem(IDC_BTN_Check)->EnableWindow(false);
		GetDlgItem(IDC_COMBO_Filepath)->EnableWindow(false);
		GetDlgItem(IDC_BTN_LoadFile)->EnableWindow(false);
		GetDlgItem(IDC_BTN_Update)->EnableWindow(true);
		GetDlgItem(IDC_BTN_Connect)->SetWindowText(L"断开");
		GetDlgItem(IDC_BTN_Send)->SetWindowText(L"发送");
		GetDlgItem(IDC_BTN_Cali)->SetWindowText(L"校准");
		GetDlgItem(IDC_BTN_Check)->SetWindowText(L"检测");
		GetDlgItem(IDC_BTN_Update)->SetWindowText(L"停止");
		break;
	default:
		break;
	}
}

void CCR3562ClientDlg::SendData()
{
	if (!m_bConnect || m_bReConnect) {
		return;
	}

	char cRecv[1024] = { 0 };
	bool bSendSuccess = false;
	bool bSendFetch = false;
	CString cstrData;
	GetDlgItem(IDC_EDIT_CMD)->GetWindowText(cstrData);

	string strData /*= ":IPOX:IP?\r\n"*/;
	strData = CW2A(cstrData);
	strData += "\r\n";
	if (strData.find(":FETCh?") != string::npos) {
		bSendFetch = true;
	}
	if (m_bShowSend) {
		InsertTips(strData, false);
	}	
	memcpy(cRecv, strData.c_str(),min(sizeof(cRecv),strData.length()));
	if (m_SerialInterface.writeData(cRecv, min(sizeof(cRecv), strData.length()))) {
		bSendSuccess = true;
	}
	else {
		InsertTips("发送失败", false);
	}

	memset(cRecv, 0, sizeof(cRecv));
	if (bSendSuccess) {
		Sleep(50);
		if (m_SerialInterface.readData(cRecv, sizeof(cRecv))){
			cstrData = cRecv;
			string strData = CW2A(cstrData);
			InsertTips(strData, false);
			UpdateCurrentRV(strData, bSendFetch);
		}
		else {

		}
	}
}

void CCR3562ClientDlg::EnableUpdate(bool bTag)
{
	if (m_bConnect) {
		GetDlgItem(IDC_BTN_Update)->EnableWindow(bTag);
	}
	else {
		GetDlgItem(IDC_BTN_Update)->EnableWindow(false);
	}
}

void CCR3562ClientDlg::SetCaliCurrState(bool bVolt) {
	const unsigned long nLenBufMax = 1024;
	char Buf[nLenBufMax] = { 0 };

	bool bSendSuccess = false;
	CString cstrData;

	string strData;
	if (!bVolt) {//电阻
		strData = ":CURRent:STATe ON\r\n";
	}
	else {//电压
		strData = ":CURRent:STATe OFF\r\n";
	}
	
	memcpy(Buf, strData.c_str(), min(sizeof(Buf), strData.length()));
	if (m_SerialInterface.writeData(Buf, min(sizeof(Buf), strData.length()))) {
		bSendSuccess = true;
	}
	else {
	}
	Sleep(1000);
}

//bool CCR3562ClientDlg::FileExist(const string& strFilePath)
//{
//	WIN32_FIND_DATAA fd;
//	HANDLE hFind = FindFirstFileA(strFilePath.c_str(), &fd);
//	bool bRtrn = (hFind != INVALID_HANDLE_VALUE);
//	if (hFind != INVALID_HANDLE_VALUE) {
//		FindClose(hFind);
//		hFind = INVALID_HANDLE_VALUE;
//	}
//	return bRtrn;
//}

bool CCR3562ClientDlg::CheckFile()
{
	if (bFileLoading) {
		//关闭文件
		m_FileStream.CloseFileStream();
		bFileLoading = false;
	}
	//加载文件
	string strMess = "加载文件:";
	strMess += CW2A(m_strFilePath);
	//AddMessage(cstrMess);
	InsertTips(strMess,false);
	if (!m_FileStream.LoadFileStream(m_strFilePath)) {
		strMess = "文件加载失败";
		//AddMessage(cstrMess);
		InsertTips(strMess, false);
		return false;
	}
	bFileLoading = true;
	strMess = "文件加载完毕，开始文件校验";
	//AddMessage(cstrMess);
	InsertTips(strMess, false);
	string strErr;
	//检查开始，结束，crc
	if (!m_FileStream.GetUpdateData(strErr)) {
		//clogstrerr
		//升级文件加载失败，进行校准文件判断
		//if (m_FileStream.GetCaliUpdateData(strErr)) {
		//	string strNuid = MacCnnctDev_copy::UintToHexStr(m_FileStream.m_st_CaliFile.dwDevNuid);
		//	if (strNuid == /*m_MeterMidInfo.GetNuid()*/"xxxxxxxx") {
		//		strMess = "校准文件检测通过，可下发 ";
		//		//AddMessage(cstrMess);
		//		InsertTips(strMess, false);
		//		m_bCaliFile = true;
		//		return true;
		//	}
		//	else {
		//		strMess = "校准文件检测异常，不可下发 ";
		//		//AddMessage(cstrMess);
		//		InsertTips(strMess, false);
		//		return false;
		//	}

		//}
		//else {
		//	strMess = "文件检测异常，无法用于升级";
		//	//AddMessage(cstrMess);
		//	InsertTips(strMess, false);
		//	EnableUpdate(false);
		//	return false;
		//}
		strMess = "文件检测异常，无法用于升级";
		//AddMessage(cstrMess);
		InsertTips(strMess, false);
		EnableUpdate(false);
		return false;
	}
	m_bCaliFile = false;
	strMess = "文件检测通过，可用于升级 ";
	/*string strVer = UintToHexStr(m_FileStream.m_sUpdateData.usVersion);
	switch (m_FileStream.GetTYPE())
	{
	case 1:
		cstrMess += "mcu";
		break;
	case 2:
		cstrMess += "fpga";
		break;
	case 3:
		cstrMess += "lcd";
		break;
	case 4:
		cstrMess += "btl";
		break;
	default:
		break;
	}*/
	//AddMessage(cstrMess);
	InsertTips(strMess, false);
	//strMess = "当前版本：";
	//cstrMess += GetCurrVer(m_FileStream.GetTYPE()).c_str();
	//strMess += "；\r\n升级文件版本：";
	//cstrMess += GetUpdateVer(m_FileStream.GetVer()).c_str();
	//strMess += "；";
	//strMess += m_FileStream.GetBuildDate().c_str();
	//strMess += m_FileStream.GetBuildTime().c_str();
	//AddMessage(cstrMess);
	//InsertTips(strMess,false);
	//检查版本适配


	return true;
}

bool CCR3562ClientDlg::LoadFile()
{
	bool bLoad = false;

	CFileDialog filedlg(TRUE, NULL, NULL, NULL, _T("*.*||"), NULL);//mcu(*.mcu)|*.mcu|fpga(*.fpga)|*.fpga|lcd(*.lcd)|*.lcd||
	if (filedlg.DoModal() == IDOK) {
		m_strFilePath = filedlg.GetPathName();
		GetDlgItem(IDC_COMBO_Filepath)->SetWindowText(m_strFilePath);
		//判断

		bLoad = true;
	}
	return bLoad;
}

bool CCR3562ClientDlg::InUpdate() {
	const unsigned long nLenBufMax = 1024;
	char Buf[nLenBufMax] = { 0 };

	//
	bool bSendSuccess = false;
	bool bSendFetch = false;
	CString cstrData;

	string strData;
	strData = "*IDN?\r\n";
	memcpy(Buf, strData.c_str(), min(sizeof(Buf), strData.length()));
	if (m_SerialInterface.writeData(Buf, min(sizeof(Buf), strData.length()))) {
		bSendSuccess = true;
	}
	else {
	}

	memset(Buf, 0, sizeof(Buf));
	if (bSendSuccess) {
		Sleep(1000);
		if (m_SerialInterface.readData(Buf, sizeof(Buf))) {
			cstrData = Buf;
			string strData = CW2A(cstrData);
			strData= toLowerCase(strData);
			if (strData.find("boot") != string::npos) {
				return true;
			}
		}
		else {

		}
	}

	memset(Buf, 0, sizeof(Buf));

	//发送命令设置电压量程
	string strCmd;
	strCmd = ":REBOOT";//string("MEASure:VOLTage:DC?\n");
	//strCmd += to_string(m_FileStream.m_sUpdateData.size());
	strCmd += "\r\n";
	/*CLog::Instance()->LOG_WriteLine(LOG_INFO_ERROR, Log_Update,
		"%s:sendtoIRMeter\"%s\""
		, __FUNCTION__, strCmd.c_str());*/
	memset(Buf, 0, nLenBufMax);
	memcpy(Buf, strCmd.c_str(), strCmd.length());
	if (!m_SerialInterface.writeData(Buf, strCmd.length())) {
		//CLog::Instance()->LOG_WriteLine(eLog_CaliSendMeter10, strCmd);
		DWORD dwErrorCode = ::GetLastError();
		//CLog::Instance()->LOG_WriteLine(LOG_INFO_ERROR, Log_Update,
		//	"%s:数据发送失败，错误码%u"
		//	, __FUNCTION__, dwErrorCode);
		//if (dwErrorCode == WSAECONNRESET) {//发现网线断开，需要尝试重连
		//	OnDisconnect();
		//	Invalidate();
		//}
		return false;
	}
	else {
	}
	Sleep(1000);

	memset(Buf, 0, sizeof(Buf));
	strData = "*IDN?\r\n";
	memcpy(Buf, strData.c_str(), min(sizeof(Buf), strData.length()));
	if (m_SerialInterface.writeData(Buf, min(sizeof(Buf), strData.length()))) {
		bSendSuccess = true;
	}
	else {
	}

	memset(Buf, 0, sizeof(Buf));
	if (bSendSuccess) {
		Sleep(1000);
		if (m_SerialInterface.readData(Buf, sizeof(Buf))) {
			cstrData = Buf;
			string strData = CW2A(cstrData);
			strData = toLowerCase(strData);
			if (strData.find("boot") != string::npos) {
				return true;
			}
		}
		else {

		}
	}

	return true;
}
bool CCR3562ClientDlg::SendUpdateFile() {
	
	m_bUpdating = true;
	const unsigned long nLenBufMax = 1024;
	char Buf[nLenBufMax] = { 0 };

	int nSendLen = sizeof(WORD) * 5 + 128;
	int nSeg = m_FileStream.m_sUpdateData.size();
	string strData;
	//CString cstrData;
	int nRate = 10;
	//for (size_t i = 0; i < nSeg; i++)
	size_t i = 0;
	while(i<nSeg)
	{
		if (!m_bUpdating) {
			strData = "主动停止";
			InsertTips(strData, false);
			return false;
		}
		memset(Buf, 0, nLenBufMax);
		//nSendLen = nLenBufMax;
		//发送命令设置电压量程
		//m_FileStream.GetBuffer((byte*)Buf, i * 1024, nSendLen);
		char* pbuf = Buf;
		*(WORD*)pbuf = m_FileStream.m_sUpdateData[i].unBeginFlag;
		pbuf += sizeof(WORD);
		*(WORD*)pbuf = m_FileStream.m_sUpdateData[i].unPackIndex;
		pbuf += sizeof(WORD);
		*(WORD*)pbuf = m_FileStream.m_sUpdateData[i].unPackLen;
		pbuf += sizeof(WORD);
		memcpy(pbuf, (char*)m_FileStream.m_sUpdateData[i].pucData, sizeof(m_FileStream.m_sUpdateData[i].pucData));
		pbuf += sizeof(m_FileStream.m_sUpdateData[i].pucData);
		*(WORD*)pbuf = m_FileStream.m_sUpdateData[i].unDataCRC32;
		pbuf += sizeof(WORD);
		*(WORD*)pbuf = m_FileStream.m_sUpdateData[i].unEndFlag;
		pbuf += sizeof(WORD);

		if (!m_SerialInterface.writeData(Buf, nSendLen)) {
			//CLog::Instance()->LOG_WriteLine(eLog_CaliSendMeter10, strCmd);
			//DWORD dwErrorCode = ::GetLastError();
			//CLog::Instance()->LOG_WriteLine(LOG_INFO_ERROR, Log_Update,
			//	"%s:数据发送失败，错误码%u"
			//	, __FUNCTION__, dwErrorCode);
			//if (dwErrorCode == WSAECONNRESET) {//发现网线断开，需要尝试重连
			//	OnDisconnect();
			//	Invalidate();
			//}
			return false;
		}
		else {
		}

		//strData = MacCnnctDev_copy::Format("SendPack:%d％", i + 1);
		//cstrData = strData.c_str();
		//AddMessage(cstrData);
		//InsertTips(strData, false);		

		bool bOffset = true;
		int nTime = 5000;
		while (nTime--) {
			//Sleep(10);
			if (!m_bUpdating) {
				return false;
			}
			memset(Buf, 0, sizeof(Buf));
			if (m_SerialInterface.readData(Buf, sizeof(Buf))/*==10*/) {
				pbuf = Buf;
				t_sUpdatePerDataBack m_Back;
				m_Back.unBeginFlag = *(WORD*)pbuf;
				pbuf += sizeof(WORD);
				m_Back.unPackError = *(WORD*)pbuf;
				pbuf += sizeof(WORD);
				m_Back.unPackIndex = *(WORD*)pbuf;
				pbuf += sizeof(WORD);
				m_Back.unPackIndexC = *(WORD*)pbuf;
				pbuf += sizeof(WORD);
				m_Back.unEndFlag = *(WORD*)pbuf;
				pbuf += sizeof(WORD);
				WORD wBack = ~m_Back.unPackIndexC;
				//if (m_Back.unBeginFlag != 0x5555 || m_Back.unEndFlag != 0xAAAA || m_Back.unPackIndex != wBack) {
				//	//return false;
				//	continue;
				//}
				//else if (m_Back.unPackError != 0) {
				//	if(i > 0) {
				//		i--;
				//	}				
				//	//return false;
				//	continue;
				//}
				//else 
				//if (i != m_Back.unPackIndex - 1 && i!= nSeg-1) {
				//	i = m_Back.unPackIndex /*- 1*/;
				//	Sleep(100);
				//	continue;
				//}
				if (i >= nSeg - 1) {
					if (m_Back.unPackIndex != 0xFFFF) {
						continue;
					}
				}
				i = m_Back.unPackIndex /*- 1*/;
				Sleep(50);

				if (i > nSeg * nRate / 100) {
					string strData = MacCnnctDev_copy::Format("SendPack:%d％ Success", nRate);
					InsertTips(strData, false);
					nRate += 10;
				}
				
				bOffset = false;
				break;
			}
			else {
				Sleep(1);
				continue;
			}
		}
		if (bOffset) {
			strData = "升级超时";
			//cstrData = strData.c_str();
			InsertTips(strData, false);
			return false;
		}
		
		//Sleep(100);
		
	}
	//if (i >= nSeg) {
	//	string strData = MacCnnctDev_copy::Format("SendPack:%d％ Success", nRate);
	//	InsertTips(strData, false);
	//	//break;
	//}

	strData = MacCnnctDev_copy::Format("Update Now");
	//cstrData = strData.c_str();
	InsertTips(strData, false);
	//AddMessage(cstrData);

	//switch (m_FileStream.m_sUpdateData.ucType)
	//{
	//case 1:
	//	Sleep(1000);
	//	break;
	//case 2:
	//	Sleep(1000);
	//	break;
	//case 3:
	//	Sleep(10000);
	//	break;
	//case 4:
	//	Sleep(1000);
	//	break;
	//default:
	//	break;
	//}
	m_FileStream.CloseFileStream();
	//OnDisconnect();
	return false;
}

// FILEPATH: 
string CCR3562ClientDlg::toLowerCase(const std::string& str) {
	std::string result;
	for (const char c : str) {
		result.push_back(static_cast<char>(std::tolower(static_cast<unsigned char>(c))));
	}
	return result;
}


void CCR3562ClientDlg::FreshCaliStates() {
	m_ListRecvData.DeleteAllItems();
	CString cstrData;
	for (size_t i = 0; i < m_CaliStates.m_vcCaliState.size(); i++)
	{
		int col = 0;
		//cstrData = m_CaliStates.m_vcCaliState[i].m_chSN;
		//m_ListRecvData.InsertItem(i, cstrData); col++;
		cstrData = m_CaliStates.m_vcCaliState[i].strMessage.c_str();
		m_ListRecvData.SetItemText(i, col, cstrData); col++;
		cstrData = UInt64MicroSecondsToStrTime(m_CaliStates.m_vcCaliState[i].u64Time).c_str();
		m_ListRecvData.SetItemText(i, col, cstrData);
	}
}

void CCR3562ClientDlg::InsertTips(const string strMess, const bool bErr) {
	CaliState caliState;
	string strData = "tip"/*m_IRMeterMid.GetStrDEVType() + "," + m_IRMeterMid.GetStrSN()*/;
	memcpy(caliState.m_chSN, strData.c_str(), min(sizeof(caliState.m_chSN), strData.length()));
	caliState.strMessage = strMess;
	caliState.u64Time = GetTimeMicroSeconds();
	int i = m_CaliStates.m_vcCaliState.size();
	InsertCaliStates(i, caliState, bErr);
	m_CaliStates.m_vcCaliState.push_back(caliState);
}

void CCR3562ClientDlg::InsertCaliStates(const int nitem, const CaliState caliState, const bool bErr) {
	//正序输出用nitem，逆序直接首行插入
	CString cstrData;
	int col = 0;
	//cstrData = caliState.m_chSN;
	//m_ListRecvData.InsertItem(0, cstrData); col++;
	cstrData = caliState.strMessage.c_str();
	m_ListRecvData.InsertItem(0, cstrData); col++;
	//m_ListRecvData.SetItemText(0, col, cstrData); col++;
	if (m_bShowTime) {
		cstrData = UInt64MicroSecondsToStrTime(caliState.u64Time).c_str();
		m_ListRecvData.SetItemText(0, col, cstrData);
	}	
	if (bErr) {//当前无效，考虑重新列表
		m_ListRecvData.SetItemData(0, RGB(100, 0, 0));
	}
}

void CCR3562ClientDlg::ClearCaliStates() {
	m_CaliStates.m_vcCaliState.clear();
	m_ListRecvData.DeleteAllItems();
	Invalidate();
}

void CCR3562ClientDlg::OnNMRClickListResult(NMHDR* pNMHDR, LRESULT* pResult)
{	

	LPNMITEMACTIVATE pNMItemActivate = reinterpret_cast<LPNMITEMACTIVATE>(pNMHDR);
	// TODO: 在此添加控件通知处理程序代码
	m_nItem = -1;
	m_nSubItem = -1;

	if (pNMItemActivate)
	{
		m_nItem = pNMItemActivate->iItem;
		m_nSubItem = pNMItemActivate->iSubItem;
	}

	if (m_nItem == -1)
	{
		return;
	}

	CMenu menu;
	CMenu menuSub;
	menu.CreatePopupMenu();
	menu.AppendMenu(MF_STRING, ID_MENU_DEL_CALI_STATE, L"清空");
	menu.AppendMenu(MF_STRING, ID_MENU_Copy_CALI_STATE, L"复制");

	CPoint pt;
	::GetCursorPos(&pt);
	menu.TrackPopupMenu(TPM_LEFTALIGN | TPM_RIGHTBUTTON, pt.x, pt.y, this);

	*pResult = 0;
	
}

void CCR3562ClientDlg::OnMenuDelCaliState()
{
	ClearCaliStates();
}

void CCR3562ClientDlg::OnMenuCopyCaliState()
{
	CString	strAisMsg;
	int	nItem;

	TCHAR* pszData;
	HGLOBAL	hClipboardData;

	/*nItem = m_ListRecvData.GetSelectionMark();

	if (nItem != -1)
	{
		strAisMsg = m_ListRecvData.GetItemText(nItem, 0);
	}
	
	string strCopyData = CW2A(strAisMsg);*/
	string strCopyData = "";

	POSITION   pos = m_ListRecvData.GetFirstSelectedItemPosition();
	while (pos != NULL)
	{
		nItem = m_ListRecvData.GetNextSelectedItem(pos);
		//在这里添加处理函数
		if (nItem != -1)
		{
			strAisMsg = m_ListRecvData.GetItemText(nItem, 0);
		}

		strCopyData+= CW2A(strAisMsg);
	}	

	//复制剪切板
	if (!strAisMsg.IsEmpty())
	{
		if (OpenClipboard())
		{
			HANDLE hHandle = GlobalAlloc(GMEM_FIXED, strCopyData.length() + 1);//分配内存
			char* pData = (char*)GlobalLock(hHandle);//锁定内存，返回申请内存的首地址

			memcpy(pData, strCopyData.c_str(), strCopyData.length());
			EmptyClipboard();//清空剪切板    
			SetClipboardData(CF_TEXT, hHandle);//设置剪切板数据
			GlobalUnlock(hHandle);//解除锁定
			CloseClipboard();//关闭前帖板
		}
	}
}

BOOL CCR3562ClientDlg::OnDeviceChange(UINT nEventType, DWORD_PTR dwData) {
	//DEV_BROADCAST_DEVICEINTERFACE* dbd = (DEV_BROADCAST_DEVICEINTERFACE*) dwData;
	switch (nEventType)
	{
	case DBT_DEVICEREMOVECOMPLETE://移除设备
		OnBnClickedBtnSearch();//刷新列表框的内容
		if (m_bConnect) {
			m_bReConnect = true;
			m_bConnect = false;
			m_dwBtnStatus = 0;
			SetBtnStatus(m_dwBtnStatus);
			m_SerialInterface.closeComm();
		}
		break;
	case DBT_DEVICEARRIVAL://添加设备
		OnBnClickedBtnSearch();//刷新列表框的内容
		if (m_bReConnect) {
			bool m_bReconnect=false;
			//选中上次串口
			for (map<int, map<string, CString>>::iterator it = m_mpPortsName.begin(); 
				it != m_mpPortsName.end(); it++)
			{
				if (m_cstrConnectName == it->second.begin()->second)
				{
					nConnectIndex = it->first;
					//尝试连接
					OnBnClickedBtnConnect();
					m_bReconnect = true;
					if (m_nSendData > 0) {
						m_dwBtnStatus = 3;
						SetBtnStatus(m_dwBtnStatus);
					}
					break;
				}
			}
		}
		break;

	default:
		break;
	}
	return TRUE;
}


void CCR3562ClientDlg::OnCbnSelchangeComboSerialname()
{
	// TODO: 在此添加控件通知处理程序代码
	nConnectIndex = ((CComboBox*)GetDlgItem(IDC_COMBO_SerialName))->GetCurSel();
}


void CCR3562ClientDlg::OnBnClickedCheckShowsend()
{
	// TODO: 在此添加控件通知处理程序代码
	if (((CButton*)GetDlgItem(IDC_CHECK_ShowSend))->GetCheck()) {
		m_bShowSend = true;
	}
	else {
		m_bShowSend = false;
	}
}


void CCR3562ClientDlg::OnBnClickedCheckShowtime()
{
	// TODO: 在此添加控件通知处理程序代码
	if (((CButton*)GetDlgItem(IDC_CHECK_ShowTime))->GetCheck()) {
		m_bShowTime = true;
	}
	else {
		m_bShowTime = false;
	}
}

void CCR3562ClientDlg::UpdateCurrentRV(string strData, bool bData)
{
	string strR, strV;
	CString cstrData;
	
	if (bData) {
		if (strData.find(",") != string::npos) {
			strR = strData.substr(0, strData.find(","));
			strV = strData.substr(strData.find(",") + 1);
		}
		cstrData = strR.c_str();
		GetDlgItem(IDC_EDIT_R)->SetWindowText(cstrData);
		cstrData = strV.c_str();
		GetDlgItem(IDC_EDIT_V)->SetWindowText(cstrData);
	}
	else {
		cstrData = L"--";
		GetDlgItem(IDC_EDIT_R)->SetWindowText(cstrData);
		GetDlgItem(IDC_EDIT_V)->SetWindowText(cstrData);
	}
}

void CCR3562ClientDlg::CaliMeter()
{
	m_dwBtnStatus = 4;
	SetBtnStatus(m_dwBtnStatus);

	//预热
	//进入校准模式

	SetCaliCurrState(m_bAimVolt);

	CurrCali();

	//退出校准模式

	m_dwBtnStatus = 1;
	SetBtnStatus(m_dwBtnStatus);
}

void CCR3562ClientDlg::CurrCali()
{
	m_CaliProgress.ShowWindow(true);
	t_sCaliSeg CaliFile = m_CaliFile;
	double dLastPoint = 0,dCurrPoint = 0,dLastY;
	int nCurrVRange = 0;
	CString cstrData;
	string strData;
	if (m_bAimVolt) {//电压校准，用电压点
		//按量程，段循环取点
		for (map<double, map<int, double>>::iterator it = m_mpCaliVPoint.begin();
			it != m_mpCaliVPoint.end(); it++)
		{
			//切换量程
			if (!SetRange(m_bAimVolt, it->first)) {
				InsertTips("量程设置异常！", false);
				return;
			}
			dLastPoint = 0;//切量程时清空
			dLastY = 0;
			if (abs(it->first - 2.0) < 0.000001) {
				nCurrVRange = 0;
			}
			else if (abs(it->first - 20.0) < 0.000001) {
				nCurrVRange = 1;
			}
			else if (abs(it->first - 100.0) < 0.000001) {
				nCurrVRange = 2;
			}
			for (size_t i = 0; i < it->second.size(); i++)
			{
				//取点函数，实际取5个值的平均数
				if (!GetPoint(m_bAimVolt, it->first,i, it->second[i], dCurrPoint)) {
					//InsertTips("取点异常！", false);
					return;
				}

				if (i > 0) {//计算kb值，并匹配保存到对应的数据位置
					cstrData.Format(L"量程%.0fV第%d段k：%e，b：%e", it->first, i,
						(it->second[i] - dLastY)/(dCurrPoint - dLastPoint)
						, it->second[i]- (it->second[i] - dLastY) / (dCurrPoint - dLastPoint)*dCurrPoint);
					strData = CW2A(cstrData);
					InsertTips(strData, false);
					sCaliSeg sCurrCaliSeg;
					sCurrCaliSeg.unBegin = dLastPoint;
					sCurrCaliSeg.unEnd = dCurrPoint;
					sCurrCaliSeg.fk = (it->second[i] - dLastY) / (dCurrPoint - dLastPoint);
					sCurrCaliSeg.fb = it->second[i] - (it->second[i] - dLastY) / (dCurrPoint - dLastPoint) * dCurrPoint;
					CaliFile.sVoltCali[nCurrVRange][i - 1] = sCurrCaliSeg;
				}
				dLastY = it->second[i];
				dLastPoint = dCurrPoint;
			}
			//nCurrVRange++;
		}
		InsertTips("电压校准完成！", false);
		//以校准文件的形式下发
		UpdateCaliFile(CaliFile);//更新校准文件
		UpdateCaliFileTiming();
		IssueCaliFile();//下发校准文件
	}
	else {//电阻校准（先相位再电阻？），用电阻点
		//按量程，段循环取点
		for (map<double, map<int, double>>::iterator it = m_mpCaliRPoint.begin();
			it != m_mpCaliRPoint.end(); it++)
		{
			//切换量程
			if (!SetRange(m_bAimVolt, it->first)) {
				InsertTips("量程设置异常！", false);
				return;
			}
			dLastPoint = 0;//切量程时清空
			dLastY = 0;
			if (abs(it->first - 0.002) < 0.000001) {
				nCurrVRange = 0;
			}
			else if (abs(it->first - 0.02) < 0.000001) {
				nCurrVRange = 1;
			}
			else if (abs(it->first - 0.2) < 0.000001) {
				nCurrVRange = 2;
			}
			else if (abs(it->first - 2) < 0.000001) {
				nCurrVRange = 3;
			}
			else if (abs(it->first - 20.0) < 0.000001) {
				nCurrVRange = 4;
			}
			else if (abs(it->first - 200.0) < 0.000001) {
				nCurrVRange = 5;
			}
			for (size_t i = 0; i < it->second.size(); i++)
			{
				//取点函数，实际取5个值的平均数
				if (!GetPoint(m_bAimVolt, it->first, i, it->second[i], dCurrPoint)) {
					InsertTips("取点异常！", false);
					return;
				}

				if (i > 0) {//计算kb值，并匹配保存到对应的数据位置
					cstrData.Format(L"量程%.0fΩ第%d段k：%e，b：%e", it->first, i,
						(it->second[i] - dLastY) / (dCurrPoint - dLastPoint)
						, it->second[i] - (it->second[i] - dLastY) / (dCurrPoint - dLastPoint) * dCurrPoint);
					strData = CW2A(cstrData);
					InsertTips(strData, false);
					sCaliSeg sCurrCaliSeg;
					sCurrCaliSeg.unBegin = dLastPoint;
					sCurrCaliSeg.unEnd = dCurrPoint;
					sCurrCaliSeg.fk = (it->second[i] - dLastY) / (dCurrPoint - dLastPoint);
					sCurrCaliSeg.fb = it->second[i] - (it->second[i] - dLastY) / (dCurrPoint - dLastPoint) * dCurrPoint;
					CaliFile.sResCali[nCurrVRange][i - 1] = sCurrCaliSeg;
				}
				dLastY = it->second[i];
				dLastPoint = dCurrPoint;
			}
			//nCurrVRange++;
		}
		InsertTips("电阻校准完成！", false);
		//以校准文件的形式下发
		UpdateCaliFile(CaliFile);//更新校准文件
		UpdateCaliFileTiming();
		IssueCaliFile();//下发校准文件

	}
	m_CaliProgress.ShowWindow(false);
}

void CCR3562ClientDlg::UpdateMeter()
{
	if (!m_bUpdateReady)
	{
		InsertTips("需加载正确文件!", false);
		return;
	}
	m_dwBtnStatus = 6;
	SetBtnStatus(m_dwBtnStatus);
	
	if (m_bCaliFile) {//发送校准文件
		//IRMeter_SendCaliFile();
	}
	else {//发送升级文件
		if (!InUpdate()) {
			m_dwBtnStatus = 1;
			SetBtnStatus(m_dwBtnStatus);
			return;
		}
		SendUpdateFile();
	}
	m_dwBtnStatus = 1;
	SetBtnStatus(m_dwBtnStatus);
}

bool CCR3562ClientDlg::bIsCR3562()
{
	char cRecv[1024] = { 0 };
	bool bSendSuccess = false;
	bool bSendFetch = false;
	CString cstrData;

	string strData;
	strData = "*IDN?\r\n";
	memcpy(cRecv, strData.c_str(), min(sizeof(cRecv), strData.length()));
	if (m_SerialInterface.writeData(cRecv, min(sizeof(cRecv), strData.length()))) {
		bSendSuccess = true;
	}
	else {
	}

	memset(cRecv, 0, sizeof(cRecv));
	if (bSendSuccess) {
		Sleep(1000);
		if (m_SerialInterface.readData(cRecv, sizeof(cRecv))) {
			cstrData = cRecv;
			string strData = CW2A(cstrData);
			if (strData.find("CR3562") != string::npos) {
				return true;
			}
		}
		else {

		}
	}
	return false;
}

void CCR3562ClientDlg::InitCaliParam()
{
	//map<int, double> mpV2, mpV20, mpV100;
	//map<int, double> mpR2, mpR20, mpR200, mpR2000, mpR20000, mpR200000;
	//mpV2[0] = -2.0;
	//mpV2[1] = -1.0;
	//mpV2[2] = -0.0;
	//mpV2[3] = 1.0;
	//mpV2[4] = 2.0;
	//mpV20[0] = -20.0;
	//mpV20[1] = -4.0;
	//mpV20[2] = -0.0;
	//mpV20[3] = 4.0;
	//mpV20[4] = 20.0;
	//mpV100[0] = -40.0;
	//mpV100[1] = -20.0;
	//mpV100[2] = -0.0;
	//mpV100[3] = 20.0;
	//mpV100[4] = 40.0;

	//mpR2[0] = 0;
	//mpR2[1] = 1/1000.0;
	//mpR20[0] = 0;
	//mpR20[1] = 10 / 1000.0;
	//mpR200[0] = 0;
	//mpR200[1] = 100 / 1000.0;
	//mpR2000[0] = 0;
	//mpR2000[1] = 1000 / 1000.0;
	//mpR20000[0] = 0;
	//mpR20000[1] = 10000 / 1000.0;
	//mpR200000[0] = 0;
	//mpR200000[1] = 100000 / 1000.0;
	//m_mpCaliVPoint[2] = mpV2;
	//m_mpCaliVPoint[20] = mpV20;
	//m_mpCaliVPoint[100] = mpV100;
	//m_mpCaliRPoint[0.002] = mpR2;
	//m_mpCaliRPoint[0.020] = mpR20;
	//m_mpCaliRPoint[0.200] = mpR200;
	//m_mpCaliRPoint[2] = mpR2000;
	//m_mpCaliRPoint[20] = mpR20000;
	//m_mpCaliRPoint[200] = mpR200000;

	////存配置文件
	//CMyINI* p = new CMyINI();
	//string strPath = GetProcessDir() + "Setting.ini";
	//p->ReadINI(strPath);
	//string strRange, strPointIndex, StrPointValue;
	//for (map<double, map<int, double>>::iterator it = m_mpCaliVPoint.begin(); it != m_mpCaliVPoint.end(); it++)
	//{
	//	strRange = "V";
	//	strRange += DoubleToStr(it->first,1,0);
	//	
	//	strPointIndex = "err";
	//	for (map<int, double>::iterator itP = it->second.begin(); itP != it->second.end(); itP++)
	//	{
	//		strPointIndex = UintToStr(itP->first);
	//		StrPointValue = DoubleToStr(itP->second,1,0);
	//		p->SetValue(strRange, strPointIndex, StrPointValue);
	//	}
	//}

	//for (map<double, map<int, double>>::iterator it = m_mpCaliRPoint.begin(); it != m_mpCaliRPoint.end(); it++)
	//{
	//	strRange = "R";
	//	strRange += DoubleToStr(it->first,3,0);
	//	
	//	for (map<int, double>::iterator itP = it->second.begin(); itP != it->second.end(); itP++)
	//	{
	//		strPointIndex = UintToStr(itP->first);
	//		StrPointValue = DoubleToStr(itP->second, 0, 0);
	//		p->SetValue(strRange, strPointIndex, StrPointValue);
	//	}
	//}
	//
	//p->WriteINI(strPath);

	std::string filePath = GetProcessDir() + "Setting.ini";  //替换为你的文件路径
	std::string content = strSetting;  //替换为你要存储的字符串

	std::ofstream file(filePath);  //创建一个ofstream对象，用于写入文件

	if (file.is_open()) {  //如果文件成功打开
		file << content;  //将字符串写入文件
		file.close();  //关闭文件
		std::cout << "字符串已成功存储到文件中！" << std::endl;
		GetCaliParamFromFile();
	}
	else {
		std::cout << "无法打开文件！" << std::endl;
	}

}

bool CCR3562ClientDlg::GetCaliParamFromFile()
{
	bool bRtrn = false;
	CMyINI* p = new CMyINI();
	string strPath = GetProcessDir()+ "Setting.ini";
	if (p->ReadINI(strPath)) {
		m_mpCaliVPoint.clear();
		m_mpCaliRPoint.clear();
		m_mpVErr.clear();
		m_mpRErr.clear();

		//获取校准值
		string strRange, strPointIndex, StrPointValue;
		for (map<string, SubNode>::iterator it= p->map_ini.begin();
			it != p->map_ini.end(); it++)
		{
			strRange = it->first;
			string strHead, strValue;
			strHead = strRange.substr(1, 1);
			for (char const& c : strHead) {
				if (std::isdigit(c) == 0) {
					continue;
				}					
			}
			//if (!isdigit((char)strHead.c_str())) {
			//	continue;
			//}
			strHead = strRange.substr(0, 1);
			strValue = strRange.substr(1);
			map<int, double> mpChild;
			if (strHead == "V") {
				for (map<string, string>::iterator itC = it->second.sub_node.begin();
					itC != it->second.sub_node.end(); itC++)
				{
					if (itC->first == "err") {
						m_mpVErr[atof(strValue.c_str())] = atof(itC->second.c_str());
					}
					else {
						mpChild[atoi(itC->first.c_str())] = atof(itC->second.c_str());
					}					
				}
				m_mpCaliVPoint[atof(strValue.c_str())] = mpChild;
			}
			if (strHead == "R") {
				for (map<string, string>::iterator itC = it->second.sub_node.begin();
					itC != it->second.sub_node.end(); itC++)
				{
					if (itC->first == "err") {
						m_mpRErr[atof(strValue.c_str())] = atof(itC->second.c_str());
					}
					else {
						mpChild[atoi(itC->first.c_str())] = atof(itC->second.c_str());
					}					
				}
				m_mpCaliRPoint[atof(strValue.c_str())] = mpChild;
			}
			if (strHead == "D") {
				for (map<string, string>::iterator itC = it->second.sub_node.begin();
					itC != it->second.sub_node.end(); itC++)
				{
					if (itC->first == "r") {
						m_dRThreshold = atof(itC->second.c_str());
					}
					else if(itC->first == "v"){
						m_dVThreshold = atof(itC->second.c_str());
					}
				}
			}
		}

		delete p;
		p = NULL;
		//if (m_mpCaliVPoint.size() != 3 || m_mpCaliRPoint.size() != 6) {
		//	bRtrn = false;
		//}
		bRtrn = true;
	}
	else {
	}
	
	return bRtrn;
}

void CCR3562ClientDlg::InitTSValiParam()
{
	map<double, double> mpV2, mpV20, mpV100;
	map<double, double> mpR2, mpR20, mpR200, mpR2000, mpR20000, mpR200000;
	mpV2[0] = -2.0;
	mpV2[1] = -1.0;
	mpV2[2] = 0.0;
	mpV2[3] = 1.0;
	mpV2[4] = 2.0;
	mpV20[0] = -20.0;
	mpV20[1] = -4.0;
	mpV20[2] = 0.0;
	mpV20[3] = 4.0;
	mpV20[4] = 20.0;
	mpV100[0] = -40.0;
	mpV100[1] = -20.0;
	mpV100[2] = 0.0;
	mpV100[3] = 20.0;
	mpV100[4] = 40.0;

	mpR2[0] = 0;
	mpR2[1] = 1 / 1000.0;
	mpR20[0] = 0;
	mpR20[1] = 10 / 1000.0;
	mpR200[0] = 0;
	mpR200[1] = 100 / 1000.0;
	mpR2000[0] = 0;
	mpR2000[1] = 1000 / 1000.0;
	mpR20000[0] = 0;
	mpR20000[1] = 10000 / 1000.0;
	mpR200000[0] = 0;
	mpR200000[1] = 100000 / 1000.0;
	m_mpCliVPointMZValue[2] = mpV2;
	m_mpCliVPointMZValue[20] = mpV20;
	m_mpCliVPointMZValue[100] = mpV100;
	m_mpCliRPointMZValue[0.002] = mpR2;
	m_mpCliRPointMZValue[0.020] = mpR20;
	m_mpCliRPointMZValue[0.200] = mpR200;
	m_mpCliRPointMZValue[2] = mpR2000;
	m_mpCliRPointMZValue[20] = mpR20000;
	m_mpCliRPointMZValue[200] = mpR200000;
	m_dVThreshold = 0;
	m_dRThreshold = 0;
	m_dVAvgTS = 0;
	m_dRAvgTS = 0;

	//存配置文件
	CMyINI* p = new CMyINI();
	string strPath = GetProcessDir() + "ThresholdParam.ini";
	p->ReadINI(strPath);
	string strRange, strPointIndex, StrPointValue;
	for (map<double, map<double, double>>::iterator it = m_mpCliVPointMZValue.begin(); it != m_mpCliVPointMZValue.end(); it++)
	{
		strRange = "V";
		strRange += DoubleToStr(it->first, 1, 0);

		for (map<double, double>::iterator itP = it->second.begin(); itP != it->second.end(); itP++)
		{
			strPointIndex = UintToStr(itP->first);
			StrPointValue = DoubleToStr(itP->second, 1, 0);
			p->SetValue(strRange, strPointIndex, StrPointValue);
		}
	}

	for (map<double, map<double, double>>::iterator it = m_mpCliRPointMZValue.begin(); it != m_mpCliRPointMZValue.end(); it++)
	{
		strRange = "R";
		strRange += DoubleToStr(it->first, 3, 0);

		for (map<double, double>::iterator itP = it->second.begin(); itP != it->second.end(); itP++)
		{
			strPointIndex = UintToStr(itP->first);
			StrPointValue = DoubleToStr(itP->second, 0, 0);
			p->SetValue(strRange, strPointIndex, StrPointValue);
		}
	}

	strRange = "TV";
	strPointIndex = "threshold";
	StrPointValue = DoubleToStr(m_dVThreshold, 0, 0);
	p->SetValue(strRange, strPointIndex, StrPointValue);
	strPointIndex = "avgTS";
	StrPointValue = DoubleToStr(m_dVAvgTS, 0, 0);
	p->SetValue(strRange, strPointIndex, StrPointValue);

	strRange = "TR";
	strPointIndex = "threshold";
	StrPointValue = DoubleToStr(m_dRThreshold, 0, 0);
	p->SetValue(strRange, strPointIndex, StrPointValue);
	strPointIndex = "avgTS";
	StrPointValue = DoubleToStr(m_dRAvgTS, 0, 0);
	p->SetValue(strRange, strPointIndex, StrPointValue);

	p->WriteINI(strPath);
}

bool CCR3562ClientDlg::GetTSValiParamFromFile()
{

	bool bRtrn = false;
	CMyINI* p = new CMyINI();
	string strPath = GetProcessDir() + "ThresholdParam.ini";
	if (p->ReadINI(strPath)) {

		//获取校准值
		string strRange, strPointIndex, StrPointValue;
		for (map<string, SubNode>::iterator it = p->map_ini.begin();
			it != p->map_ini.end(); it++)
		{
			strRange = it->first;
			string strHead, strValue;
			strHead = strRange.substr(1, 1);
			/*for (char const& c : strHead) {
				if (std::isdigit(c) == 0) {
					continue;
				}
			}*/
			//if (!isdigit((char)strHead.c_str())) {
			//	continue;
			//}
			strHead = strRange.substr(0, 1);
			strValue = strRange.substr(1);
			map<double, double> mpChild;
			if (strHead == "V") {
				for (map<string, string>::iterator itC = it->second.sub_node.begin();
					itC != it->second.sub_node.end(); itC++)
				{
					mpChild[atof(itC->first.c_str())] = atof(itC->second.c_str());
				}
				m_mpCliVPointMZValue[atof(strValue.c_str())] = mpChild;
			}
			if (strHead == "R") {
				for (map<string, string>::iterator itC = it->second.sub_node.begin();
					itC != it->second.sub_node.end(); itC++)
				{
					mpChild[atof(itC->first.c_str())] = atof(itC->second.c_str());
				}
				m_mpCliRPointMZValue[atof(strValue.c_str())] = mpChild;
			}
			if (strHead == "T") {
				strHead = strRange.substr(1, 1);
				if (strHead == "V") {
					int nTS = 0;
					for (map<string, string>::iterator itC = it->second.sub_node.begin();
						itC != it->second.sub_node.end(); itC++)
					{
						if (nTS == 1) {
							m_dVThreshold = atof(itC->second.c_str());
						}
						else {
							m_dVAvgTS = atof(itC->second.c_str());
						}
						nTS++;
					}
				}
				if (strHead == "R") {
					int nTS = 0;
					for (map<string, string>::iterator itC = it->second.sub_node.begin();
						itC != it->second.sub_node.end(); itC++)
					{
						if (nTS == 1) {
							m_dRThreshold = atof(itC->second.c_str());
						}
						else {
							m_dRAvgTS = atof(itC->second.c_str());
						}
						nTS++;
					}
				}
			}
			
		}

		delete p;
		p = NULL;
		/*if (m_mpCaliVPoint.size() != 3 || m_mpCaliRPoint.size() != 6) {
			bRtrn = false;
		}*/
		bRtrn = true;
	}
	else {
	}

	return bRtrn;
}

bool CCR3562ClientDlg::GetCaliFile()
{

	char cRecv[1024] = { 0 };
	bool bSendSuccess = false;
	CString cstrData;

	string strData;
	strData = ":CALibrate:FILE?\r\n";
	memcpy(cRecv, strData.c_str(), min(sizeof(cRecv), strData.length()));
	if (m_SerialInterface.writeData(cRecv, min(sizeof(cRecv), strData.length()))) {
		bSendSuccess = true;
	}
	else {
	}

	memset(cRecv, 0, sizeof(cRecv));
	if (bSendSuccess) {
		Sleep(1000);
		if (m_SerialInterface.readData(cRecv, sizeof(cRecv))) {
			GetCaliFileFromData(cRecv, sizeof(cRecv));
			WORD wCRC = calc_crc16_with_init(cRecv + 2, sizeof(m_CaliFile) - 6, 0xFFFF);
			if (wCRC == m_CaliFile.wCRC16) {
				return true;
			}
			else {
				return false;
			}
			
		}
		else {
		}
	}
	else {		
	}

	return false;
}

bool CCR3562ClientDlg::UpdateCaliFile(t_sCaliSeg CaliFile)
{
	m_CaliFile = CaliFile;
	return true;
}

bool CCR3562ClientDlg::UpdateCaliFileTiming()
{
	m_CaliFile.dwTime = 0;
	m_CaliFile.dwDate = 0;

	int nA = 0;
	unsigned char buf[2] = { 0 };
	unsigned long nDataLen = 0;
	string strData;
	UINT64 u64CurrTime = GetTimeMicroSeconds();

	string strDate = UInt64MicroSecondsToStrDate(u64CurrTime);

	m_CaliFile.dwDate = 0;
	m_CaliFile.dwTime = 0;

	strData = strDate.substr(0, 4);
	nA = atoi(strData.c_str());
	m_CaliFile.dwDate += nA;
	m_CaliFile.dwDate *= 256;

	strData = strDate.substr(4, 2);
	nA = atoi(strData.c_str());
	m_CaliFile.dwDate += nA;
	m_CaliFile.dwDate *= 256;

	strData = strDate.substr(6, 2);
	nA = atoi(strData.c_str());
	m_CaliFile.dwDate += nA;

	string strTime = UInt64MicroSecondsToStrTimeNoMS(u64CurrTime);

	strData = strTime.substr(11, 2);
	nA = atoi(strData.c_str());
	m_CaliFile.dwTime += nA;
	m_CaliFile.dwTime *= 256;
	strData = strTime.substr(14, 2);
	nA = atoi(strData.c_str());
	m_CaliFile.dwTime += nA;
	m_CaliFile.dwTime *= 256;
	strData = strTime.substr(17, 2);
	nA = atoi(strData.c_str());
	m_CaliFile.dwTime += nA;

	return true;
}

bool CCR3562ClientDlg::IssueCaliFile()
{
	bool brtrn = false;
	m_bUpdating = true;
	const unsigned long nLenBufMax = 1024;
	char Buf[nLenBufMax] = { 0 };

	int nSendLen = 128;
	int nSeg = 0;
	string strData;
	//CString cstrData;
	int nRate = 10;

	memset(Buf, 0, nLenBufMax);
	strData = ":CALibrate:FILE\r\n";//电阻在前电压在后
	memcpy(Buf, strData.c_str(), min(sizeof(Buf), strData.length()));
	if (!m_SerialInterface.writeData(Buf, min(sizeof(Buf), strData.length()))) {
		return false;
	}
	else {
	}
	Sleep(200);

	memset(Buf, 0, nLenBufMax);
	SetCaliFileToData(Buf,sizeof(m_CaliFile));
	
	while(nSeg <sizeof(m_CaliFile))
	{
		/*if (!m_bUpdating) {
			strData = "主动停止";
			InsertTips(strData, false);
			return false;
		}*/
		

		if (!m_SerialInterface.writeData(Buf +nSeg, sizeof(m_CaliFile)-nSeg>nSendLen?nSendLen: sizeof(m_CaliFile) - nSeg)) {
			return false;
		}
		else {
		}	
		Sleep(100);
		nSeg += nSendLen;
	}

	t_sCaliSeg CaliFile = m_CaliFile;
	m_CaliFile.dwDate = 0;

	Sleep(100);
	if (!GetCaliFile()) {
		InsertTips("校准文件校验失败", false);
		return false;
	}
	bool isEqual = (memcmp(&CaliFile, &m_CaliFile, sizeof(CaliFile)) == 0);

	if (isEqual) {
		strData = MacCnnctDev_copy::Format("校准文件下发成功");
		InsertTips(strData, false);
		brtrn = true;
	}
	else {
		strData = MacCnnctDev_copy::Format("校准文件下发异常");
		InsertTips(strData, false);
	}

	

	m_FileStream.CloseFileStream();

	return brtrn;
}

bool CCR3562ClientDlg::GetCaliFileFromData(char* cData, int Lenth)
{
	char* pBuf = cData;
	m_CaliFile.wBeginFlag = *(WORD*)pBuf;
	pBuf += sizeof(WORD);

	if (m_CaliFile.wBeginFlag != 0x5555) {
		return false;
	}

	m_CaliFile.wFileSize = *(WORD*)pBuf;
	pBuf += sizeof(WORD);

	if (m_CaliFile.wFileSize > Lenth) {
		return false;
	}

	m_CaliFile.dwDate = *(DWORD*)pBuf;
	pBuf += sizeof(DWORD);

	m_CaliFile.dwTime = *(DWORD*)pBuf;
	pBuf += sizeof(DWORD);

	for (size_t i = 0; i < 3; i++)
	{
		for (size_t j = 0; j < 4; j++)
		{
			m_CaliFile.sVoltCali[i][j].unBegin = * (DWORD*)pBuf;
			pBuf += sizeof(DWORD);

			m_CaliFile.sVoltCali[i][j].unEnd = *(DWORD*)pBuf;
			pBuf += sizeof(DWORD);

			m_CaliFile.sVoltCali[i][j].fk = *(float*)pBuf;
			pBuf += sizeof(float);

			m_CaliFile.sVoltCali[i][j].fb = *(float*)pBuf;
			pBuf += sizeof(float);
		}
	}
	for (size_t i = 0; i < 6; i++)
	{
		m_CaliFile.fDACOffset[i] = *(float*)pBuf;
		pBuf += sizeof(float);
	}

	for (size_t i = 0; i < 6; i++)
	{
		for (size_t j = 0; j < 1; j++)
		{
			m_CaliFile.sResCali[i][j].unBegin = *(DWORD*)pBuf;
			pBuf += sizeof(DWORD);

			m_CaliFile.sResCali[i][j].unEnd = *(DWORD*)pBuf;
			pBuf += sizeof(DWORD);

			m_CaliFile.sResCali[i][j].fk = *(float*)pBuf;
			pBuf += sizeof(float);

			m_CaliFile.sResCali[i][j].fb = *(float*)pBuf;
			pBuf += sizeof(float);
		}
	}

	m_CaliFile.wCRC16 = *(WORD*)pBuf;
	pBuf += sizeof(WORD);

	m_CaliFile.wEndFlag = *(WORD*)pBuf;
	pBuf += sizeof(WORD);

	if (m_CaliFile.wEndFlag != 0xAAAA) {
		return false;
	}

	return true;
}

bool CCR3562ClientDlg::SetCaliFileToData(char* cData, int Lenth)
{
	char* pBuf = cData;
	*(WORD*)pBuf = m_CaliFile.wBeginFlag;
	pBuf += sizeof(WORD);

	if (m_CaliFile.wBeginFlag != 0x5555) {
		return false;
	}

	*(WORD*)pBuf = m_CaliFile.wFileSize;
	pBuf += sizeof(WORD);

	if (m_CaliFile.wFileSize > Lenth) {
		return false;
	}

	*(DWORD*)pBuf = m_CaliFile.dwDate;
	pBuf += sizeof(DWORD);

	*(DWORD*)pBuf = m_CaliFile.dwTime;
	pBuf += sizeof(DWORD);

	for (size_t i = 0; i < 3; i++)
	{
		for (size_t j = 0; j < 4; j++)
		{
			*(DWORD*)pBuf = m_CaliFile.sVoltCali[i][j].unBegin;
			pBuf += sizeof(DWORD);

			*(DWORD*)pBuf = m_CaliFile.sVoltCali[i][j].unEnd;
			pBuf += sizeof(DWORD);

			*(float*)pBuf = m_CaliFile.sVoltCali[i][j].fk;
			pBuf += sizeof(float);

			*(float*)pBuf = m_CaliFile.sVoltCali[i][j].fb;
			pBuf += sizeof(float);
		}
	}
	for (size_t i = 0; i < 6; i++)
	{
		*(float*)pBuf = m_CaliFile.fDACOffset[i];
		pBuf += sizeof(float);
	}

	for (size_t i = 0; i < 6; i++)
	{
		for (size_t j = 0; j < 1; j++)
		{
			*(DWORD*)pBuf = m_CaliFile.sResCali[i][j].unBegin;
			pBuf += sizeof(DWORD);

			*(DWORD*)pBuf = m_CaliFile.sResCali[i][j].unEnd;
			pBuf += sizeof(DWORD);

			*(float*)pBuf = m_CaliFile.sResCali[i][j].fk;
			pBuf += sizeof(float);

			*(float*)pBuf = m_CaliFile.sResCali[i][j].fb;
			pBuf += sizeof(float);
		}
	}

	m_CaliFile.wCRC16 = calc_crc16_with_init(cData + 2, Lenth - 6,0xFFFF);

	*(WORD*)pBuf = m_CaliFile.wCRC16;
	pBuf += sizeof(WORD);

	*(WORD*)pBuf = m_CaliFile.wEndFlag;
	pBuf += sizeof(WORD);

	if (m_CaliFile.wEndFlag != 0xAAAA) {
		return false;
	}

	return true;
}

bool CCR3562ClientDlg::SetRange(bool m_bIsV, double nRange)
{
	//InsertTips("量程设置异常！", false);
	char cRecv[1024] = { 0 };
	bool bSendSuccess = false;
	CString cstrData;
	string strData;
	if (m_bIsV) {
		cstrData.Format(L":VOLTage:RANGe %.0f\r\n", nRange);
		strData = CW2A(cstrData);
	}
	else {
		cstrData.Format(L":RESistance:RANGe %f\r\n", nRange);
		strData = CW2A(cstrData);
	}
	memcpy(cRecv, strData.c_str(), min(sizeof(cRecv), strData.length()));
	if (m_SerialInterface.writeData(cRecv, min(sizeof(cRecv), strData.length()))) {
		bSendSuccess = true;
	}
	else {
	}

	if (bSendSuccess) {
		bSendSuccess = false;
		memset(cRecv, 0, sizeof(cRecv));
		if (m_bIsV) {
			strData = ":VOLTage:RANGe?\r\n";
		}
		else {
			strData = ":RESistance:RANGe?\r\n";
		}
		memcpy(cRecv, strData.c_str(), min(sizeof(cRecv), strData.length()));
		if (m_SerialInterface.writeData(cRecv, min(sizeof(cRecv), strData.length()))) {
			bSendSuccess = true;
		}
		else {
		}
	}

	memset(cRecv, 0, sizeof(cRecv));
	if (bSendSuccess) {
		Sleep(1000);
		if (m_SerialInterface.readData(cRecv, sizeof(cRecv))) {
			cstrData = cRecv;
			strData = CW2A(cstrData);
			strData = strData.substr(0,strData.find('\r'));
			double dCurrRange = atof(strData.c_str());
			if (dCurrRange == nRange) {
				
				return true;
			}
		}
		else {

		}
	}
	return false;
}

bool CCR3562ClientDlg::GetPoint(bool m_bIsV, double nRange, int n,double dValue, double& dGetValue)
{
	CString cstrMess;
	string strMess;	
	char cRecv[1024] = { 0 };
	bool bSendSuccess = false;
	CString cstrData;
	string strData;
	if (m_bIsV) {
		m_CaliProgress.SetPos(0);
		cstrMess.Format(L"电压校准,量程%.0fV的点：%.5fV", nRange, dValue);
		strMess = CW2A(cstrMess);
		InsertTips(strMess, false);
		//Sleep(5000);
		
		double dMax = 0, dMin = 0, dFetchValue[5] = { 0 },dAvgValue=0;
		double dCurrValue = 0;
		//dMax = m_mpCliVPointMZValue[nRange][n]  + m_dVThreshold;
		//dMin = m_mpCliVPointMZValue[nRange][n]  - m_dVThreshold;
		if (m_bThreadUsing == false) {
			return false;
		}
		Sleep(1000 * m_dVThreshold);
		int i = 0;
		while (1) {
			if (m_bThreadUsing == false) {
				return false;
			}
			strData = ":CALibrate:FETCh?\r\n";//电阻在前电压在后
			memcpy(cRecv, strData.c_str(), min(sizeof(cRecv), strData.length()));
			if (m_SerialInterface.writeData(cRecv, min(sizeof(cRecv), strData.length()))) {
				bSendSuccess = true;
			}
			else {
			}

			memset(cRecv, 0, sizeof(cRecv));
			if (bSendSuccess) {
				Sleep(2000);
				if (m_SerialInterface.readData(cRecv, sizeof(cRecv))) {
					cstrData = cRecv;
					string strData = CW2A(cstrData);
					strData = strData.substr(strData.find(',') + 1, strData.find('\r'));
					dCurrValue = atof(strData.c_str());
					//if (dCurrValue <  dMax && dCurrValue > dMin) {
						if (i > 0) {
							if (abs(dFetchValue[i - 1] - dCurrValue) >= m_mpVErr[nRange]) {
								i = 0;
							}
						}
						dFetchValue[i] = dCurrValue;
						i++;
					//}
					//else {
					//	i = 0;
					//}
					m_CaliProgress.SetPos(i*20);
					if (i == 5) {
						dAvgValue = dFetchValue[i-1];
						cstrData.Format(L"电压采样值为：%.0f", dAvgValue);
						string strData = CW2A(cstrData);
						InsertTips(strData, false);
						dGetValue = dAvgValue;
						break;
					}

				}
				else {
					return false;
				}
			}
			else {
				return false;
			}
		}
	}
	else {
		m_CaliProgress.SetPos(0);
		cstrMess.Format(L"电阻校准,量程%fΩ的点：%.4fΩ", nRange, dValue);
		strMess = CW2A(cstrMess);
		InsertTips(strMess, false);
		Sleep(5000);

		double dMax = 0, dMin = 0, dFetchValue[5] = { 0 }, dAvgValue = 0;
		double dCurrValue = 0;
		//dMax = m_mpCliRPointMZValue[nRange][n] + m_dRThreshold;
		//dMin = m_mpCliRPointMZValue[nRange][n] - m_dRThreshold;
		int i = 0;
		Sleep(1000 * m_dRThreshold);
		while (1) {
			if (m_bThreadUsing == false) {
				return false;
			}
			strData = ":CALibrate:FETCh?\r\n";//电阻在前电压在后
			memcpy(cRecv, strData.c_str(), min(sizeof(cRecv), strData.length()));
			if (m_SerialInterface.writeData(cRecv, min(sizeof(cRecv), strData.length()))) {
				bSendSuccess = true;
			}
			else {
			}

			memset(cRecv, 0, sizeof(cRecv));
			if (bSendSuccess) {
				Sleep(1000);
				if (m_SerialInterface.readData(cRecv, sizeof(cRecv))) {
					cstrData = cRecv;
					string strData = CW2A(cstrData);
					strData = strData.substr(0, strData.find(','));
					dCurrValue = atof(strData.c_str());
					//if (dCurrValue <  dMax && dCurrValue > dMin) {
						if (i > 0) {
							if (abs(dFetchValue[i - 1] - dCurrValue) > m_mpRErr[nRange]) {
								i = 0;
							}
						}
						dFetchValue[i] = dCurrValue;
						i++;
					/*}
					else {
						i = 0;
					}*/
					m_CaliProgress.SetPos(i * 20);
					if (i == 5) {
						dAvgValue = dFetchValue[i - 1];
						cstrData.Format(L"电阻采样值为：%.0f", dAvgValue);
						string strData = CW2A(cstrData);
						InsertTips(strData, false);
						dGetValue = dAvgValue;
						break;
					}

				}
				else {
					return false;
				}
			}
			else {
				return false;
			}
		}
	}

	return true;
}
