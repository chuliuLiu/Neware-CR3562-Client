/*
www.sourceforge.net/projects/tinyxml
Original code (2.0 and earlier )copyright (c) 2000-2006 Lee Thomason (www.grinninglizard.com)

This software is provided 'as-is', without any express or implied
warranty. In no event will the authors be held liable for any
damages arising from the use of this software.

Permission is granted to anyone to use this software for any
purpose, including commercial applications, and to alter it and
redistribute it freely, subject to the following restrictions:

1. The origin of this software must not be misrepresented; you must
not claim that you wrote the original software. If you use this
software in a product, an acknowledgment in the product documentation
would be appreciated but is not required.

2. Altered source versions must be plainly marked as such, and
must not be misrepresented as being the original software.

3. This notice may not be removed or altered from any source
distribution.
*/

#include "pch.h"
#include <ctype.h>

#include <sstream>
#include <iostream>
#include "tinyxml.h"
bool TiXmlBase::bCondenseWhiteSpace = true;

void TiXmlBase::PutString( const TIXML_STRING& str, TIXML_STRING* pOutString )
{
    int i = 0;

    while( i<(int)str.length() )
    {
        unsigned char c = (unsigned char) str[i];

        if (    c == '&'
            && i < ( (int)str.length() - 2 )
            && str[i+1] == '#'
            && str[i+2] == 'x' )
        {
            // Hexadecimal character reference.
            // Pass through unchanged.
            // &#xA9;    -- copyright symbol, for example.
            //
            // The -1 is a bug fix from Rob Laveaux. It keeps
            // an overflow from happening if there is no ';'.
            // There are actually 2 ways to exit this loop -
            // while fails (error case) and break (semicolon found).
            // However, there is no mechanism (currently) for
            // this function to return an error.
            while( i<(int)str.length()-1 )
            {
                pOutString->append( str.c_str() + i, 1 );
                ++i;
                if ( str[i] == ';' )
                {
                    break;
                }
            }
        }
        else if ( c == '&' )
        {
            pOutString->append( entity[0].pcStr, entity[0].nStrLength );
            ++i;
        }
        else if ( c == '<' )
        {
            pOutString->append( entity[1].pcStr, entity[1].nStrLength );
            ++i;
        }
        else if ( c == '>' )
        {
            pOutString->append( entity[2].pcStr, entity[2].nStrLength );
            ++i;
        }
        else if ( c == '\"' )
        {
            pOutString->append( entity[3].pcStr, entity[3].nStrLength );
            ++i;
        }
        else if ( c == '\'' )
        {
            pOutString->append( entity[4].pcStr, entity[4].nStrLength );
            ++i;
        }
        else if ( c < 32 )
        {
            // Easy pass at non-alpha/numeric/symbol
            // Below 32 is symbolic.
            char buf[ 32 ];

#if defined(TIXML_SNPRINTF)
            TIXML_SNPRINTF( buf, sizeof(buf), "&#x%02X;", (unsigned) ( c & 0xff ) );
#else
            sprintf( buf, "&#x%02X;", (unsigned) ( c & 0xff ) );
#endif

            //warning C4267: convert 'size_t' to 'int'
            //Int-Cast to make compiler happy ...
            pOutString->append( buf, (int)strlen( buf ) );
            ++i;
        }
        else
        {
            //char realc = (char) c;
            //pOutString->append( &realc, 1 );
            *pOutString += (char) c;    // somewhat more efficient function call.
            ++i;
        }
    }
}


TiXmlNode::TiXmlNode( NodeType _type ) : TiXmlBase()
{
    pParent = 0;
    type = _type;
    pFirstChild = 0;
    pLastChild = 0;
    pPrev = 0;
    pNext = 0;
}


TiXmlNode::~TiXmlNode()
{
    TiXmlNode* pNode = pFirstChild;
    TiXmlNode* pTemp = 0;

    while( pNode )
    {
        pTemp = pNode;
        pNode = pNode->pNext;
        delete pTemp;
        pTemp = NULL;
    }
}


void TiXmlNode::CopyTo( TiXmlNode* pTarget ) const
{
    pTarget->SetValue (value.c_str() );
    pTarget->pUserData = pUserData;
}


void TiXmlNode::Clear()
{
    TiXmlNode* pNode = pFirstChild;
    TiXmlNode* pTemp = 0;

    while( pNode )
    {
        pTemp = pNode;
        pNode = pNode->pNext;
        delete pTemp;
        pTemp = NULL;
    }

    pFirstChild = 0;
    pLastChild = 0;
}


TiXmlNode* TiXmlNode::LinkEndChild( TiXmlNode* pNode )
{
    assert( pNode->pParent == 0 || pNode->pParent == this );
    assert( pNode->GetDocument() == 0 || pNode->GetDocument() == this->GetDocument() );

    if ( pNode->Type() == TiXmlNode::DOCUMENT )
    {
        delete pNode;
        if ( GetDocument() )
        {
            GetDocument()->SetError( TIXML_ERROR_DOCUMENT_TOP_ONLY, 0, 0,
                TIXML_ENCODING_UNKNOWN );
        }
        return 0;
    }

    pNode->pParent = this;

    pNode->pPrev = pLastChild;
    pNode->pNext = 0;

    if ( pLastChild )
    {
        pLastChild->pNext = pNode;
    }
    else
    {
        pFirstChild = pNode;            // it was an empty list.
    }

    pLastChild = pNode;
    return pNode;
}


TiXmlNode* TiXmlNode::InsertEndChild( const TiXmlNode& addThis )
{
    if ( addThis.Type() == TiXmlNode::DOCUMENT )
    {
        if ( GetDocument() )
        {
            GetDocument()->SetError( TIXML_ERROR_DOCUMENT_TOP_ONLY, 0, 0,
                TIXML_ENCODING_UNKNOWN );
        }
        return 0;
    }

    TiXmlNode* pNode = addThis.Clone();
    if ( !pNode )
    {
        return 0;
    }

    return LinkEndChild( pNode );
}


TiXmlNode* TiXmlNode::InsertBeforeChild( TiXmlNode* pBeforeThis, const TiXmlNode& addThis )
{
    if ( !pBeforeThis || pBeforeThis->pParent != this )
    {
        return 0;
    }

    if ( addThis.Type() == TiXmlNode::DOCUMENT )
    {
        if ( GetDocument() )
        {
            GetDocument()->SetError( TIXML_ERROR_DOCUMENT_TOP_ONLY, 0, 0,
                TIXML_ENCODING_UNKNOWN );
        }
        return 0;
    }

    TiXmlNode* pNode = addThis.Clone();
    if ( !pNode )
    {
        return 0;
    }

    pNode->pParent = this;

    pNode->pNext = pBeforeThis;
    pNode->pPrev = pBeforeThis->pPrev;
    if ( pBeforeThis->pPrev )
    {
        pBeforeThis->pPrev->pNext = pNode;
    }
    else
    {
        assert( pFirstChild == pBeforeThis );
        pFirstChild = pNode;
    }

    pBeforeThis->pPrev = pNode;
    return pNode;
}


TiXmlNode* TiXmlNode::InsertAfterChild( TiXmlNode* pAfterThis, const TiXmlNode& addThis )
{
    if ( !pAfterThis || pAfterThis->pParent != this )
    {
        return 0;
    }

    if ( addThis.Type() == TiXmlNode::DOCUMENT )
    {
        if ( GetDocument() )
        {
            GetDocument()->SetError( TIXML_ERROR_DOCUMENT_TOP_ONLY, 0, 0,
                TIXML_ENCODING_UNKNOWN );
        }
        return 0;
    }

    TiXmlNode* pNode = addThis.Clone();
    if ( !pNode )
    {
        return 0;
    }
    pNode->pParent = this;

    pNode->pPrev = pAfterThis;
    pNode->pNext = pAfterThis->pNext;
    if ( pAfterThis->pNext )
    {
        pAfterThis->pNext->pPrev = pNode;
    }
    else
    {
        assert( pLastChild == pAfterThis );
        pLastChild = pNode;
    }
    pAfterThis->pNext = pNode;
    return pNode;
}


TiXmlNode* TiXmlNode::ReplaceChild( TiXmlNode* pReplaceThis, const TiXmlNode& withThis )
{
    if( pReplaceThis->pParent != this )
    {
        return 0;
    }

    TiXmlNode* pNode = withThis.Clone();
    if ( !pNode )
    {
        return 0;
    }

    pNode->pNext = pReplaceThis->pNext;
    pNode->pPrev = pReplaceThis->pPrev;

    if ( pReplaceThis->pNext )
    {
        pReplaceThis->pNext->pPrev = pNode;
    }
    else
    {
        pLastChild = pNode;
    }

    if ( pReplaceThis->pPrev )
    {
        pReplaceThis->pPrev->pNext = pNode;
    }
    else
    {
        pFirstChild = pNode;
    }
    delete pReplaceThis;
    pReplaceThis = NULL;
    pNode->pParent = this;
    return pNode;
}


bool TiXmlNode::RemoveChild( TiXmlNode* pRemoveThis )
{
    if(pRemoveThis->pParent != this )
    {
        assert( 0 );
        return false;
    }
    if ( pRemoveThis->pNext )
    {
        pRemoveThis->pNext->pPrev = pRemoveThis->pPrev;
    }
    else
    {
        pLastChild = pRemoveThis->pPrev;
    }

    if ( pRemoveThis->pPrev )
    {
        pRemoveThis->pPrev->pNext = pRemoveThis->pNext;
    }
    else
    {
        pFirstChild = pRemoveThis->pNext;
    }
    delete pRemoveThis;
    pRemoveThis = NULL;
    return true;
}

const TiXmlNode* TiXmlNode::FirstChild( const char * pc_value ) const
{
    const TiXmlNode* pNode;
    for ( pNode = pFirstChild; pNode; pNode = pNode->pNext )
    {
        if ( strcmp( pNode->Value(), pc_value ) == 0 )
        {
            return pNode;
        }
    }

    return 0;
}


const TiXmlNode* TiXmlNode::LastChild( const char * pc_value ) const
{
    const TiXmlNode* pNode;
    for ( pNode = pLastChild; pNode; pNode = pNode->pPrev )
    {
        if ( strcmp( pNode->Value(), pc_value ) == 0 )
        {
            return pNode;
        }
    }
    return 0;
}


const TiXmlNode* TiXmlNode::IterateChildren( const TiXmlNode* pRevious ) const
{
    if ( !pRevious )
    {
        return FirstChild();
    }
    else
    {
        assert( pRevious->pParent == this );
        return pRevious->NextSibling();
    }
}


const TiXmlNode* TiXmlNode::IterateChildren( const char * pcVal, const TiXmlNode* pRevious ) const
{
    if ( !pRevious )
    {
        return FirstChild( pcVal );
    }
    else
    {
        assert( pRevious->pParent == this );
        return pRevious->NextSibling( pcVal );
    }
}


const TiXmlNode* TiXmlNode::NextSibling( const char *pc_value ) const
{
    const TiXmlNode* pNode;
    for ( pNode = pNext; pNode; pNode = pNode->pNext )
    {
        if ( strcmp( pNode->Value(), pc_value ) == 0 )
        {
            return pNode;
        }
    }
    return 0;
}


const TiXmlNode* TiXmlNode::PreviousSibling( const char * pc_value ) const
{
    const TiXmlNode* pNode;
    for ( pNode = pPrev; pNode; pNode = pNode->pPrev )
    {
        if ( strcmp( pNode->Value(), pc_value ) == 0 )
        {
            return pNode;
        }
    }
    return 0;
}


void TiXmlElement::RemoveAttribute( const char * pName )
{
    TIXML_STRING str( pName );
    TiXmlAttribute* pNode = attributeSet.Find( str );
    if( pNode )
    {
        attributeSet.Remove( pNode );
        delete pNode;
        pNode = NULL;
    }
}

const TiXmlElement* TiXmlNode::FirstChildElement() const
{
    const TiXmlNode* pNode;

    for(pNode = FirstChild(); pNode ; pNode = pNode->NextSibling() )
    {
        if ( pNode->ToElement() )
        {
            return pNode->ToElement();
        }
    }
    return 0;
}


const TiXmlElement* TiXmlNode::FirstChildElement( const char * pc_value ) const
{
    const TiXmlNode* pNode;

    for(pNode = FirstChild( pc_value ); pNode  ; pNode = pNode->NextSibling( pc_value ) )
    {
        if(pNode->ToElement() )
        {
            return pNode->ToElement();
        }
    }
    return 0;
}


const TiXmlElement* TiXmlNode::NextSiblingElement() const
{
    const TiXmlNode* pNode;

    for (pNode = NextSibling(); pNode ; pNode = pNode->NextSibling() )
    {
        if(pNode->ToElement())
        {
            return pNode->ToElement();
        }
    }
    return 0;
}


const TiXmlElement* TiXmlNode::NextSiblingElement( const char * pc_value ) const
{
    const TiXmlNode* pNode;

    for (    pNode = NextSibling( pc_value );
        pNode;
        pNode = pNode->NextSibling( pc_value ) )
    {
        if ( pNode->ToElement() )
        {
            return pNode->ToElement();
        }
    }
    return 0;
}


const TiXmlDocument* TiXmlNode::GetDocument() const
{
    const TiXmlNode* pNode;

    for( pNode = this; pNode; pNode = pNode->pParent )
    {
        if ( pNode->ToDocument() )
        {
            return pNode->ToDocument();
        }
    }
    return 0;
}


TiXmlElement::TiXmlElement (const char * pc_value)
    : TiXmlNode( TiXmlNode::ELEMENT )
{
    pFirstChild = pLastChild = 0;
    value = pc_value;
}



TiXmlElement::TiXmlElement( const std::string& str_value )
    : TiXmlNode( TiXmlNode::ELEMENT )
{
    pFirstChild = pLastChild = 0;
    value = str_value;
}

TiXmlElement::TiXmlElement( const TiXmlElement& copy)
    : TiXmlNode( TiXmlNode::ELEMENT )
{
    pFirstChild = pLastChild = 0;
    copy.CopyTo( this );
}


void TiXmlElement::operator=( const TiXmlElement& base )
{
    ClearThis();
    base.CopyTo( this );
}


TiXmlElement::~TiXmlElement()
{
    ClearThis();
}


void TiXmlElement::ClearThis()
{
    Clear();
    while( attributeSet.First() )
    {
        TiXmlAttribute* pNode = attributeSet.First();
        attributeSet.Remove( pNode );
        delete pNode;
        pNode = NULL;
    }
}


const char* TiXmlElement::Attribute( const char* name ) const
{
    const TiXmlAttribute* pNode = attributeSet.Find( name );
    if ( pNode )
    {
        return pNode->Value();
    }
    return 0;
}



const std::string* TiXmlElement::Attribute( const std::string& strName ) const
{
    const TiXmlAttribute* pNode = attributeSet.Find( strName );
    if ( pNode )
    {
        return &pNode->ValueStr();
    }
    return 0;
}


const char* TiXmlElement::Attribute( const char* pName, int* pn ) const
{
    const char* pcS = Attribute( pName );
    if ( pn )
    {
        if ( pcS )
        {
            *pn = atoi( pcS );
        }
        else
        {
            *pn = 0;
        }
    }
    return pcS;
}



const std::string* TiXmlElement::Attribute( const std::string& strName, int* pn ) const
{
    const std::string* pcS = Attribute( strName );
    if ( pn )
    {
        if ( pcS )
        {
            *pn = atoi( pcS->c_str() );
        }
        else
        {
            *pn = 0;
        }
    }
    return pcS;
}

const char* TiXmlElement::Attribute( const char* pName, double* pd ) const
{
    const char* pcS = Attribute( pName );
    if ( pd )
    {
        if ( pcS )
        {
            *pd = atof( pcS );
        }
        else
        {
            *pd = 0;
        }
    }
    return pcS;
}



const std::string* TiXmlElement::Attribute( const std::string& strName, double* pd ) const
{
    const std::string* pstr = Attribute( strName );
    if ( pd )
    {
        if ( pstr )
        {
            *pd = atof( pstr->c_str() );
        }
        else
        {
            *pd = 0;
        }
    }
    return pstr;
}


int TiXmlElement::QueryIntAttribute( const char* pName, int* pnVal ) const
{
    const TiXmlAttribute* node = attributeSet.Find( pName );
    if ( !node )
    {
        return TIXML_NO_ATTRIBUTE;
    }

    return node->QueryIntValue( pnVal );
}



int TiXmlElement::QueryIntAttribute( const std::string& strName, int* pnVal ) const
{
    const TiXmlAttribute* pNode = attributeSet.Find( strName );
    if ( !pNode )
    {
        return TIXML_NO_ATTRIBUTE;
    }
    return pNode->QueryIntValue( pnVal );
}

int TiXmlElement::QueryDoubleAttribute( const char* pcName, double* pdVal ) const
{
    const TiXmlAttribute* node = attributeSet.Find( pcName );
    if ( !node )
    {
        return TIXML_NO_ATTRIBUTE;
    }
    return node->QueryDoubleValue( pdVal );
}



int TiXmlElement::QueryDoubleAttribute( const std::string& strName, double* pdVal ) const
{
    const TiXmlAttribute* node = attributeSet.Find( strName );
    if ( !node )
    {
        return TIXML_NO_ATTRIBUTE;
    }

    return node->QueryDoubleValue( pdVal );
}


void TiXmlElement::SetAttribute( const char * pcName, int nVal )
{
    char buf[64];
#if defined(TIXML_SNPRINTF)
    TIXML_SNPRINTF( buf, sizeof(buf), "%d", nVal );
#else
    sprintf( buf, "%d", nVal );
#endif
    SetAttribute( pcName, buf );
}



void TiXmlElement::SetAttribute( const std::string& strName, int nVal )
{
    std::ostringstream oss;
    oss <<nVal;
    SetAttribute( strName, oss.str() );
}

void TiXmlElement::SetDoubleAttribute( const char * pcName, double dVal )
{
    char buf[256];
#if defined(TIXML_SNPRINTF)
    TIXML_SNPRINTF( buf, sizeof(buf), "%f", dVal );
#else
    sprintf( buf, "%f", dVal );
#endif
    SetAttribute( pcName, buf );
}


void TiXmlElement::SetAttribute( const char * pcName, const char * pcValue )
{
    TIXML_STRING _name( pcName );
    TIXML_STRING _value( pcValue );

    TiXmlAttribute* pNode = attributeSet.Find( _name );
    if ( pNode )
    {
        pNode->SetValue( _value );
        return;
    }

    TiXmlAttribute* pAttrib = new TiXmlAttribute( pcName, pcValue );
    if ( pAttrib )
    {
        attributeSet.Add( pAttrib );
    }
    else
    {
        TiXmlDocument* document = GetDocument();
        if ( document )
        {
            document->SetError( TIXML_ERROR_OUT_OF_MEMORY, 0, 0,
                TIXML_ENCODING_UNKNOWN );
        }
    }
}

void TiXmlElement::SetAttribute( const std::string& strName, const char * pc_value )
{
    SetAttribute(strName.c_str(), pc_value);
}

void TiXmlElement::SetAttribute( const std::string& strName, const std::string& str_value )
{
    TiXmlAttribute* pNode = attributeSet.Find( strName );
    if ( pNode )
    {
        pNode->SetValue( str_value );
        return;
    }

    TiXmlAttribute* pAttrib = new TiXmlAttribute( strName, str_value );
    if ( pAttrib )
    {
        attributeSet.Add( pAttrib );
    }
    else
    {
        TiXmlDocument* document = GetDocument();
        if ( document )
        {
            document->SetError( TIXML_ERROR_OUT_OF_MEMORY, 0, 0,
                TIXML_ENCODING_UNKNOWN );
        }
    }
}


void TiXmlElement::Print( FILE* pfile, int nDepth ) const
{
    int i;
    assert( pfile );
    for ( i=0; i<nDepth; i++ )
    {
        fprintf( pfile, "    " );
    }

    fprintf( pfile, "<%s", value.c_str() );

    const TiXmlAttribute* attrib;
    for ( attrib = attributeSet.First(); attrib; attrib = attrib->Next() )
    {
        fprintf( pfile, " " );
        attrib->Print( pfile, nDepth );
    }

    // There are 3 different formatting approaches:
    // 1) An element without children is printed as a <foo /> node
    // 2) An element with only a text child is printed as <foo> text </foo>
    // 3) An element with children is printed on multiple lines.
    TiXmlNode* pNode;
    if ( !pFirstChild )
    {
        fprintf( pfile, " />" );
    }
    else if ( pFirstChild == pLastChild && pFirstChild->ToText() )
    {
        fprintf( pfile, ">" );
        pFirstChild->Print( pfile, nDepth + 1 );
        fprintf( pfile, "</%s>", value.c_str() );
    }
    else
    {
        fprintf( pfile, ">" );

        for ( pNode = pFirstChild; pNode; pNode=pNode->NextSibling() )
        {
            if ( !pNode->ToText() )
            {
                fprintf( pfile, "\n" );
            }
            pNode->Print( pfile, nDepth+1 );
        }
        fprintf( pfile, "\n" );
        for( i=0; i<nDepth; ++i )
        {
            fprintf( pfile, "    " );
        }
        fprintf( pfile, "</%s>", value.c_str() );
    }
}


void TiXmlElement::CopyTo( TiXmlElement* pTarget ) const
{
    // superclass:
    TiXmlNode::CopyTo( pTarget );

    // Element class:
    // Clone the attributes, then clone the children.
    const TiXmlAttribute* pAttribute = 0;
    for(    pAttribute = attributeSet.First();
        pAttribute;
        pAttribute = pAttribute->Next() )
    {
        pTarget->SetAttribute( pAttribute->Name(), pAttribute->Value() );
    }

    TiXmlNode* pNode = 0;
    for ( pNode = pFirstChild; pNode; pNode = pNode->NextSibling() )
    {
        pTarget->LinkEndChild( pNode->Clone() );
    }
}

bool TiXmlElement::Accept( TiXmlVisitor* pvisitor ) const
{
    if ( pvisitor->VisitEnter( *this, attributeSet.First() ) )
    {
        for ( const TiXmlNode* node=FirstChild(); node; node=node->NextSibling() )
        {
            if ( !node->Accept( pvisitor ) )
            {
                break;
            }
        }
    }
    return pvisitor->VisitExit( *this );
}


TiXmlNode* TiXmlElement::Clone() const
{
    TiXmlElement* pClone = new TiXmlElement( Value() );
    if ( !pClone )
    {
        return 0;
    }

    CopyTo( pClone );
    return pClone;
}


const char* TiXmlElement::GetText() const
{
    const TiXmlNode* pChild = this->FirstChild();
    if ( pChild )
    {
        const TiXmlText* childText = pChild->ToText();
        if ( childText )
        {
            return childText->Value();
        }
    }
    return 0;
}


TiXmlDocument::TiXmlDocument() : TiXmlNode( TiXmlNode::DOCUMENT )
{
    nTabsize = 4;
    bUseMicrosoftBOM = false;
    ClearError();
}

TiXmlDocument::TiXmlDocument( const char * pDocumentName ) : TiXmlNode( TiXmlNode::DOCUMENT )
{
    nTabsize = 4;
    bUseMicrosoftBOM = false;
    value = pDocumentName;
    ClearError();
}

TiXmlDocument::TiXmlDocument( const std::string& strDocumentName ) : TiXmlNode( TiXmlNode::DOCUMENT)
{
    nTabsize = 4;
    bUseMicrosoftBOM = false;
    value = strDocumentName;
    ClearError();
}

TiXmlDocument::TiXmlDocument( const TiXmlDocument& copy ) : TiXmlNode( TiXmlNode::DOCUMENT )
{
    copy.CopyTo( this );
}

void TiXmlDocument::operator=( const TiXmlDocument& copy )
{
    Clear();
    copy.CopyTo( this );
}

bool TiXmlDocument::LoadFile( TiXmlEncoding encoding )
{

    return LoadFile( Value(), encoding );
}

bool TiXmlDocument::SaveFile() const
{
    return SaveFile( Value() );
}

bool TiXmlDocument::LoadFile( const char*pc_filename, TiXmlEncoding encoding )
{
    // There was a really terrifying little bug here. The code:
    //        value = filename
    // in the STL case, cause the assignment method of the std::string to
    // be called. What is strange, is that the std::string had the same
    // address as it's c_str() method, and so bad things happen. Looks
    // like a bug in the Microsoft STL implementation.
    // Add an extra string to avoid the crash.
    TIXML_STRING filename( pc_filename );
    value = filename;

    // reading in binary mode so that tinyxml can normalize the EOL
    //FILE* pFile = fopen( value.c_str (), "rb" );
    FILE* pFile = _fsopen(value.c_str (), "rb", _SH_DENYWR);

    if ( pFile )
    {
        bool result = LoadFile( pFile, encoding );
        fclose( pFile );
        return result;
    }
    else
    {
        SetError( TIXML_ERROR_OPENING_FILE, 0, 0, TIXML_ENCODING_UNKNOWN );
        return false;
    }
}

bool TiXmlDocument::LoadFile( FILE* pFile, TiXmlEncoding encoding )
{
    if ( !pFile )
    {
        SetError( TIXML_ERROR_OPENING_FILE, 0, 0, TIXML_ENCODING_UNKNOWN );
        return false;
    }

    // Delete the existing data:
    Clear();
    location.Clear();

    // Get the file size, so we can pre-allocate the string. HUGE speed impact.
    long nLength = 0;
    fseek( pFile, 0, SEEK_END );
    nLength = ftell( pFile );
    fseek( pFile, 0, SEEK_SET );

    // Strange case, but good to handle up front.
    if ( nLength == 0 )
    {
        SetError( TIXML_ERROR_DOCUMENT_EMPTY, 0, 0, TIXML_ENCODING_UNKNOWN );
        return false;
    }

    // If we have a file, assume it is all one big XML file, and read it in.
    // The document parser may decide the document ends sooner than the entire file, however.
    TIXML_STRING data;
    data.reserve( nLength );

    // Subtle bug here. TinyXml did use fgets. But from the XML spec:
    // 2.11 End-of-Line Handling
    // <snip>
    // <quote>
    // ...the XML processor MUST behave as if it normalized all line breaks in external
    // parsed entities (including the document entity) on input, before parsing, by translating
    // both the two-character sequence #xD #xA and any #xD that is not followed by #xA to
    // a single #xA character.
    // </quote>
    //
    // It is not clear fgets does that, and certainly isn't clear it works cross platform.
    // Generally, you expect fgets to translate from the convention of the OS to the c/unix
    // convention, and not work generally.

    /*
    while( fgets( buf, sizeof(buf), file ) )
    {
    data += buf;
    }
    */

    char* pcBuf = new char[ nLength+1 ];
    pcBuf[0] = 0;

    if ( fread( pcBuf, nLength, 1, pFile ) != 1 )
    {
        delete [] pcBuf;
        SetError( TIXML_ERROR_OPENING_FILE, 0, 0, TIXML_ENCODING_UNKNOWN );
        return false;
    }

    const char* pLastPos = pcBuf;
    const char* pc = pcBuf;

    pcBuf[nLength] = 0;
    while( *pc )
    {
        assert( pc < (pcBuf+nLength) );
        if ( *pc == 0xa )
        {
            // Newline character. No special rules for this. Append all the characters
            // since the last string, and include the newline.
            data.append( pLastPos, (pc-pLastPos+1) );    // append, include the newline
            ++pc;                                    // move past the newline
            pLastPos = pc;                            // and point to the new buffer (may be 0)
            assert( pc <= (pcBuf+nLength) );
        }
        else if ( *pc == 0xd )
        {
            // Carriage return. Append what we have so far, then
            // handle moving forward in the buffer.
            if ( (pc-pLastPos) > 0 )
            {
                data.append( pLastPos, pc-pLastPos );    // do not add the CR
            }
            data += (char)0xa;                        // a proper newline

            if ( *(pc+1) == 0xa )
            {
                // Carriage return - new line sequence
                pc += 2;
                pLastPos = pc;
                assert( pc <= (pcBuf+nLength) );
            }
            else
            {
                // it was followed by something else...that is presumably characters again.
                ++pc;
                pLastPos = pc;
                assert( pc <= (pcBuf+nLength) );
            }
        }
        else
        {
            ++pc;
        }
    }

    // Handle any left over characters.
    if ( pc-pLastPos )
    {
        data.append( pLastPos, pc-pLastPos );
    }
    delete [] pcBuf;
    pcBuf = 0;

    Parse( data.c_str(), 0, encoding );

    if (  Error() )
    {
        return false;
    }
    else
    {
        return true;
    }
}


bool TiXmlDocument::SaveFile( const char * pFilename ) const
{
    // The old c stuff lives on...
    //FILE* pF = fopen( pFilename, "w" );
    FILE* pF = _fsopen(pFilename, "w", _SH_DENYWR);
    if ( pF )
    {
        bool result = SaveFile( pF );
        fclose( pF );
        return result;
    }
    return false;
}


bool TiXmlDocument::SaveFile( FILE* fp ) const
{
    if ( bUseMicrosoftBOM )
    {
        const unsigned char TIXML_UTF_LEAD_0 = 0xefU;
        const unsigned char TIXML_UTF_LEAD_1 = 0xbbU;
        const unsigned char TIXML_UTF_LEAD_2 = 0xbfU;

        fputc( TIXML_UTF_LEAD_0, fp );
        fputc( TIXML_UTF_LEAD_1, fp );
        fputc( TIXML_UTF_LEAD_2, fp );
    }
    Print( fp, 0 );
    return (ferror(fp) == 0);
}


void TiXmlDocument::CopyTo( TiXmlDocument* pTarget ) const
{
    TiXmlNode::CopyTo( pTarget );

    pTarget->bError = bError;
    pTarget->errorDesc = errorDesc.c_str ();

    TiXmlNode* node = 0;
    for ( node = pFirstChild; node; node = node->NextSibling() )
    {
        pTarget->LinkEndChild( node->Clone() );
    }
}


TiXmlNode* TiXmlDocument::Clone() const
{
    TiXmlDocument* clone = new TiXmlDocument();
    if ( !clone )
    {
        return 0;
    }

    CopyTo( clone );
    return clone;
}


void TiXmlDocument::Print( FILE* pFile, int nDepth ) const
{
    assert( pFile );
    for ( const TiXmlNode* pNode=FirstChild(); pNode; pNode=pNode->NextSibling() )
    {
        pNode->Print( pFile, nDepth );
        fprintf( pFile, "\n" );
    }
}


bool TiXmlDocument::Accept( TiXmlVisitor* pVisitor ) const
{
    if ( pVisitor->VisitEnter( *this ) )
    {
        for ( const TiXmlNode* node=FirstChild(); node; node=node->NextSibling() )
        {
            if ( !node->Accept( pVisitor ) )
                break;
        }
    }
    return pVisitor->VisitExit( *this );
}


const TiXmlAttribute* TiXmlAttribute::Next() const
{
    // We are using knowledge of the sentinel. The sentinel
    // have a value or name.
    if ( pNext->value.empty() && pNext->name.empty() )
    {
        return 0;
    }

    return pNext;
}

/*
TiXmlAttribute* TiXmlAttribute::Next()
{
// We are using knowledge of the sentinel. The sentinel
// have a value or name.
if ( next->value.empty() && next->name.empty() )
return 0;
return next;
}
*/

const TiXmlAttribute* TiXmlAttribute::Previous() const
{
    // We are using knowledge of the sentinel. The sentinel
    // have a value or name.
    if ( pPrev->value.empty() && pPrev->name.empty() )
    {
        return 0;
    }
    return pPrev;
}

/*
TiXmlAttribute* TiXmlAttribute::Previous()
{
// We are using knowledge of the sentinel. The sentinel
// have a value or name.
if ( prev->value.empty() && prev->name.empty() )
return 0;
return prev;
}
*/

void TiXmlAttribute::Print( FILE* pFile, int /*nDepth*/, TIXML_STRING* pStr ) const
{
    TIXML_STRING n, v;

    PutString( name, &n );
    PutString( value, &v );

    if (value.find ('\"') == TIXML_STRING::npos)
    {
        if ( pFile )
        {
            fprintf (pFile, "%s=\"%s\"", n.c_str(), v.c_str() );
        }

        if ( pStr )
        {
            (*pStr) += n; (*pStr) += "=\""; (*pStr) += v; (*pStr) += "\"";
        }
    }
    else
    {
        if ( pFile )
        {
            fprintf (pFile, "%s='%s'", n.c_str(), v.c_str() );
        }

        if ( pStr )
        {
            (*pStr) += n; (*pStr) += "='"; (*pStr) += v; (*pStr) += "'";
        }
    }
}


int TiXmlAttribute::QueryIntValue( int* pnVal ) const
{
    if(sscanf_s(value.c_str(), "%d", pnVal ) == 1)
    {
        return TIXML_SUCCESS;
    }
    return TIXML_WRONG_TYPE;
}

int TiXmlAttribute::QueryDoubleValue( double* pdVal ) const
{
    if(sscanf_s(value.c_str(), "%lf", pdVal ) == 1)
    {
        return TIXML_SUCCESS;
    }
    return TIXML_WRONG_TYPE;
}

void TiXmlAttribute::SetIntValue( int n_value )
{
    char cBuf [64];
#if defined(TIXML_SNPRINTF)
    TIXML_SNPRINTF(cBuf, sizeof(cBuf), "%d", n_value);
#else
    sprintf (cBuf, "%d", n_value);
#endif
    SetValue (cBuf);
}

void TiXmlAttribute::SetDoubleValue( double d_value )
{
    char cBuf [256];
#if defined(TIXML_SNPRINTF)
    TIXML_SNPRINTF( cBuf, sizeof(cBuf), "%lf", d_value);
#else
    sprintf (cBuf, "%lf", d_value);
#endif
    SetValue (cBuf);
}

int TiXmlAttribute::IntValue() const
{
    return atoi (value.c_str ());
}

double  TiXmlAttribute::DoubleValue() const
{
    return atof (value.c_str ());
}

TiXmlComment::TiXmlComment( const TiXmlComment& copy ) : TiXmlNode( TiXmlNode::COMMENT )
{
    copy.CopyTo( this );
}


void TiXmlComment::operator=( const TiXmlComment& base )
{
    Clear();
    base.CopyTo( this );
}


void TiXmlComment::Print( FILE* pFile, int nDepth ) const
{
    assert( pFile );
    for ( int i=0; i<nDepth; i++ )
    {
        fprintf( pFile,  "    " );
    }
    fprintf( pFile, "<!--%s-->", value.c_str() );
}


void TiXmlComment::CopyTo( TiXmlComment* pTarget ) const
{
    TiXmlNode::CopyTo( pTarget );
}


bool TiXmlComment::Accept( TiXmlVisitor* pVisitor ) const
{
    return pVisitor->Visit( *this );
}


TiXmlNode* TiXmlComment::Clone() const
{
    TiXmlComment* clone = new TiXmlComment();

    if ( !clone )
    {
        return 0;
    }

    CopyTo( clone );
    return clone;
}


void TiXmlText::Print( FILE* pFile, int nDepth ) const
{
    assert( pFile );
    if ( bData )
    {
        int i;
        fprintf( pFile, "\n" );
        for ( i=0; i<nDepth; i++ )
        {
            fprintf( pFile, "    " );
        }
        fprintf( pFile, "<![CDATA[%s]]>\n", value.c_str() );    // unformatted output
    }
    else
    {
        TIXML_STRING buffer;
        PutString( value, &buffer );
        fprintf( pFile, "%s", buffer.c_str() );
    }
}


void TiXmlText::CopyTo( TiXmlText* pTarget ) const
{
    TiXmlNode::CopyTo( pTarget );
    pTarget->bData = bData;
}


bool TiXmlText::Accept( TiXmlVisitor* pVisitor ) const
{
    return pVisitor->Visit( *this );
}


TiXmlNode* TiXmlText::Clone() const
{
    TiXmlText* pClone = 0;
    pClone = new TiXmlText( "" );

    if ( !pClone )
    {
        return 0;
    }

    CopyTo( pClone );
    return pClone;
}


TiXmlDeclaration::TiXmlDeclaration( const char * pc_version,
    const char * pc_encoding,
    const char * pc_standalone )
    : TiXmlNode( TiXmlNode::DECLARATION )
{
    version = pc_version;
    encoding = pc_encoding;
    standalone = pc_standalone;
}



TiXmlDeclaration::TiXmlDeclaration(    const std::string& str_version,
    const std::string& str_encoding,
    const std::string& str_standalone )
    : TiXmlNode( TiXmlNode::DECLARATION )
{
    version = str_version;
    encoding = str_encoding;
    standalone = str_standalone;
}



TiXmlDeclaration::TiXmlDeclaration( const TiXmlDeclaration& copy )
    : TiXmlNode( TiXmlNode::DECLARATION )
{
    copy.CopyTo( this );
}


void TiXmlDeclaration::operator=( const TiXmlDeclaration& copy )
{
    Clear();
    copy.CopyTo( this );
}


void TiXmlDeclaration::Print( FILE* pFile, int /*nDepth*/, TIXML_STRING* pStr ) const
{
    if ( pFile ) fprintf( pFile, "<?xml " );
    if ( pStr )     (*pStr) += "<?xml ";

    if ( !version.empty() )
    {
        if ( pFile )
        {
            fprintf (pFile, "version=\"%s\" ", version.c_str ());
        }

        if ( pStr )
        {
            (*pStr) += "version=\""; (*pStr) += version; (*pStr) += "\" ";
        }
    }

    if ( !encoding.empty() )
    {
        if ( pFile )
        {
            fprintf (pFile, "encoding=\"%s\" ", encoding.c_str ());
        }

        if ( pStr )
        {
            (*pStr) += "encoding=\""; (*pStr) += encoding; (*pStr) += "\" ";
        }
    }

    if ( !standalone.empty() )
    {
        if ( pFile )
        {
            fprintf (pFile, "standalone=\"%s\" ", standalone.c_str ());
        }

        if ( pStr )
        {
            (*pStr) += "standalone=\""; (*pStr) += standalone; (*pStr) += "\" ";
        }
    }

    if ( pFile )
    {
        fprintf( pFile, "?>" );
    }

    if ( pStr )
    {
        (*pStr) += "?>";
    }
}


void TiXmlDeclaration::CopyTo( TiXmlDeclaration* pTarget ) const
{
    TiXmlNode::CopyTo( pTarget );

    pTarget->version = version;
    pTarget->encoding = encoding;
    pTarget->standalone = standalone;
}


bool TiXmlDeclaration::Accept( TiXmlVisitor* pVisitor ) const
{
    return pVisitor->Visit( *this );
}


TiXmlNode* TiXmlDeclaration::Clone() const
{
    TiXmlDeclaration* pClone = new TiXmlDeclaration();

    if ( !pClone )
    {
        return 0;
    }

    CopyTo( pClone );
    return pClone;
}


void TiXmlUnknown::Print( FILE* pFile, int nDepth ) const
{
    for ( int i=0; i<nDepth; i++ )
    {
        fprintf( pFile, "    " );
    }

    fprintf( pFile, "<%s>", value.c_str() );
}


void TiXmlUnknown::CopyTo( TiXmlUnknown* pTarget ) const
{
    TiXmlNode::CopyTo( pTarget );
}


bool TiXmlUnknown::Accept( TiXmlVisitor* pVisitor ) const
{
    return pVisitor->Visit( *this );
}


TiXmlNode* TiXmlUnknown::Clone() const
{
    TiXmlUnknown* clone = new TiXmlUnknown();

    if ( !clone )
    {
        return 0;
    }

    CopyTo( clone );
    return clone;
}


TiXmlAttributeSet::TiXmlAttributeSet()
{
    sentinel.pNext = &sentinel;
    sentinel.pPrev = &sentinel;
}


TiXmlAttributeSet::~TiXmlAttributeSet()
{
    assert( sentinel.pNext == &sentinel );
    assert( sentinel.pPrev == &sentinel );
}


void TiXmlAttributeSet::Add( TiXmlAttribute* pAddMe )
{
    assert( !Find( TIXML_STRING( pAddMe->Name() ) ) );    // Shouldn't be multiply adding to the set.
    pAddMe->pNext = &sentinel;
    pAddMe->pPrev = sentinel.pPrev;

    sentinel.pPrev->pNext = pAddMe;
    sentinel.pPrev      = pAddMe;
}

void TiXmlAttributeSet::Remove( TiXmlAttribute* pRemoveMe )
{
    TiXmlAttribute* pNode;

    for( pNode = sentinel.pNext; pNode != &sentinel; pNode = pNode->pNext )
    {
        if ( pNode == pRemoveMe )
        {
            pNode->pPrev->pNext = pNode->pNext;
            pNode->pNext->pPrev = pNode->pPrev;
            pNode->pNext = 0;
            pNode->pPrev = 0;
            return;
        }
    }
    assert( 0 );        // we tried to remove a non-linked attribute.
}

const TiXmlAttribute* TiXmlAttributeSet::Find( const std::string& strName ) const
{
    for( const TiXmlAttribute* pNode = sentinel.pNext; pNode != &sentinel; pNode = pNode->pNext )
    {
        if ( pNode->name == strName )
        {
            return pNode;
        }
    }
    return 0;
}


const TiXmlAttribute* TiXmlAttributeSet::Find( const char* pcName ) const
{
    for( const TiXmlAttribute* pNode = sentinel.pNext; pNode != &sentinel; pNode = pNode->pNext )
    {
        if ( strcmp( pNode->name.c_str(), pcName ) == 0 )
        {
            return pNode;
        }
    }
    return 0;
}



std::istream& operator>> (std::istream & in, TiXmlNode & base)
{
    TIXML_STRING tag;
    tag.reserve( 8 * 1000 );
    base.StreamIn( &in, &tag );

    base.Parse( tag.c_str(), 0, TIXML_DEFAULT_ENCODING );
    return in;
}



std::ostream& operator<< (std::ostream & out, const TiXmlNode & base)
{
    TiXmlPrinter printer;
    printer.SetStreamPrinting();
    base.Accept( &printer );
    out << printer.Str();

    return out;
}


std::string& operator<< (std::string& strOut, const TiXmlNode& base )
{
    TiXmlPrinter printer;
    printer.SetStreamPrinting();
    base.Accept( &printer );
    strOut.append( printer.Str() );

    return strOut;
}


TiXmlHandle TiXmlHandle::FirstChild() const
{
    if ( pNode )
    {
        TiXmlNode* pChild = pNode->FirstChild();
        if ( pChild )
        {
            return TiXmlHandle( pChild );
        }
    }

    return TiXmlHandle( 0 );
}


TiXmlHandle TiXmlHandle::FirstChild( const char * pcValue ) const
{
    if ( pNode )
    {
        TiXmlNode* pChild = pNode->FirstChild( pcValue );
        if ( pChild )
        {
            return TiXmlHandle( pChild );
        }
    }
    return TiXmlHandle( 0 );
}


TiXmlHandle TiXmlHandle::FirstChildElement() const
{
    if ( pNode )
    {
        TiXmlElement* pChild = pNode->FirstChildElement();
        if ( pChild )
        {
            return TiXmlHandle( pChild );
        }
    }
    return TiXmlHandle( 0 );
}


TiXmlHandle TiXmlHandle::FirstChildElement( const char * pcValue ) const
{
    if ( pNode )
    {
        TiXmlElement* pChild = pNode->FirstChildElement( pcValue );
        if ( pChild )
        {
            return TiXmlHandle( pChild );
        }
    }
    return TiXmlHandle( 0 );
}


TiXmlHandle TiXmlHandle::Child( int nCount ) const
{
    if ( pNode )
    {
        int i;
        TiXmlNode* pChild = pNode->FirstChild();
        for (    i=0;
            pChild && i<nCount;
            pChild = pChild->NextSibling(), ++i )
        {
            // nothing
        }

        if ( pChild )
        {
            return TiXmlHandle( pChild );
        }
    }
    return TiXmlHandle( 0 );
}


TiXmlHandle TiXmlHandle::Child( const char* pcValue, int nCount ) const
{
    if ( pNode )
    {
        int i;
        TiXmlNode* pChild = pNode->FirstChild( pcValue );
        for (    i=0;
            pChild && i<nCount;
            pChild = pChild->NextSibling( pcValue ), ++i )
        {
            // nothing
        }

        if ( pChild )
        {
            return TiXmlHandle( pChild );
        }
    }
    return TiXmlHandle( 0 );
}


TiXmlHandle TiXmlHandle::ChildElement( int nCount ) const
{
    if ( pNode )
    {
        int i;
        TiXmlElement* pChild = pNode->FirstChildElement();
        for (    i=0;
            pChild && i<nCount;
            pChild = pChild->NextSiblingElement(), ++i )
        {
            // nothing
        }

        if ( pChild )
        {
            return TiXmlHandle( pChild );
        }
    }
    return TiXmlHandle( 0 );
}


TiXmlHandle TiXmlHandle::ChildElement( const char* pcValue, int nCount ) const
{
    if ( pNode )
    {
        int i;
        TiXmlElement* pChild = pNode->FirstChildElement( pcValue );
        for (    i=0;
            pChild && i<nCount;
            pChild = pChild->NextSiblingElement( pcValue ), ++i )
        {
            // nothing
        }

        if ( pChild )
        {
            return TiXmlHandle( pChild );
        }
    }
    return TiXmlHandle( 0 );
}


bool TiXmlPrinter::VisitEnter( const TiXmlDocument& )
{
    return true;
}

bool TiXmlPrinter::VisitExit( const TiXmlDocument& )
{
    return true;
}

bool TiXmlPrinter::VisitEnter( const TiXmlElement& element, const TiXmlAttribute* pFirstAttribute )
{
    DoIndent();
    buffer += "<";
    buffer += element.Value();

    for( const TiXmlAttribute* attrib = pFirstAttribute; attrib; attrib = attrib->Next() )
    {
        buffer += " ";
        attrib->Print( 0, 0, &buffer );
    }

    if ( !element.FirstChild() )
    {
        buffer += " />";
        DoLineBreak();
    }
    else
    {
        buffer += ">";
        if (element.FirstChild()->ToText()
            && element.LastChild() == element.FirstChild()
            && !element.FirstChild()->ToText()->CDATA())
        {
            bSimpleTextPrint = true;
            // no DoLineBreak()!
        }
        else
        {
            DoLineBreak();
        }
    }
    ++nDepth;
    return true;
}


bool TiXmlPrinter::VisitExit( const TiXmlElement& element )
{
    --nDepth;
    if ( !element.FirstChild() )
    {
        // nothing.
    }
    else
    {
        if ( bSimpleTextPrint )
        {
            bSimpleTextPrint = false;
        }
        else
        {
            DoIndent();
        }
        buffer += "</";
        buffer += element.Value();
        buffer += ">";
        DoLineBreak();
    }
    return true;
}


bool TiXmlPrinter::Visit( const TiXmlText& text )
{
    if ( text.CDATA() )
    {
        DoIndent();
        buffer += "<![CDATA[";
        buffer += text.Value();
        buffer += "]]>";
        DoLineBreak();
    }
    else if ( bSimpleTextPrint )
    {
        buffer += text.Value();
    }
    else
    {
        DoIndent();
        buffer += text.Value();
        DoLineBreak();
    }
    return true;
}


bool TiXmlPrinter::Visit( const TiXmlDeclaration& declaration )
{
    DoIndent();
    declaration.Print( 0, 0, &buffer );
    DoLineBreak();
    return true;
}


bool TiXmlPrinter::Visit( const TiXmlComment& comment )
{
    DoIndent();
    buffer += "<!--";
    buffer += comment.Value();
    buffer += "-->";
    DoLineBreak();
    return true;
}


bool TiXmlPrinter::Visit( const TiXmlUnknown& unknown )
{
    DoIndent();
    buffer += "<";
    buffer += unknown.Value();
    buffer += ">";
    DoLineBreak();
    return true;
}

