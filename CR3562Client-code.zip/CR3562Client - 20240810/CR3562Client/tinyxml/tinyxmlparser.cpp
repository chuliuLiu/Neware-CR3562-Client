/*
www.sourceforge.net/projects/tinyxml
Original code (2.0 and earlier )copyright (c) 2000-2002 Lee Thomason (www.grinninglizard.com)

This software is provided 'as-is', without any express or implied
warranty. In no event will the authors be held liable for any
damages arising from the use of this software.

Permission is granted to anyone to use this software for any
purpose, including commercial applications, and to alter it and
redistribute it freely, subject to the following restrictions:

1. The origin of this software must not be misrepresented; you must
not claim that you wrote the original software. If you use this
software in a product, an acknowledgment in the product documentation
would be appreciated but is not required.

2. Altered source versions must be plainly marked as such, and
must not be misrepresented as being the original software.

3. This notice may not be removed or altered from any source
distribution.
*/

#include "pch.h"
#include <ctype.h>
#include <stddef.h>

#include "tinyxml.h"

//#define DEBUG_PARSER
#if defined( DEBUG_PARSER )
#    if defined( DEBUG ) && defined( _MSC_VER )
#        include <windows.h>
#       ifndef TIXML_LOG
#        define TIXML_LOG OutputDebugString
#       endif
#    else
//#       ifndef TIXML_LOG
//#        define TIXML_LOG printf
//#       endif
#    endif
#endif

// Note tha "PutString" hardcodes the same list. This
// is less flexible than it appears. Changing the entries
// or order will break putstring.
TiXmlBase::Entity TiXmlBase::entity[ NUM_ENTITY ] =
{
    { "&amp;",  5, '&' },
    { "&lt;",   4, '<' },
    { "&gt;",   4, '>' },
    { "&quot;", 6, '\"' },
    { "&apos;", 6, '\'' }
};

// Bunch of unicode info at:
//        http://www.unicode.org/faq/utf_bom.html
// Including the basic of this table, which determines the #bytes in the
// sequence from the lead byte. 1 placed for invalid sequences --
// although the result will be junk, pass it through as much as possible.
// Beware of the non-characters in UTF-8:
//                ef bb bf (Microsoft "lead bytes")
//                ef bf be
//                ef bf bf

const unsigned char TIXML_UTF_LEAD_0 = 0xefU;
const unsigned char TIXML_UTF_LEAD_1 = 0xbbU;
const unsigned char TIXML_UTF_LEAD_2 = 0xbfU;

const int TiXmlBase::utf8ByteTable[256] =
{
    //    0    1    2    3    4    5    6    7    8    9    a    b    c    d    e    f
    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    // 0x00
    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    // 0x10
    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    // 0x20
    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    // 0x30
    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    // 0x40
    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    // 0x50
    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    // 0x60
    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    // 0x70    End of ASCII range
    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    // 0x80 0x80 to 0xc1 invalid
    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    // 0x90
    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    // 0xa0
    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    // 0xb0
    1,    1,    2,    2,    2,    2,    2,    2,    2,    2,    2,    2,    2,    2,    2,    2,    // 0xc0 0xc2 to 0xdf 2 byte
    2,    2,    2,    2,    2,    2,    2,    2,    2,    2,    2,    2,    2,    2,    2,    2,    // 0xd0
    3,    3,    3,    3,    3,    3,    3,    3,    3,    3,    3,    3,    3,    3,    3,    3,    // 0xe0 0xe0 to 0xef 3 byte
    4,    4,    4,    4,    4,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1    // 0xf0 0xf0 to 0xf4 4 byte,
    //0xf5 and higher invalid
};


void TiXmlBase::ConvertUTF32ToUTF8( unsigned long nInput, char* pcOutput, int* pnLength )
{
    const unsigned long BYTE_MASK = 0xBF;
    const unsigned long BYTE_MARK = 0x80;
    const unsigned long FIRST_BYTE_MARK[7] = { 0x00, 0x00, 0xC0, 0xE0, 0xF0, 0xF8, 0xFC };

    if (nInput < 0x80)
    {
        *pnLength = 1;
    }
    else if ( nInput < 0x800 )
    {
        *pnLength = 2;
    }
    else if ( nInput < 0x10000 )
    {
        *pnLength = 3;
    }
    else if ( nInput < 0x200000 )
    {
        *pnLength = 4;
    }
    else
    {
        *pnLength = 0;
        return;
    }    // This code won't covert this correctly anyway.

    pcOutput += *pnLength;

    // Scary scary fall throughs.
    switch (*pnLength)
    {
    case 4:
        --pcOutput;
        *pcOutput = (char)((nInput | BYTE_MARK) & BYTE_MASK);
        nInput >>= 6;
    case 3:
        --pcOutput;
        *pcOutput = (char)((nInput | BYTE_MARK) & BYTE_MASK);
        nInput >>= 6;
    case 2:
        --pcOutput;
        *pcOutput = (char)((nInput | BYTE_MARK) & BYTE_MASK);
        nInput >>= 6;
    case 1:
        --pcOutput;
        *pcOutput = (char)(nInput | FIRST_BYTE_MARK[*pnLength]);
    }
}


/*static*/ int TiXmlBase::IsAlpha( unsigned char btAny, TiXmlEncoding /*encoding*/ )
{
    // This will only work for low-ascii, everything else is assumed to be a valid
    // letter. I'm not sure this is the best approach, but it is quite tricky trying
    // to figure out alhabetical vs. not across encoding. So take a very
    // conservative approach.

    //    if ( encoding == TIXML_ENCODING_UTF8 )
    //    {
    if ( btAny < 127 )
    {
        return isalpha( btAny );
    }
    else
    {
        return 1;    // What else to do? The unicode set is huge...get the english ones right.
    }
}


/*static*/ int TiXmlBase::IsAlphaNum( unsigned char btAny, TiXmlEncoding /*encoding*/ )
{
    // This will only work for low-ascii, everything else is assumed to be a valid
    // letter. I'm not sure this is the best approach, but it is quite tricky trying
    // to figure out alhabetical vs. not across encoding. So take a very
    // conservative approach.

    //    if ( encoding == TIXML_ENCODING_UTF8 )
    //    {
    if ( btAny < 127 )
    {
        return isalnum( btAny );
    }
    else
    {
        return 1;    // What else to do? The unicode set is huge...get the english ones right.
    }
    //    }
    //    else
    //    {
    //        return isalnum( anyByte );
    //    }
}


class TiXmlParsingData
{
    friend class TiXmlDocument;
public:
    void Stamp( const char* pcNow, TiXmlEncoding encoding );

    const TiXmlCursor& Cursor()
    {
        return cursor;
    }

private:
    // Only used by the document!
    TiXmlParsingData( const char* pcStart, int n_tabsize, int nRow, int nCol )
    {
        assert( pcStart );
        stamp = pcStart;
        nTabsize = n_tabsize;
        cursor.nRow = nRow;
        cursor.nCol = nCol;
    }

    TiXmlCursor        cursor;
    const char*        stamp;
    int                nTabsize;
};


void TiXmlParsingData::Stamp( const char* pNow, TiXmlEncoding encoding )
{
    assert( pNow );

    // Do nothing if the nTabsize is 0.
    if ( nTabsize < 1 )
    {
        return;
    }

    // Get the current nRow, column.
    int nRow = cursor.nRow;
    int nCol = cursor.nCol;
    const char* p = stamp;
    assert( p );

    while( p < pNow )
    {
        // Treat p as unsigned, so we have a happy compiler.
        const unsigned char* pU = (const unsigned char*)p;

        // Code contributed by Fletcher Dunn: (modified by lee)
        switch (*pU)
        {
        case 0:
            // We *should* never get here, but in case we do, don't
            // advance past the terminating null nCharacter, ever
            return;

        case '\r':
            // bump down to the next line
            ++nRow;
            nCol = 0;
            // Eat the nCharacter
            ++p;

            // Check for \r\n sequence, and treat this as a single nCharacter
            if (*p == '\n')
            {
                ++p;
            }
            break;

        case '\n':
            // bump down to the next line
            ++nRow;
            nCol = 0;

            // Eat the nCharacter
            ++p;

            // Check for \n\r sequence, and treat this as a single
            // nCharacter.  (Yes, this bizarre thing does occur still
            // on some arcane platforms...)
            if (*p == '\r')
            {
                ++p;
            }
            break;

        case '\t':
            // Eat the nCharacter
            ++p;

            // Skip to next tab stop
            nCol = (nCol / nTabsize + 1) * nTabsize;
            break;

        case TIXML_UTF_LEAD_0:
            if ( encoding == TIXML_ENCODING_UTF8 )
            {
                if ( *(p+1) && *(p+2) )
                {
                    // In these cases, don't advance the column. These are
                    // 0-width spaces.
                    if ( *(pU+1)==TIXML_UTF_LEAD_1 && *(pU+2)==TIXML_UTF_LEAD_2 )
                    {
                        p += 3;
                    }
                    else if ( *(pU+1)==0xbfU && *(pU+2)==0xbeU )
                    {
                        p += 3;
                    }
                    else if ( *(pU+1)==0xbfU && *(pU+2)==0xbfU )
                    {
                        p += 3;
                    }
                    else
                    {
                        p +=3;
                        ++nCol;
                    }    // A normal nCharacter.
                }
            }
            else
            {
                ++p;
                ++nCol;
            }
            break;

        default:
            if ( encoding == TIXML_ENCODING_UTF8 )
            {
                // Eat the 1 to 4 byte utf8 nCharacter.
                int step = TiXmlBase::utf8ByteTable[*((const unsigned char*)p)];
                if ( step == 0 )
                {
                    step = 1;        // Error case from bad encoding, but handle gracefully.
                }
                p += step;

                // Just advance one column, of course.
                ++nCol;
            }
            else
            {
                ++p;
                ++nCol;
            }
            break;
        }
    }

    cursor.nRow = nRow;
    cursor.nCol = nCol;
    assert( cursor.nRow >= -1 );
    assert( cursor.nCol >= -1 );
    stamp = p;
    assert( stamp );
}


const char* TiXmlBase::SkipWhiteSpace( const char* pc, TiXmlEncoding encoding )
{
    if ( !pc || !*pc )
    {
        return 0;
    }

    if ( encoding == TIXML_ENCODING_UTF8 )
    {
        while( *pc )
        {
            const unsigned char* pU = (const unsigned char*)pc;

            // Skip the stupid Microsoft UTF-8 Byte order marks
            if (    *(pU+0)==TIXML_UTF_LEAD_0
                && *(pU+1)==TIXML_UTF_LEAD_1
                && *(pU+2)==TIXML_UTF_LEAD_2 )
            {
                pc += 3;
                continue;
            }
            else if(*(pU+0)==TIXML_UTF_LEAD_0
                && *(pU+1)==0xbfU
                && *(pU+2)==0xbeU )
            {
                pc += 3;
                continue;
            }
            else if(*(pU+0)==TIXML_UTF_LEAD_0
                && *(pU+1)==0xbfU
                && *(pU+2)==0xbfU )
            {
                pc += 3;
                continue;
            }

            // Still using old rules for white space.
            if ( IsWhiteSpace( *pc ) || *pc == '\n' || *pc =='\r' )
            {
                ++pc;
            }
            else
            {
                break;
            }
        }
    }
    else
    {
        while( *pc && IsWhiteSpace( *pc ) || *pc == '\n' || *pc =='\r' )
        {
            ++pc;
        }
    }

    return pc;
}


/*static*/ bool TiXmlBase::StreamWhiteSpace( std::istream * pIn, TIXML_STRING * pTag )
{
    for( ;; )
    {
        if ( !pIn->good() )
        {
            return false;
        }

        int c = pIn->peek();
        // At this scope, we can't get to a document. So fail silently.
        if ( !IsWhiteSpace( c ) || c <= 0 )
        {
            return true;
        }

        *pTag += (char) pIn->get();
    }
}

/*static*/ bool TiXmlBase::StreamTo( std::istream * pIn, int nCharacter, TIXML_STRING * pTag )
{
    //assert( nCharacter > 0 && nCharacter < 128 );    // else it won't work in utf-8
    while( pIn->good() )
    {
        int c = pIn->peek();
        if ( c == nCharacter )
        {
            return true;
        }

        if ( c <= 0 )        // Silent failure: can't get document at this scope
        {
            return false;
        }

        pIn->get();
        *pTag += (char) c;
    }

    return false;
}


// One of TinyXML's more performance demanding functions.
// Try to keep the memory overhead down. The
// "assign" optimization removes over 10% of the execution time.
//
const char* TiXmlBase::ReadName( const char* pc, TIXML_STRING * pName, TiXmlEncoding encoding )
{
    // Oddly, not supported on some comilers,
    //name->clear();
    // So use this:
    *pName = "";
    assert( pc );

    // Names start with letters or underscores.
    // Of course, in unicode, tinyxml has no idea what a letter *is*. The
    // algorithm is generous.
    //
    // After that, they can be letters, underscores, numbers,
    // hyphens, or colons. (Colons are valid ony for namespaces,
    // but tinyxml can't tell namespaces from names.)
    if (    pc && *pc && ( IsAlpha( (unsigned char) *pc, encoding ) || *pc == '_' ) )
    {
        const char* start = pc;
        while(        pc && *pc
            &&    (        IsAlphaNum( (unsigned char ) *pc, encoding )
            || *pc == '_'
            || *pc == '-'
            || *pc == '.'
            || *pc == ':' ) )
        {
            //(*name) += *pc; // expensive
            ++pc;
        }

        if ( pc-start > 0 )
        {
            pName->assign( start, pc-start );
        }

        return pc;
    }
    return 0;
}

const char* TiXmlBase::GetEntity( const char* pc, char* pcValue, int* pnLength,

    TiXmlEncoding encoding )
{
    // Presume an entity, and pull it out.
    TIXML_STRING ent;
    int i;
    *pnLength = 0;

    if ( *(pc+1) && *(pc+1) == '#' && *(pc+2) )
    {
        unsigned long nUcs = 0;
        ptrdiff_t delta = 0;
        unsigned nMult = 1;

        if ( *(pc+2) == 'x' )
        {
            // Hexadecimal.
            if ( !*(pc+3) )
            {
                return 0;
            }

            const char* pcQ = pc+3;
            pcQ = strchr( pcQ, ';' );

            if ( !pcQ || !*pcQ )
            {
                return 0;
            }

            delta = pcQ-pc;
            --pcQ;

            while( *pcQ != 'x' )
            {
                if ( *pcQ >= '0' && *pcQ <= '9' )
                {
                    nUcs += nMult * (*pcQ - '0');
                }
                else if ( *pcQ >= 'a' && *pcQ <= 'f' )
                {
                    nUcs += nMult * (*pcQ - 'a' + 10);
                }
                else if ( *pcQ >= 'A' && *pcQ <= 'F' )
                {
                    nUcs += nMult * (*pcQ - 'A' + 10 );
                }
                else
                {
                    return 0;
                }

                nMult *= 16;
                --pcQ;
            }
        }
        else
        {
            // Decimal.
            if ( !*(pc+2) )
            {
                return 0;
            }

            const char* pcQ = pc+2;
            pcQ = strchr( pcQ, ';' );

            if ( !pcQ || !*pcQ )
            {
                return 0;
            }

            delta = pcQ-pc;
            --pcQ;

            while( *pcQ != '#' )
            {
                if ( *pcQ >= '0' && *pcQ <= '9' )
                {
                    nUcs += nMult * (*pcQ - '0');
                }
                else
                {
                    return 0;
                }

                nMult *= 10;
                --pcQ;
            }
        }

        if ( encoding == TIXML_ENCODING_UTF8 )
        {
            // convert the UCS to UTF-8
            ConvertUTF32ToUTF8( nUcs, pcValue, pnLength );
        }
        else
        {
            *pcValue = (char)nUcs;
            *pnLength = 1;
        }
        return pc + delta + 1;
    }

    // Now try to match it.
    for( i=0; i<NUM_ENTITY; ++i )
    {
        if ( strncmp( entity[i].pcStr, pc, entity[i].nStrLength ) == 0 )
        {
            assert( strlen( entity[i].pcStr ) == entity[i].nStrLength );
            *pcValue = entity[i].chr;
            *pnLength = 1;
            return ( pc + entity[i].nStrLength );
        }
    }

    // So it wasn't an entity, its unrecognized, or something like that.
    *pcValue = *pc;// Don't put back the last one, since we return it!
    // *pnlength = 1;// Leave unrecognized entities - this doesn't really work.
    // Just writes strange XML.
    return pc+1;
}


bool TiXmlBase::StringEqual( const char* pc,
    const char* pTag,
    bool bIgnoreCase,
    TiXmlEncoding encoding )
{
    assert( pc );
    assert( pTag );
    if ( !pc || !*pc )
    {
        assert( 0 );
        return false;
    }

    const char* q = pc;

    if ( bIgnoreCase )
    {
        while( *q && *pTag && ToLower( *q, encoding ) == ToLower( *pTag, encoding ) )
        {
            ++q;
            ++pTag;
        }

        if ( *pTag == 0 )
        {
            return true;
        }
    }
    else
    {
        while( *q && *pTag && *q == *pTag )
        {
            ++q;
            ++pTag;
        }

        if ( *pTag == 0 )        // Have we found the end of the pTag, and everything equal?
        {
            return true;
        }
    }

    return false;
}

const char* TiXmlBase::ReadText(    const char* pIn,
    TIXML_STRING * pText,
    bool bTrimWhiteSpace,
    const char* pEndTag,
    bool bCaseInsensitive,
    TiXmlEncoding encoding )
{
    *pText = "";
    if (    !bTrimWhiteSpace            // certain tags always keep whitespace
        || !bCondenseWhiteSpace )    // if true, whitespace is always kept
    {
        // Keep all the white space.
        while(       pIn && *pIn && !StringEqual( pIn, pEndTag, bCaseInsensitive, encoding ))
        {
            int nLen;
            char cArr[4] = { 0, 0, 0, 0 };
            pIn = GetChar( pIn, cArr, &nLen, encoding );
            pText->append( cArr, nLen );
        }
    }
    else
    {
        bool bWhitespace = false;

        // Remove leading white space:
        pIn = SkipWhiteSpace( pIn, encoding );
        while(       pIn && *pIn
            && !StringEqual( pIn, pEndTag, bCaseInsensitive, encoding ) )
        {
            if ( *pIn == '\r' || *pIn == '\n' )
            {
                bWhitespace = true;
                ++pIn;
            }
            else if ( IsWhiteSpace( *pIn ) )
            {
                bWhitespace = true;
                ++pIn;
            }
            else
            {
                // If we've found whitespace, add it before the
                // new nCharacter. Any whitespace just becomes a space.
                if ( bWhitespace )
                {
                    (*pText) += ' ';
                    bWhitespace = false;
                }

                int nLen;
                char cArr[4] = { 0, 0, 0, 0 };
                pIn = GetChar( pIn, cArr, &nLen, encoding );
                if ( nLen == 1 )
                {
                    (*pText) += cArr[0];    // more efficient
                }
                else
                {
                    pText->append( cArr, nLen );
                }
            }
        }
    }

    if ( pIn )
    {
        pIn += strlen( pEndTag );
    }

    return pIn;
}


void TiXmlDocument::StreamIn( std::istream * pIn, TIXML_STRING * pTag )
{
    // The basic issue with a document is that we don't know what we're
    // streaming. Read something presumed to be a tag (and hope), then
    // identify it, and call the appropriate stream method on the tag.
    //
    // This "pre-streaming" will never read the closing ">" so the
    // sub-tag can orient itself.

    if ( !StreamTo( pIn, '<', pTag ) )
    {
        SetError( TIXML_ERROR_PARSING_EMPTY, 0, 0, TIXML_ENCODING_UNKNOWN );
        return;
    }

    while( pIn->good() )
    {
        int tagIndex = (int) pTag->length();
        while( pIn->good() && pIn->peek() != '>' )
        {
            int c = pIn->get();
            if ( c <= 0 )
            {
                SetError( TIXML_ERROR_EMBEDDED_NULL, 0, 0, TIXML_ENCODING_UNKNOWN );
                break;
            }
            (*pTag) += (char) c;
        }

        if ( pIn->good() )
        {
            // We now have something we presume to be a node of
            // some sort. Identify it, and call the node to
            // continue streaming.
            TiXmlNode* node = Identify( pTag->c_str() + tagIndex, TIXML_DEFAULT_ENCODING );

            if ( node )
            {
                node->StreamIn( pIn, pTag );
                bool isElement = node->ToElement() != 0;
                delete node;
                node = 0;

                // If this is the root element, we're done. Parsing will be
                // done by the >> operator.
                if ( isElement )
                {
                    return;
                }
            }
            else
            {
                SetError( TIXML_ERROR, 0, 0, TIXML_ENCODING_UNKNOWN );
                return;
            }
        }
    }
    // We should have returned sooner.
    SetError( TIXML_ERROR, 0, 0, TIXML_ENCODING_UNKNOWN );
}



const char* TiXmlDocument::Parse( const char* pc, TiXmlParsingData* pRevData,
    TiXmlEncoding encoding )
{
    ClearError();

    // Parse away, at the document level. Since a document
    // contains nothing but other tags, most of what happens
    // here is skipping white space.
    if ( !pc || !*pc )
    {
        SetError( TIXML_ERROR_DOCUMENT_EMPTY, 0, 0, TIXML_ENCODING_UNKNOWN );
        return 0;
    }

    // Note that, for a document, this needs to come
    // before the while space skip, so that parsing
    // starts from the pointer we are given.
    location.Clear();
    if ( pRevData )
    {
        location.nRow = pRevData->cursor.nRow;
        location.nCol = pRevData->cursor.nCol;
    }
    else
    {
        location.nRow = 0;
        location.nCol = 0;
    }
    TiXmlParsingData data( pc, TabSize(), location.nRow, location.nCol );
    location = data.Cursor();

    if ( encoding == TIXML_ENCODING_UNKNOWN )
    {
        // Check for the Microsoft UTF-8 lead bytes.
        const unsigned char* pU = (const unsigned char*)pc;
        if (    *(pU+0) && *(pU+0) == TIXML_UTF_LEAD_0
            && *(pU+1) && *(pU+1) == TIXML_UTF_LEAD_1
            && *(pU+2) && *(pU+2) == TIXML_UTF_LEAD_2 )
        {
            encoding = TIXML_ENCODING_UTF8;
            bUseMicrosoftBOM = true;
        }
    }

    pc = SkipWhiteSpace( pc, encoding );
    if ( !pc )
    {
        SetError( TIXML_ERROR_DOCUMENT_EMPTY, 0, 0, TIXML_ENCODING_UNKNOWN );
        return 0;
    }

    while( pc && *pc )
    {
        TiXmlNode* node = Identify( pc, encoding );
        if ( node )
        {
            pc = node->Parse( pc, &data, encoding );
            LinkEndChild( node );
        }
        else
        {
            break;
        }

        // Did we get encoding info?
        if (    encoding == TIXML_ENCODING_UNKNOWN
            && node->ToDeclaration() )
        {
            TiXmlDeclaration* dec = node->ToDeclaration();
            const char* enc = dec->Encoding();
            assert( enc );

            if ( *enc == 0 )
            {
                encoding = TIXML_ENCODING_UTF8;
            }
            else if ( StringEqual( enc, "UTF-8", true, TIXML_ENCODING_UNKNOWN ) )
            {
                encoding = TIXML_ENCODING_UTF8;
            }
            else if ( StringEqual( enc, "UTF8", true, TIXML_ENCODING_UNKNOWN ) )
            {
                encoding = TIXML_ENCODING_UTF8;    // incorrect, but be nice
            }
            else
            {
                encoding = TIXML_ENCODING_LEGACY;
            }
        }

        pc = SkipWhiteSpace( pc, encoding );
    }

    // Was this empty?
    if ( !pFirstChild )
    {
        SetError( TIXML_ERROR_DOCUMENT_EMPTY, 0, 0, encoding );
        return 0;
    }

    // All is well.
    return pc;
}

void TiXmlDocument::SetError( int nErr, const char* pError, TiXmlParsingData* pData,
    TiXmlEncoding encoding )
{
    // The first error in a chain is more accurate - don't set again!
    if ( bError )
    {
        return;
    }

    assert( nErr > 0 && nErr < TIXML_ERROR_STRING_COUNT );
    bError   = true;
    nErrorId = nErr;
    errorDesc = errorString[ nErrorId ];

    errorLocation.Clear();
    if ( pError && pData )
    {
        pData->Stamp( pError, encoding );
        errorLocation = pData->Cursor();
    }
}


TiXmlNode* TiXmlNode::Identify( const char* pc, TiXmlEncoding encoding )
{
    TiXmlNode* pReturnNode = 0;

    pc = SkipWhiteSpace( pc, encoding );
    if( !pc || !*pc || *pc != '<' )
    {
        return 0;
    }

    TiXmlDocument* pDoc = GetDocument();
    pc = SkipWhiteSpace( pc, encoding );

    if ( !pc || !*pc )
    {
        return 0;
    }

    // What is this thing?
    // - Elements start with a letter or underscore, but xml is reserved.
    // - Comments: <!--
    // - Decleration: <?xml
    // - Everthing else is unknown to tinyxml.
    //

    const char* pcXmlHeader = { "<?xml" };
    const char* pcCommentHeader = { "<!--" };
    const char* pcDtdHeader = { "<!" };
    const char* pcCdataHeader = { "<![CDATA[" };

    if ( StringEqual( pc, pcXmlHeader, true, encoding ) )
    {
#ifdef DEBUG_PARSER
        TIXML_LOG( "XML parsing Declaration\n" );
#endif
        pReturnNode = new TiXmlDeclaration();
    }
    else if ( StringEqual( pc, pcCommentHeader, false, encoding ) )
    {
#ifdef DEBUG_PARSER
        TIXML_LOG( "XML parsing Comment\n" );
#endif
        pReturnNode = new TiXmlComment();
    }
    else if ( StringEqual( pc, pcCdataHeader, false, encoding ) )
    {
#ifdef DEBUG_PARSER
        TIXML_LOG( "XML parsing CDATA\n" );
#endif
        TiXmlText* text = new TiXmlText( "" );
        text->SetCDATA( true );
        pReturnNode = text;
    }
    else if ( StringEqual( pc, pcDtdHeader, false, encoding ) )
    {
#ifdef DEBUG_PARSER
        TIXML_LOG( "XML parsing Unknown(1)\n" );
#endif
        pReturnNode = new TiXmlUnknown();
    }
    else if (    IsAlpha( *(pc+1), encoding )
        || *(pc+1) == '_' )
    {
#ifdef DEBUG_PARSER
        TIXML_LOG( "XML parsing Element\n" );
#endif
        pReturnNode = new TiXmlElement( "" );
    }
    else
    {
#ifdef DEBUG_PARSER
        TIXML_LOG( "XML parsing Unknown(2)\n" );
#endif
        pReturnNode = new TiXmlUnknown();
    }

    if ( pReturnNode )
    {
        // Set the parent, so it can report errors
        pReturnNode->pParent = this;
    }
    else
    {
        if ( pDoc )
        {
            pDoc->SetError( TIXML_ERROR_OUT_OF_MEMORY, 0, 0, TIXML_ENCODING_UNKNOWN );
        }
    }

    return pReturnNode;
}



void TiXmlElement::StreamIn (std::istream * pIn, TIXML_STRING * pTag)
{
    // We're called with some amount of pre-parsing. That is, some of "this"
    // element is in "tag". Go ahead and stream to the closing ">"
    while( pIn->good() )
    {
        int nC = pIn->get();
        if ( nC <= 0 )
        {
            TiXmlDocument* document = GetDocument();
            if ( document )
                document->SetError( TIXML_ERROR_EMBEDDED_NULL, 0, 0, TIXML_ENCODING_UNKNOWN );
            return;
        }
        (*pTag) += (char) nC ;

        if ( nC == '>' )
        {
            break;
        }
    }

    if ( pTag->length() < 3 ) return;

    // Okay...if we are a "/>" tag, then we're done. We've read a complete tag.
    // If not, identify and stream.

    if (    pTag->at( pTag->length() - 1 ) == '>'
        && pTag->at( pTag->length() - 2 ) == '/' )
    {
        // All good!
        return;
    }
    else if ( pTag->at( pTag->length() - 1 ) == '>' )
    {
        // There is more. Could be:
        //        text
        //        bData text (which looks like another node)
        //        closing tag
        //        another node.
        for ( ;; )
        {
            StreamWhiteSpace( pIn, pTag );

            // Do we have text?
            if ( pIn->good() && pIn->peek() != '<' )
            {
                // Yep, text.
                TiXmlText text( "" );
                text.StreamIn( pIn, pTag );

                // What follows text is a closing tag or another node.
                // Go around again and figure it out.
                continue;
            }

            // We now have either a closing tag...or another node.
            // We should be at a "<", regardless.
            if ( !pIn->good() )
            {
                return;
            }

            assert( pIn->peek() == '<' );
            int tagIndex = (int) pTag->length();

            bool bClosingTag = false;
            bool bFirstCharFound = false;

            for( ;; )
            {
                if ( !pIn->good() )
                {
                    return;
                }

                int c = pIn->peek();
                if ( c <= 0 )
                {
                    TiXmlDocument* document = GetDocument();
                    if ( document )
                    {
                        document->SetError( TIXML_ERROR_EMBEDDED_NULL, 0, 0,
                            TIXML_ENCODING_UNKNOWN );
                    }
                    return;
                }

                if ( c == '>' )
                {
                    break;
                }

                *pTag += (char) c;
                pIn->get();

                // Early out if we find the CDATA id.
                if ( c == '[' && pTag->size() >= 9 )
                {
                    size_t nLen = pTag->size();
                    const char* start = pTag->c_str() + nLen - 9;
                    if ( strcmp( start, "<![CDATA[" ) == 0 )
                    {
                        assert( !bClosingTag );
                        break;
                    }
                }

                if ( !bFirstCharFound && c != '<' && !IsWhiteSpace( c ) )
                {
                    bFirstCharFound = true;
                    if ( c == '/' )
                    {
                        bClosingTag = true;
                    }
                }
            }
            // If it was a closing tag, then read in the closing '>' to clean up the input stream.
            // If it was not, the streaming will be done by the tag.
            if ( bClosingTag )
            {
                if ( !pIn->good() )
                {
                    return;
                }

                int c = pIn->get();
                if ( c <= 0 )
                {
                    TiXmlDocument* document = GetDocument();
                    if ( document )
                    {
                        document->SetError( TIXML_ERROR_EMBEDDED_NULL, 0, 0,
                            TIXML_ENCODING_UNKNOWN );
                    }

                    return;
                }
                assert( c == '>' );
                *pTag += (char) c;

                // We are done, once we've found our closing tag.
                return;
            }
            else
            {
                // If not a closing tag, id it, and stream.
                const char* pTagloc = pTag->c_str() + tagIndex;
                TiXmlNode* pNode = Identify( pTagloc, TIXML_DEFAULT_ENCODING );
                if ( !pNode )
                {
                    return;
                }

                pNode->StreamIn( pIn, pTag );
                delete pNode;
                pNode = 0;

                // No return: go around from the beginning: text, closing tag, or node.
            }
        }
    }
}


const char* TiXmlElement::Parse( const char* pc, TiXmlParsingData* pData, TiXmlEncoding encoding )
{
    pc = SkipWhiteSpace( pc, encoding );
    TiXmlDocument* document = GetDocument();

    if ( !pc || !*pc )
    {
        if ( document )
        {
            document->SetError( TIXML_ERROR_PARSING_ELEMENT, 0, 0, encoding );
        }
        return 0;
    }

    if ( pData )
    {
        pData->Stamp( pc, encoding );
        location = pData->Cursor();
    }

    if ( *pc != '<' )
    {
        if ( document )
        {
            document->SetError( TIXML_ERROR_PARSING_ELEMENT, pc, pData, encoding );
        }
        return 0;
    }

    pc = SkipWhiteSpace( pc+1, encoding );

    // Read the name.
    const char* pErr = pc;

    pc = ReadName( pc, &value, encoding );
    if ( !pc || !*pc )
    {
        if ( document )
        {
            document->SetError( TIXML_ERROR_FAILED_TO_READ_ELEMENT_NAME,
                pErr, pData, encoding );
        }
        return 0;
    }

    TIXML_STRING endTag ("</");
    endTag += value;
    endTag += ">";

    // Check for and read attributes. Also look for an empty
    // tag or an end tag.
    while( pc && *pc )
    {
        pErr = pc;
        pc = SkipWhiteSpace( pc, encoding );
        if ( !pc || !*pc )
        {
            if ( document )
            {
                document->SetError( TIXML_ERROR_READING_ATTRIBUTES,
                    pErr, pData, encoding );
            }
            return 0;
        }

        if ( *pc == '/' )
        {
            ++pc;
            // Empty tag.
            if ( *pc  != '>' )
            {
                if ( document )
                {
                    document->SetError( TIXML_ERROR_PARSING_EMPTY, pc,
                        pData, encoding );
                }
                return 0;
            }

            return (pc+1);
        }
        else if ( *pc == '>' )
        {
            // Done with attributes (if there were any.)
            // Read the value -- which can include other
            // elements -- read the end tag, and return.
            ++pc;

            // Note this is an Element method, and will set the error if one happens.
            pc = ReadValue( pc, pData, encoding );
            if ( !pc || !*pc )
            {
                return 0;
            }

            // We should find the end tag now
            if ( StringEqual( pc, endTag.c_str(), false, encoding ) )
            {
                pc += endTag.length();
                return pc;
            }
            else
            {
                if ( document )
                {
                    document->SetError( TIXML_ERROR_READING_END_TAG, pc,
                        pData, encoding );
                }
                return 0;
            }
        }
        else
        {
            // Try to read an attribute:
            TiXmlAttribute* pAttrib = new TiXmlAttribute();
            if ( !pAttrib )
            {
                if ( document )
                {
                    document->SetError( TIXML_ERROR_OUT_OF_MEMORY, pErr,
                        pData, encoding );
                }
                return 0;
            }

            pAttrib->SetDocument( document );
            pErr = pc;
            pc = pAttrib->Parse( pc, pData, encoding );

            if ( !pc || !*pc )
            {
                if ( document )
                {
                    document->SetError( TIXML_ERROR_PARSING_ELEMENT, pErr,
                        pData, encoding );
                }
                delete pAttrib;
                pAttrib = NULL;
                return 0;
            }

            // Handle the strange case of double attributes:

            TiXmlAttribute* pNode = attributeSet.Find( pAttrib->NameTStr() );
            if ( pNode )
            {
                pNode->SetValue( pAttrib->Value() );
                delete pAttrib;
                pAttrib = NULL;
                return 0;
            }

            attributeSet.Add( pAttrib );
        }
    }
    return pc;
}


const char* TiXmlElement::ReadValue( const char* pc, TiXmlParsingData* pData,
    TiXmlEncoding encoding )
{
    TiXmlDocument* pCocument = GetDocument();

    // Read in text and elements in any order.
    const char* pWithWhiteSpace = pc;
    pc = SkipWhiteSpace( pc, encoding );

    while( pc && *pc )
    {
        if ( *pc != '<' )
        {
            // Take what we have, make a text element.
            TiXmlText* textNode = new TiXmlText( "" );

            if ( !textNode )
            {
                if ( pCocument )
                {
                    pCocument->SetError( TIXML_ERROR_OUT_OF_MEMORY, 0, 0, encoding );
                }
                return 0;
            }

            if ( TiXmlBase::IsWhiteSpaceCondensed() )
            {
                pc = textNode->Parse( pc, pData, encoding );
            }
            else
            {
                // Special case: we want to keep the white space
                // so that leading spaces aren't removed.
                pc = textNode->Parse( pWithWhiteSpace, pData, encoding );
            }

            if(!textNode->Blank() )
            {
                LinkEndChild( textNode );
            }
            else
            {
                delete textNode;
            }
        }
        else
        {
            // We hit a '<'
            // Have we hit a new element or an end tag? This could also be
            // a TiXmlText in the "CDATA" style.
            if ( StringEqual( pc, "</", false, encoding ) )
            {
                return pc;
            }
            else
            {
                TiXmlNode* node = Identify( pc, encoding );
                if ( node )
                {
                    pc = node->Parse( pc, pData, encoding );
                    LinkEndChild( node );
                }
                else
                {
                    return 0;
                }
            }
        }

        pWithWhiteSpace = pc;
        pc = SkipWhiteSpace( pc, encoding );
    }

    if ( !pc )
    {
        if ( pCocument )
        {
            pCocument->SetError( TIXML_ERROR_READING_ELEMENT_VALUE, 0, 0, encoding );
        }
    }
    return pc;
}



void TiXmlUnknown::StreamIn( std::istream * pIn, TIXML_STRING * pTag )
{
    while( pIn->good() )
    {
        int c = pIn->get();
        if ( c <= 0 )
        {
            TiXmlDocument* document = GetDocument();
            if ( document )
            {
                document->SetError( TIXML_ERROR_EMBEDDED_NULL, 0, 0, TIXML_ENCODING_UNKNOWN );
            }
            return;
        }
        (*pTag) += (char) c;

        if ( c == '>' )
        {
            // All is well.
            return;
        }
    }
}


const char* TiXmlUnknown::Parse( const char* pc, TiXmlParsingData* pData, TiXmlEncoding encoding )
{
    TiXmlDocument* pDocument = GetDocument();
    pc = SkipWhiteSpace( pc, encoding );

    if ( pData )
    {
        pData->Stamp( pc, encoding );
        location = pData->Cursor();
    }
    if ( !pc || !*pc || *pc != '<' )
    {
        if ( pDocument )
        {
            pDocument->SetError( TIXML_ERROR_PARSING_UNKNOWN, pc, pData, encoding );
        }
        return 0;
    }
    ++pc;
    value = "";

    while( pc && *pc && *pc != '>' )
    {
        value += *pc;
        ++pc;
    }

    if ( !pc )
    {
        if ( pDocument )
        {
            pDocument->SetError( TIXML_ERROR_PARSING_UNKNOWN, 0, 0, encoding );
        }
    }

    if ( *pc == '>' )
    {
        return pc+1;
    }

    return pc;
}


void TiXmlComment::StreamIn( std::istream * pIn, TIXML_STRING * pTag )
{
    while( pIn->good() )
    {
        int c = pIn->get();
        if ( c <= 0 )
        {
            TiXmlDocument* document = GetDocument();
            if ( document )
            {
                document->SetError( TIXML_ERROR_EMBEDDED_NULL, 0, 0, TIXML_ENCODING_UNKNOWN );
            }
            return;
        }

        (*pTag) += (char) c;

        if ( c == '>'
            && pTag->at( pTag->length() - 2 ) == '-'
            && pTag->at( pTag->length() - 3 ) == '-' )
        {
            // All is well.
            return;
        }
    }
}



const char* TiXmlComment::Parse( const char* pc, TiXmlParsingData* pData, TiXmlEncoding encoding )
{
    TiXmlDocument* pCocument = GetDocument();
    value = "";

    pc = SkipWhiteSpace( pc, encoding );

    if ( pData )
    {
        pData->Stamp( pc, encoding );
        location = pData->Cursor();
    }
    const char* startTag = "<!--";
    const char* endTag   = "-->";

    if ( !StringEqual( pc, startTag, false, encoding ) )
    {
        pCocument->SetError( TIXML_ERROR_PARSING_COMMENT, pc, pData, encoding );
        return 0;
    }
    pc += strlen( startTag );
    pc = ReadText( pc, &value, false, endTag, false, encoding );
    return pc;
}


const char* TiXmlAttribute::Parse( const char* pc, TiXmlParsingData* pData, TiXmlEncoding encoding )
{
    pc = SkipWhiteSpace( pc, encoding );
    if ( !pc || !*pc )
    {
        return 0;
    }
    if ( pData )
    {
        pData->Stamp( pc, encoding );
        location = pData->Cursor();
    }
    // Read the name, the '=' and the value.
    const char* pErr = pc;
    pc = ReadName( pc, &name, encoding );
    if ( !pc || !*pc )
    {
        if ( pDocument )
        {
            pDocument->SetError( TIXML_ERROR_READING_ATTRIBUTES, pErr, pData, encoding );
        }
        return 0;
    }

    pc = SkipWhiteSpace( pc, encoding );
    if ( !pc || !*pc || *pc != '=' )
    {
        if ( pDocument )
        {
            pDocument->SetError( TIXML_ERROR_READING_ATTRIBUTES, pc, pData, encoding );
        }
        return 0;
    }

    ++pc;    // skip '='
    pc = SkipWhiteSpace( pc, encoding );
    if ( !pc || !*pc )
    {
        if ( pDocument )
        {
            pDocument->SetError( TIXML_ERROR_READING_ATTRIBUTES, pc, pData, encoding );
        }
        return 0;
    }

    const char* pEnd;
    const char SINGLE_QUOTE = '\'';
    const char DOUBLE_QUOTE = '\"';

    if ( *pc == SINGLE_QUOTE )
    {
        ++pc;
        pEnd = "\'";        // single quote in string
        pc = ReadText( pc, &value, false, pEnd, false, encoding );
    }
    else if ( *pc == DOUBLE_QUOTE )
    {
        ++pc;
        pEnd = "\"";        // double quote in string
        pc = ReadText( pc, &value, false, pEnd, false, encoding );
    }
    else
    {
        // All attribute values should be in single or double quotes.
        // But this is such a common error that the parser will try
        // its best, even without them.
        value = "";
        while(    pc && *pc                                            // existence
            && !IsWhiteSpace( *pc ) && *pc != '\n' && *pc != '\r'    // whitespace
            && *pc != '/' && *pc != '>' )                            // tag end
        {
            if ( *pc == SINGLE_QUOTE || *pc == DOUBLE_QUOTE )
            {
                // [ 1451649 ] Attribute values with trailing quotes not handled correctly
                // We did not have an opening quote but seem to have a
                // closing one. Give up and throw an error.
                if ( pDocument )
                {
                    pDocument->SetError( TIXML_ERROR_READING_ATTRIBUTES, pc, pData,
                        encoding );
                }
                return 0;
            }
            value += *pc;
            ++pc;
        }
    }
    return pc;
}


void TiXmlText::StreamIn( std::istream * pIn, TIXML_STRING * ptag )
{
    while( pIn->good() )
    {
        int c = pIn->peek();
        if ( !bData && (c == '<' ) )
        {
            return;
        }

        if ( c <= 0 )
        {
            TiXmlDocument* document = GetDocument();
            if ( document )
            {
                document->SetError( TIXML_ERROR_EMBEDDED_NULL, 0, 0, TIXML_ENCODING_UNKNOWN );
            }

            return;
        }

        (*ptag) += (char) c;
        pIn->get();    // "commits" the peek made above

        if ( bData && c == '>' && ptag->size() >= 3 )
        {
            size_t nLen = ptag->size();
            if ( (*ptag)[nLen-2] == ']' && (*ptag)[nLen-3] == ']' )
            {
                // terminator of bData.
                return;
            }
        }
    }
}

const char* TiXmlText::Parse( const char* pc, TiXmlParsingData* pData, TiXmlEncoding encoding )
{
    value = "";
    TiXmlDocument* document = GetDocument();

    if ( pData )
    {
        pData->Stamp( pc, encoding );
        location = pData->Cursor();
    }

    const char* const startTag = "<![CDATA[";
    const char* const endTag   = "]]>";

    if ( bData || StringEqual( pc, startTag, false, encoding ) )
    {
        bData = true;

        if ( !StringEqual( pc, startTag, false, encoding ) )
        {
            document->SetError( TIXML_ERROR_PARSING_CDATA, pc, pData, encoding );
            return 0;
        }
        pc += strlen( startTag );

        // Keep all the white space, ignore the encoding, etc.
        while(       pc && *pc
            && !StringEqual( pc, endTag, false, encoding )
            )
        {
            value += *pc;
            ++pc;
        }

        TIXML_STRING dummy;
        pc = ReadText( pc, &dummy, false, endTag, false, encoding );
        return pc;
    }
    else
    {
        bool ignoreWhite = true;

        const char* end = "<";
        pc = ReadText( pc, &value, ignoreWhite, end, false, encoding );
        if ( pc )
        {
            return pc-1;    // don't truncate the '<'
        }

        return 0;
    }
}


void TiXmlDeclaration::StreamIn( std::istream * pIn, TIXML_STRING * ptag )
{
    while( pIn->good() )
    {
        int c = pIn->get();
        if ( c <= 0 )
        {
            TiXmlDocument* document = GetDocument();
            if ( document )
            {
                document->SetError( TIXML_ERROR_EMBEDDED_NULL, 0, 0, TIXML_ENCODING_UNKNOWN );
            }
            return;
        }
        (*ptag) += (char) c;

        if ( c == '>' )
        {
            // All is well.
            return;
        }
    }
}


const char* TiXmlDeclaration::Parse( const char* pc, TiXmlParsingData* pData,
    TiXmlEncoding _encoding )
{
    pc = SkipWhiteSpace( pc, _encoding );
    // Find the beginning, find the end, and look for
    // the stuff in-between.
    TiXmlDocument* pDocument = GetDocument();
    if ( !pc || !*pc || !StringEqual( pc, "<?xml", true, _encoding ) )
    {
        if ( pDocument )
        {
            pDocument->SetError( TIXML_ERROR_PARSING_DECLARATION, 0, 0, _encoding );
        }
        return 0;
    }

    if ( pData )
    {
        pData->Stamp( pc, _encoding );
        location = pData->Cursor();
    }
    pc += 5;

    version = "";
    encoding = "";
    standalone = "";

    while( pc && *pc )
    {
        if ( *pc == '>' )
        {
            ++pc;
            return pc;
        }

        pc = SkipWhiteSpace( pc, _encoding );
        if ( StringEqual( pc, "version", true, _encoding ) )
        {
            TiXmlAttribute attrib;
            pc = attrib.Parse( pc, pData, _encoding );
            version = attrib.Value();
        }
        else if ( StringEqual( pc, "encoding", true, _encoding ) )
        {
            TiXmlAttribute attrib;
            pc = attrib.Parse( pc, pData, _encoding );
            encoding = attrib.Value();
        }
        else if ( StringEqual( pc, "standalone", true, _encoding ) )
        {
            TiXmlAttribute attrib;
            pc = attrib.Parse( pc, pData, _encoding );
            standalone = attrib.Value();
        }
        else
        {
            // Read over whatever it is.
            while( pc && *pc && *pc != '>' && !IsWhiteSpace( *pc ) )
            {
                ++pc;
            }
        }
    }
    return 0;
}

bool TiXmlText::Blank() const
{
    for ( unsigned i=0; i<value.length(); i++ )
    {
        if ( !IsWhiteSpace( value[i] ) )
        {
            return false;
        }
    }
    return true;
}
